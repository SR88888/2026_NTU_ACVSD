module pe_config #(
    parameter  AXIL_ADDR_W = 10, AXIL_DATA_W = 128,  AXIL_RESP_W = 2
) (
    input  logic clk_ctrl_bus,
    input  logic rst_n,

    // -------------------------------------------------------------------------
    // AXI4-Lite slave (from controller) — flat ports
    // -------------------------------------------------------------------------
    input  logic [AXIL_ADDR_W-1:0]  s_axil_awaddr,
    input  logic                    s_axil_awvalid,
    output logic                    s_axil_awready,
    
    input  logic [AXIL_DATA_W-1:0]  s_axil_wdata,
    input  logic                    s_axil_wvalid,
    output logic                    s_axil_wready,

    output logic [AXIL_RESP_W-1:0]  s_axil_bresp,
    output logic                    s_axil_bvalid,
    input  logic                    s_axil_bready,

    input  logic [AXIL_ADDR_W-1:0]  s_axil_araddr,
    input  logic                    s_axil_arvalid,
    output logic                    s_axil_arready,

    output logic [AXIL_DATA_W-1:0]  s_axil_rdata,
    output logic [AXIL_RESP_W-1:0]  s_axil_rresp,
    output logic                    s_axil_rvalid,
    input  logic                    s_axil_rready,

    output logic                    push_n_config,
    output logic [38:0]             pdata_config
);
localparam S_WRITE  = 1'b0;
localparam S_BRESP  = 1'b1;
logic state, state_next;
logic state_WRITE, state_BRESP;
assign state_WRITE  = (state == S_WRITE);
assign state_BRESP  = (state == S_BRESP);

logic wready; 
logic bvalid;
//w
assign s_axil_wready = wready;
//bresp
assign s_axil_bresp = 2'b00;
assign s_axil_bvalid = bvalid;
//ar
assign s_axil_arready = 1'b0;
assign s_axil_rdata = 128'd0;
//rresp
assign s_axil_rresp = 2'b00;
assign s_axil_rvalid = 1'b0;
//============FSM============
always_comb begin
    case(state)
        S_WRITE:    state_next = s_axil_wvalid ? S_BRESP : S_WRITE;
        S_BRESP:    state_next = s_axil_bready ? S_WRITE : S_BRESP;
    endcase
end
always_ff @(posedge clk_ctrl_bus or negedge rst_n) begin
    if(!rst_n) state <= S_WRITE;
    else state <= state_next;
end

//============wready============
always_ff @(posedge clk_ctrl_bus or negedge rst_n) begin
    if(!rst_n) wready <= 1'b0;
    else wready <= (state_next == S_WRITE);
end
//============bvalid============
always_ff @(posedge clk_ctrl_bus or negedge rst_n) begin
    if(!rst_n) bvalid <= 1'b0;
    else bvalid <= (state_next == S_BRESP);
end

//============push_n_config============
always_ff @(posedge clk_ctrl_bus or negedge rst_n) begin
    if(!rst_n) push_n_config <= 1'b1;
    else push_n_config <= (!(s_axil_wvalid & s_axil_wready));
end
//============pdata_config============
always_ff @(posedge clk_ctrl_bus or negedge rst_n) begin
    if(!rst_n) pdata_config <= 39'd0;
    else if(state_WRITE) 
        pdata_config <= s_axil_wdata[38:0];
end
endmodule