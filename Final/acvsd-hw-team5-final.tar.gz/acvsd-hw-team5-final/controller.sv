`timescale 1ns/1ps
import axi_pkg::*;

module controller # (
    parameter PE_COUNT = 6
)(
    input  logic         clk_ctrl_bus, 
    input  logic         rst_n,

    // AXI4-Lite Slave from CPU (flat)
    input  logic                    s_axil_awvalid,
    output logic                    s_axil_awready,
    input  logic [AXIL_ADDR_W-1:0]  s_axil_awaddr,
    input  logic [AXIL_DATA_W-1:0]  s_axil_wdata,
    input  logic                    s_axil_wvalid,
    output logic                    s_axil_wready,
    output logic [AXIL_RESP_W-1:0]  s_axil_bresp,
    output logic                    s_axil_bvalid,
    input  logic                    s_axil_bready,
    input  logic [AXIL_ADDR_W-1:0]  s_axil_araddr,
    input  logic                    s_axil_arvalid,
    output logic                    s_axil_arready,
    output logic [AXIL_DATA_W-1:0]  s_axil_rdata,
    output logic [AXIL_RESP_W-1:0]  s_axil_rresp,
    output logic                    s_axil_rvalid,
    input  logic                    s_axil_rready,

    // AXI4-Lite Masters to 6 PEs (flat)
    output logic [AXIL_ADDR_W-1:0]  m_axil_0_1_awaddr,
    output logic                    m_axil_0_1_awvalid,
    input  logic                    m_axil_0_1_awready,
    output logic [AXIL_DATA_W-1:0]  m_axil_0_1_wdata,
    output logic                    m_axil_0_1_wvalid,
    input  logic                    m_axil_0_1_wready,
    output logic                    m_axil_0_1_bready,
    input  logic [AXIL_RESP_W-1:0]  m_axil_0_1_bresp,
    input  logic                    m_axil_0_1_bvalid,
    output logic [AXIL_ADDR_W-1:0]  m_axil_0_1_araddr,
    output logic                    m_axil_0_1_arvalid,
    input  logic                    m_axil_0_1_arready,
    output logic                    m_axil_0_1_rready,
    input  logic [AXIL_DATA_W-1:0]  m_axil_0_1_rdata,
    input  logic [AXIL_RESP_W-1:0]  m_axil_0_1_rresp,
    input  logic                    m_axil_0_1_rvalid,

    output logic [AXIL_ADDR_W-1:0]  m_axil_0_2_awaddr,
    output logic                    m_axil_0_2_awvalid,
    input  logic                    m_axil_0_2_awready,
    output logic [AXIL_DATA_W-1:0]  m_axil_0_2_wdata,
    output logic                    m_axil_0_2_wvalid,
    input  logic                    m_axil_0_2_wready,
    output logic                    m_axil_0_2_bready,
    input  logic [AXIL_RESP_W-1:0]  m_axil_0_2_bresp,
    input  logic                    m_axil_0_2_bvalid,
    output logic [AXIL_ADDR_W-1:0]  m_axil_0_2_araddr,
    output logic                    m_axil_0_2_arvalid,
    input  logic                    m_axil_0_2_arready,
    output logic                    m_axil_0_2_rready,
    input  logic [AXIL_DATA_W-1:0]  m_axil_0_2_rdata,
    input  logic [AXIL_RESP_W-1:0]  m_axil_0_2_rresp,
    input  logic                    m_axil_0_2_rvalid,

    output logic [AXIL_ADDR_W-1:0]  m_axil_0_3_awaddr,
    output logic                    m_axil_0_3_awvalid,
    input  logic                    m_axil_0_3_awready,
    output logic [AXIL_DATA_W-1:0]  m_axil_0_3_wdata,
    output logic                    m_axil_0_3_wvalid,
    input  logic                    m_axil_0_3_wready,
    output logic                    m_axil_0_3_bready,
    input  logic [AXIL_RESP_W-1:0]  m_axil_0_3_bresp,
    input  logic                    m_axil_0_3_bvalid,
    output logic [AXIL_ADDR_W-1:0]  m_axil_0_3_araddr,
    output logic                    m_axil_0_3_arvalid,
    input  logic                    m_axil_0_3_arready,
    output logic                    m_axil_0_3_rready,
    input  logic [AXIL_DATA_W-1:0]  m_axil_0_3_rdata,
    input  logic [AXIL_RESP_W-1:0]  m_axil_0_3_rresp,
    input  logic                    m_axil_0_3_rvalid,

    output logic [AXIL_ADDR_W-1:0]  m_axil_1_1_awaddr,
    output logic                    m_axil_1_1_awvalid,
    input  logic                    m_axil_1_1_awready,
    output logic [AXIL_DATA_W-1:0]  m_axil_1_1_wdata,
    output logic                    m_axil_1_1_wvalid,
    input  logic                    m_axil_1_1_wready,
    output logic                    m_axil_1_1_bready,
    input  logic [AXIL_RESP_W-1:0]  m_axil_1_1_bresp,
    input  logic                    m_axil_1_1_bvalid,
    output logic [AXIL_ADDR_W-1:0]  m_axil_1_1_araddr,
    output logic                    m_axil_1_1_arvalid,
    input  logic                    m_axil_1_1_arready,
    output logic                    m_axil_1_1_rready,
    input  logic [AXIL_DATA_W-1:0]  m_axil_1_1_rdata,
    input  logic [AXIL_RESP_W-1:0]  m_axil_1_1_rresp,
    input  logic                    m_axil_1_1_rvalid,

    output logic [AXIL_ADDR_W-1:0]  m_axil_1_2_awaddr,
    output logic                    m_axil_1_2_awvalid,
    input  logic                    m_axil_1_2_awready,
    output logic [AXIL_DATA_W-1:0]  m_axil_1_2_wdata,
    output logic                    m_axil_1_2_wvalid,
    input  logic                    m_axil_1_2_wready,
    output logic                    m_axil_1_2_bready,
    input  logic [AXIL_RESP_W-1:0]  m_axil_1_2_bresp,
    input  logic                    m_axil_1_2_bvalid,
    output logic [AXIL_ADDR_W-1:0]  m_axil_1_2_araddr,
    output logic                    m_axil_1_2_arvalid,
    input  logic                    m_axil_1_2_arready,
    output logic                    m_axil_1_2_rready,
    input  logic [AXIL_DATA_W-1:0]  m_axil_1_2_rdata,
    input  logic [AXIL_RESP_W-1:0]  m_axil_1_2_rresp,
    input  logic                    m_axil_1_2_rvalid,

    output logic [AXIL_ADDR_W-1:0]  m_axil_1_3_awaddr,
    output logic                    m_axil_1_3_awvalid,
    input  logic                    m_axil_1_3_awready,
    output logic [AXIL_DATA_W-1:0]  m_axil_1_3_wdata,
    output logic                    m_axil_1_3_wvalid,
    input  logic                    m_axil_1_3_wready,
    output logic                    m_axil_1_3_bready,
    input  logic [AXIL_RESP_W-1:0]  m_axil_1_3_bresp,
    input  logic                    m_axil_1_3_bvalid,
    output logic [AXIL_ADDR_W-1:0]  m_axil_1_3_araddr,
    output logic                    m_axil_1_3_arvalid,
    input  logic                    m_axil_1_3_arready,
    output logic                    m_axil_1_3_rready,
    input  logic [AXIL_DATA_W-1:0]  m_axil_1_3_rdata,
    input  logic [AXIL_RESP_W-1:0]  m_axil_1_3_rresp,
    input  logic                    m_axil_1_3_rvalid,

    // Interrupts from PEs
    input  logic [5:0]  interrupt_pe
);

    localparam R_IDLE = 2'd0;
    localparam R_ADDR = 2'd1;
    localparam R_DATA = 2'd2;

    localparam W_IDLE = 2'd0;
    localparam W_DATA = 2'd1;
    localparam W_RESP = 2'd2;

    logic [ 1:0] state_rd_r, state_rd_w;
    logic [15:0] proc_cnt_r, proc_cnt_w;
    logic        busy_r, busy_w;

    logic [ 1:0] state_wr_r, state_wr_w;
    logic [31:0] x_meta_r, y_meta_r, z_meta_r;
    logic [31:0] x_meta_w, y_meta_w, z_meta_w;
    logic [ 5:0] interrupt_pe_r, interrupt_pe_w;
    logic        controller_finish [0:1][1:3];

    logic [AXIL_ADDR_W-1:0]  m_axil_pe_awaddr[0:1][1:3];
    logic                    m_axil_pe_awvalid[0:1][1:3];
    logic                    m_axil_pe_awready[0:1][1:3];
    logic [AXIL_DATA_W-1:0]  m_axil_pe_wdata[0:1][1:3];
    logic                    m_axil_pe_wvalid[0:1][1:3];
    logic                    m_axil_pe_wready[0:1][1:3];
    logic                    m_axil_pe_bready[0:1][1:3];
    logic [AXIL_RESP_W-1:0]  m_axil_pe_bresp[0:1][1:3];
    logic                    m_axil_pe_bvalid[0:1][1:3];
    logic [AXIL_ADDR_W-1:0]  m_axil_pe_araddr[0:1][1:3];
    logic                    m_axil_pe_arvalid[0:1][1:3];
    logic                    m_axil_pe_arready[0:1][1:3];
    logic                    m_axil_pe_rready[0:1][1:3];
    logic [AXIL_DATA_W-1:0]  m_axil_pe_rdata[0:1][1:3];
    logic [AXIL_RESP_W-1:0]  m_axil_pe_rresp[0:1][1:3];
    logic                    m_axil_pe_rvalid[0:1][1:3];

    assign m_axil_0_1_awaddr = m_axil_pe_awaddr[0][1];
    assign m_axil_0_1_awvalid = m_axil_pe_awvalid[0][1];
    assign m_axil_pe_awready[0][1] = m_axil_0_1_awready;
    assign m_axil_0_1_wdata = m_axil_pe_wdata[0][1];
    assign m_axil_0_1_wvalid = m_axil_pe_wvalid[0][1];
    assign m_axil_pe_wready[0][1] = m_axil_0_1_wready;
    assign m_axil_0_1_bready = m_axil_pe_bready[0][1];
    assign m_axil_pe_bresp[0][1] = m_axil_0_1_bresp;
    assign m_axil_pe_bvalid[0][1] = m_axil_0_1_bvalid;
    assign m_axil_0_1_araddr = m_axil_pe_araddr[0][1];
    assign m_axil_0_1_arvalid = m_axil_pe_arvalid[0][1];
    assign m_axil_pe_arready[0][1] = m_axil_0_1_arready;
    assign m_axil_0_1_rready = m_axil_pe_rready[0][1];
    assign m_axil_pe_rdata[0][1] = m_axil_0_1_rdata;
    assign m_axil_pe_rresp[0][1] = m_axil_0_1_rresp;
    assign m_axil_pe_rvalid[0][1] = m_axil_0_1_rvalid;

    assign m_axil_0_2_awaddr = m_axil_pe_awaddr[0][2];
    assign m_axil_0_2_awvalid = m_axil_pe_awvalid[0][2];
    assign m_axil_pe_awready[0][2] = m_axil_0_2_awready;
    assign m_axil_0_2_wdata = m_axil_pe_wdata[0][2];
    assign m_axil_0_2_wvalid = m_axil_pe_wvalid[0][2];
    assign m_axil_pe_wready[0][2] = m_axil_0_2_wready;
    assign m_axil_0_2_bready = m_axil_pe_bready[0][2];
    assign m_axil_pe_bresp[0][2] = m_axil_0_2_bresp;
    assign m_axil_pe_bvalid[0][2] = m_axil_0_2_bvalid;
    assign m_axil_0_2_araddr = m_axil_pe_araddr[0][2];
    assign m_axil_0_2_arvalid = m_axil_pe_arvalid[0][2];
    assign m_axil_pe_arready[0][2] = m_axil_0_2_arready;
    assign m_axil_0_2_rready = m_axil_pe_rready[0][2];
    assign m_axil_pe_rdata[0][2] = m_axil_0_2_rdata;
    assign m_axil_pe_rresp[0][2] = m_axil_0_2_rresp;
    assign m_axil_pe_rvalid[0][2] = m_axil_0_2_rvalid;

    assign m_axil_0_3_awaddr = m_axil_pe_awaddr[0][3];
    assign m_axil_0_3_awvalid = m_axil_pe_awvalid[0][3];
    assign m_axil_pe_awready[0][3] = m_axil_0_3_awready;
    assign m_axil_0_3_wdata = m_axil_pe_wdata[0][3];
    assign m_axil_0_3_wvalid = m_axil_pe_wvalid[0][3];
    assign m_axil_pe_wready[0][3] = m_axil_0_3_wready;
    assign m_axil_0_3_bready = m_axil_pe_bready[0][3];
    assign m_axil_pe_bresp[0][3] = m_axil_0_3_bresp;
    assign m_axil_pe_bvalid[0][3] = m_axil_0_3_bvalid;
    assign m_axil_0_3_araddr = m_axil_pe_araddr[0][3];
    assign m_axil_0_3_arvalid = m_axil_pe_arvalid[0][3];
    assign m_axil_pe_arready[0][3] = m_axil_0_3_arready;
    assign m_axil_0_3_rready = m_axil_pe_rready[0][3];
    assign m_axil_pe_rdata[0][3] = m_axil_0_3_rdata;
    assign m_axil_pe_rresp[0][3] = m_axil_0_3_rresp;
    assign m_axil_pe_rvalid[0][3] = m_axil_0_3_rvalid;

    assign m_axil_1_1_awaddr = m_axil_pe_awaddr[1][1];
    assign m_axil_1_1_awvalid = m_axil_pe_awvalid[1][1];
    assign m_axil_pe_awready[1][1] = m_axil_1_1_awready;
    assign m_axil_1_1_wdata = m_axil_pe_wdata[1][1];
    assign m_axil_1_1_wvalid = m_axil_pe_wvalid[1][1];
    assign m_axil_pe_wready[1][1] = m_axil_1_1_wready;
    assign m_axil_1_1_bready = m_axil_pe_bready[1][1];
    assign m_axil_pe_bresp[1][1] = m_axil_1_1_bresp;
    assign m_axil_pe_bvalid[1][1] = m_axil_1_1_bvalid;
    assign m_axil_1_1_araddr = m_axil_pe_araddr[1][1];
    assign m_axil_1_1_arvalid = m_axil_pe_arvalid[1][1];
    assign m_axil_pe_arready[1][1] = m_axil_1_1_arready;
    assign m_axil_1_1_rready = m_axil_pe_rready[1][1];
    assign m_axil_pe_rdata[1][1] = m_axil_1_1_rdata;
    assign m_axil_pe_rresp[1][1] = m_axil_1_1_rresp;
    assign m_axil_pe_rvalid[1][1] = m_axil_1_1_rvalid;

    assign m_axil_1_2_awaddr = m_axil_pe_awaddr[1][2];
    assign m_axil_1_2_awvalid = m_axil_pe_awvalid[1][2];
    assign m_axil_pe_awready[1][2] = m_axil_1_2_awready;
    assign m_axil_1_2_wdata = m_axil_pe_wdata[1][2];
    assign m_axil_1_2_wvalid = m_axil_pe_wvalid[1][2];
    assign m_axil_pe_wready[1][2] = m_axil_1_2_wready;
    assign m_axil_1_2_bready = m_axil_pe_bready[1][2];
    assign m_axil_pe_bresp[1][2] = m_axil_1_2_bresp;
    assign m_axil_pe_bvalid[1][2] = m_axil_1_2_bvalid;
    assign m_axil_1_2_araddr = m_axil_pe_araddr[1][2];
    assign m_axil_1_2_arvalid = m_axil_pe_arvalid[1][2];
    assign m_axil_pe_arready[1][2] = m_axil_1_2_arready;
    assign m_axil_1_2_rready = m_axil_pe_rready[1][2];
    assign m_axil_pe_rdata[1][2] = m_axil_1_2_rdata;
    assign m_axil_pe_rresp[1][2] = m_axil_1_2_rresp;
    assign m_axil_pe_rvalid[1][2] = m_axil_1_2_rvalid;

    assign m_axil_1_3_awaddr = m_axil_pe_awaddr[1][3];
    assign m_axil_1_3_awvalid = m_axil_pe_awvalid[1][3];
    assign m_axil_pe_awready[1][3] = m_axil_1_3_awready;
    assign m_axil_1_3_wdata = m_axil_pe_wdata[1][3];
    assign m_axil_1_3_wvalid = m_axil_pe_wvalid[1][3];
    assign m_axil_pe_wready[1][3] = m_axil_1_3_wready;
    assign m_axil_1_3_bready = m_axil_pe_bready[1][3];
    assign m_axil_pe_bresp[1][3] = m_axil_1_3_bresp;
    assign m_axil_pe_bvalid[1][3] = m_axil_1_3_bvalid;
    assign m_axil_1_3_araddr = m_axil_pe_araddr[1][3];
    assign m_axil_1_3_arvalid = m_axil_pe_arvalid[1][3];
    assign m_axil_pe_arready[1][3] = m_axil_1_3_arready;
    assign m_axil_1_3_rready = m_axil_pe_rready[1][3];
    assign m_axil_pe_rdata[1][3] = m_axil_1_3_rdata;
    assign m_axil_pe_rresp[1][3] = m_axil_1_3_rresp;
    assign m_axil_pe_rvalid[1][3] = m_axil_1_3_rvalid;

    assign s_axil_arready = (state_rd_r == R_ADDR);
    assign s_axil_rvalid  = (state_rd_r == R_DATA);
    assign s_axil_rdata   = {111'd0, proc_cnt_r, busy_r};
    assign s_axil_rresp   = 2'd00; // OKAY
    assign s_axil_awready = (state_wr_r == W_DATA);
    assign s_axil_wready  = (state_wr_r == W_DATA) && ~busy_r;
    assign s_axil_bvalid  = (state_wr_r == W_RESP);
    assign s_axil_bresp   = 2'd00; // OKAY

    assign x_meta_w = (s_axil_wvalid && s_axil_wready) ? s_axil_wdata[63:32] : x_meta_r;
    assign y_meta_w = (s_axil_wvalid && s_axil_wready) ? s_axil_wdata[95:64] : y_meta_r;
    assign z_meta_w = (s_axil_wvalid && s_axil_wready) ? s_axil_wdata[127:96] : z_meta_r;

    always_comb begin
        state_rd_w = state_rd_r;
        case(state_rd_r)
            R_IDLE: state_rd_w = R_ADDR;
            R_ADDR: state_rd_w = (s_axil_arvalid && s_axil_arready) ? R_DATA : R_ADDR;
            R_DATA: state_rd_w = (s_axil_rvalid && s_axil_rready) ? R_ADDR : R_DATA;
        endcase
    end

    always_comb begin
        state_wr_w = state_wr_r;
        case(state_wr_r)
            W_IDLE: state_wr_w = W_DATA;
            W_DATA: state_wr_w = (s_axil_wvalid && s_axil_wready) ? W_RESP : W_DATA;
            W_RESP: state_wr_w = (s_axil_bvalid && s_axil_bready) ? W_DATA : W_RESP;
        endcase
    end

    always_comb begin
        proc_cnt_w = proc_cnt_r;
        busy_w     = busy_r;
        interrupt_pe_w = &interrupt_pe_r ? 6'd0 : (interrupt_pe_r | interrupt_pe);
        if (state_wr_r == W_DATA && s_axil_wvalid && s_axil_wready) begin
            busy_w = s_axil_wdata[0];
            proc_cnt_w = proc_cnt_r + 16'd1;
        end
        else begin
            busy_w = ~&{controller_finish[0][1], controller_finish[0][2], controller_finish[0][3], 
                        controller_finish[1][1], controller_finish[1][2], controller_finish[1][3]};
        end
    end

    genvar gen_row, gen_col;
    generate
        for (gen_row = 0; gen_row < 2; gen_row = gen_row + 1) begin
            for (gen_col = 1; gen_col < 4; gen_col = gen_col + 1) begin
                pe_controller #(
                    .PE_ROW(gen_row), .PE_COL(gen_col)
                ) u_pe_controller (
                    .clk_ctrl_bus(clk_ctrl_bus),
                    .rst_n(rst_n),
                    .start(s_axil_wvalid && s_axil_wready && s_axil_wdata[0]),
                    .x_meta(x_meta_r),
                    .y_meta(y_meta_r),
                    .z_meta(z_meta_r),
                    .finish(controller_finish[gen_row][gen_col]),
                    .m_axil_awaddr(m_axil_pe_awaddr[gen_row][gen_col]),
                    .m_axil_awvalid(m_axil_pe_awvalid[gen_row][gen_col]),
                    .m_axil_awready(m_axil_pe_awready[gen_row][gen_col]),
                    // .m_axil_awready(1'b1), // test
                    .m_axil_wdata(m_axil_pe_wdata[gen_row][gen_col]),
                    .m_axil_wvalid(m_axil_pe_wvalid[gen_row][gen_col]),
                    .m_axil_wready(m_axil_pe_wready[gen_row][gen_col]),
                    // .m_axil_wready(1'b1), // test
                    .m_axil_bready(m_axil_pe_bready[gen_row][gen_col]),
                    .m_axil_bresp(m_axil_pe_bresp[gen_row][gen_col]),
                    // .m_axil_bresp(2'd00), // test
                    .m_axil_bvalid(m_axil_pe_bvalid[gen_row][gen_col]),
                    // .m_axil_bvalid(1'b1), // test
                    .m_axil_araddr(m_axil_pe_araddr[gen_row][gen_col]),
                    .m_axil_arvalid(m_axil_pe_arvalid[gen_row][gen_col]),
                    .m_axil_arready(m_axil_pe_arready[gen_row][gen_col]),
                    .m_axil_rready(m_axil_pe_rready[gen_row][gen_col]),
                    .m_axil_rdata(m_axil_pe_rdata[gen_row][gen_col]),
                    .m_axil_rresp(m_axil_pe_rresp[gen_row][gen_col]),
                    .m_axil_rvalid(m_axil_pe_rvalid[gen_row][gen_col]),
                    .interrupt_pe(&interrupt_pe_r)
                    // .interrupt_pe(1'b1) // test
                );
            end
        end
    endgenerate

    always_ff @(posedge clk_ctrl_bus or negedge rst_n) begin
        if (!rst_n) begin
            state_rd_r      <= R_IDLE;
            state_wr_r      <= W_IDLE;
            proc_cnt_r      <= 16'd0;
            busy_r          <= 1'b0;
            interrupt_pe_r  <= 6'd0;
            x_meta_r        <= 32'd0;
            y_meta_r        <= 32'd0;
            z_meta_r        <= 32'd0;
        end
        else begin
            state_rd_r      <= state_rd_w;
            state_wr_r      <= state_wr_w;
            proc_cnt_r      <= proc_cnt_w;
            busy_r          <= busy_w;
            interrupt_pe_r  <= interrupt_pe_w;
            x_meta_r        <= x_meta_w;
            y_meta_r        <= y_meta_w;
            z_meta_r        <= z_meta_w;
        end
    end
    
endmodule

module pe_controller # (
    parameter PE_ROW = 0,
    parameter PE_COL = 1
)(
    input  logic         clk_ctrl_bus, 
    input  logic         rst_n,
    input  logic         start,
    input  logic [31:0]  x_meta,
    input  logic [31:0]  y_meta,
    input  logic [31:0]  z_meta,
    output logic         finish,

    // AXI4-Lite Master to PE (flat)
    output logic [AXIL_ADDR_W-1:0]  m_axil_awaddr,
    output logic                    m_axil_awvalid,
    input  logic                    m_axil_awready,
    output logic [AXIL_DATA_W-1:0]  m_axil_wdata,
    output logic                    m_axil_wvalid,
    input  logic                    m_axil_wready,
    output logic                    m_axil_bready,
    input  logic [AXIL_RESP_W-1:0]  m_axil_bresp,
    input  logic                    m_axil_bvalid,
    output logic [AXIL_ADDR_W-1:0]  m_axil_araddr,
    output logic                    m_axil_arvalid,
    input  logic                    m_axil_arready,
    output logic                    m_axil_rready,
    input  logic [AXIL_DATA_W-1:0]  m_axil_rdata,
    input  logic [AXIL_RESP_W-1:0]  m_axil_rresp,
    input  logic                    m_axil_rvalid,

    input  logic                    interrupt_pe
);

    localparam IDLE   = 4'd0;
    localparam DATA_X = 4'd1;
    localparam RESP_X = 4'd2;
    localparam WAIT_X = 4'd3;
    localparam DATA_Y = 4'd4;
    localparam RESP_Y = 4'd5;
    localparam WAIT_Y = 4'd6;
    localparam CALC   = 4'd7;
    localparam RESP_C = 4'd8;
    localparam WAIT_C = 4'd9;
    localparam DATA_Z = 4'd10;
    localparam RESP_Z = 4'd11;
    localparam WAIT_Z = 4'd12;

    logic [3:0] state_r, state_w;
    logic       cnt_x_read_r, cnt_x_read_w;
    logic [1:0] cnt_y_read_r, cnt_y_read_w;
    logic [4:0] cnt_k_r, cnt_k_w;
    logic [2:0] cnt_z_r, cnt_z_w;
    logic [1:0] n_bank_z;
    logic       x_last, y_last;
    logic [1:0] z_last;
    logic       x_only_one_tile;
    logic       y_only_one_tile;
    logic [3:0] cnt_x_write_r, cnt_x_write_w;
    logic [3:0] cnt_y_write_r, cnt_y_write_w;
    logic       read_x_done, read_y_done, read_k_done;
    logic       write_x_done, write_y_done, write_z_done;
    logic       fin;

    assign finish = (state_w == IDLE) || (state_r == IDLE);
    assign m_axil_araddr  = 32'd0;
    assign m_axil_arvalid = 1'b0;
    assign m_axil_rready  = 1'b0;

    assign m_axil_awaddr  = 32'd0;
    assign m_axil_awvalid = (state_r == DATA_X) | (state_r == DATA_Y) | (state_r == DATA_Z) | (state_r == CALC);
    assign m_axil_wvalid  = (state_r == DATA_X) | (state_r == DATA_Y) | (state_r == DATA_Z) | (state_r == CALC);
    assign m_axil_bready  = (state_r == RESP_X) | (state_r == RESP_Y) | (state_r == RESP_Z) | (state_r == RESP_C);

    always_comb begin
        state_w = state_r;
        case(state_r)
            IDLE:   state_w = start ? DATA_X : IDLE;
            DATA_X: state_w = (m_axil_wvalid && m_axil_wready) ? RESP_X : DATA_X;
            RESP_X: state_w = (m_axil_bvalid && m_axil_bready) ? WAIT_X : RESP_X;
            WAIT_X: state_w = interrupt_pe ? (read_x_done ? DATA_Y : DATA_X) : WAIT_X;
            DATA_Y: state_w = (m_axil_wvalid && m_axil_wready) ? RESP_Y : DATA_Y;
            RESP_Y: state_w = (m_axil_bvalid && m_axil_bready) ? WAIT_Y : RESP_Y;
            WAIT_Y: state_w = interrupt_pe ? (read_y_done ? CALC : DATA_Y) : WAIT_Y;
            CALC:   state_w = (m_axil_wvalid && m_axil_wready) ? RESP_C : CALC;
            RESP_C: state_w = (m_axil_bvalid && m_axil_bready) ? WAIT_C : RESP_C;
            WAIT_C: state_w = interrupt_pe ? (read_k_done ? DATA_Z : DATA_X) : WAIT_C;
            DATA_Z: state_w = (m_axil_wvalid && m_axil_wready) ? RESP_Z : DATA_Z;
            RESP_Z: state_w = (m_axil_bvalid && m_axil_bready) ? WAIT_Z : RESP_Z;
            WAIT_Z: state_w = interrupt_pe ? (write_z_done ? (fin ? IDLE : DATA_X) : DATA_Z) : WAIT_Z;
        endcase
    end

    always_comb begin
        n_bank_z = &z_meta[5:2] ? 2'd3 : ^z_meta[5:2] ? 2'd1 : 2'd2;
        x_last = z_meta[19] ? &{cnt_x_write_r[3], cnt_x_write_r[1]} : &z_meta[18:17] ? &cnt_x_write_r[2:0] : 
                 z_meta[18] ? &{cnt_x_write_r[2], cnt_x_write_r[0]} : cnt_x_write_r[1];
        y_last = z_meta[31] ? (z_meta[26] ? &cnt_y_write_r : &z_meta[25:24] ? &cnt_y_write_r[3:2] : z_meta[25] ? &cnt_y_write_r[2:0] : &cnt_y_write_r[1:0]) : 
                              (|z_meta[29:24] ? (cnt_y_write_r == z_meta[30]) : 1'b1);
        z_last = z_meta[19] ? (n_bank_z[1] ? 2'd0 : 2'd1) : &z_meta[18:17] ? ~n_bank_z : 
                 z_meta[18] ? 2'd0 : (n_bank_z[1] ? 2'd0 : 2'd1);
        x_only_one_tile = y_last && ~z_meta[31] && (z_meta[30:24] < 32 || (z_meta[30:24] > 64 && z_meta[30:24] <= 96));
        y_only_one_tile = x_last && (z_meta[18:17] == 2'd2);
        read_x_done = x_only_one_tile ? 1'b1 : cnt_x_read_r;
        read_y_done = x_last ? (z_meta[19] ? cnt_y_read_r[0] : &z_meta[18:17] ? cnt_y_read_r[1] : z_meta[18] ? 1'b1 : cnt_y_read_r[0]) : cnt_y_read_r[1];
        read_k_done = (cnt_k_r == (x_meta[19] ? {2'd3, 3'b111} : &x_meta[18:17] ? {2'd2, 3'b111} : x_meta[18] ? {2'd1, 3'b111} : {2'd0, 3'b111}));
        write_z_done = x_last ? (x_only_one_tile ? (cnt_z_r[2:1] == z_last) : (cnt_z_r == {z_last, 1'b1})) : 
                                (x_only_one_tile ? (cnt_z_r[2:1] == ~n_bank_z) : (cnt_z_r == {~n_bank_z, 1'b1}));
        write_x_done = x_last;
        write_y_done = y_last;
        fin = write_x_done && write_y_done;
    end

    always_comb begin
        cnt_x_read_w = (state_r == WAIT_X && interrupt_pe) ? (read_x_done ? 1'b0 : cnt_x_read_r + 1'b1) : cnt_x_read_r;
        cnt_y_read_w = (state_r == WAIT_Y && interrupt_pe) ? (read_y_done ? 2'd0: cnt_y_read_r + 1'b1) : cnt_y_read_r;
        cnt_k_w = (state_r == WAIT_C && interrupt_pe) ? (read_k_done ? 5'd0 : cnt_k_r + 5'd1) : cnt_k_r;
        cnt_z_w = (state_r == WAIT_Z && interrupt_pe) ? (write_z_done ? 3'd0 : (x_only_one_tile ? cnt_z_r + 3'd2 : cnt_z_r + 3'd1)) : cnt_z_r;
        cnt_x_write_w = (state_r == WAIT_Z && interrupt_pe && write_z_done) ? (write_x_done ? 4'd0 : cnt_x_write_r + 1'b1) : cnt_x_write_r;
        cnt_y_write_w = (state_r == WAIT_Z && interrupt_pe && write_z_done && write_x_done) ? (write_y_done ? 4'd0 : cnt_y_write_r + 1'b1) : cnt_y_write_r;
    end

    always_comb begin
        m_axil_wdata = 0;
        if (state_r == DATA_X || state_r == RESP_X || state_r == WAIT_X) begin
            m_axil_wdata[38] = 1'b0; // not used
            m_axil_wdata[37:36] = 2'd0; // config
            m_axil_wdata[35] = x_meta[31]; // n_row_devided_by_256
            m_axil_wdata[34:28] = x_meta[30:24]; // n_row
            m_axil_wdata[27:26] = x_meta[19] ? 2'd3 : &x_meta[18:17] ? 2'd2 : x_meta[18] ? 2'd1 : 2'd0; // n_col
            m_axil_wdata[25] = PE_ROW[0];
            m_axil_wdata[24:23] = PE_COL[1:0];
            if (PE_ROW == 0) begin
                if (PE_COL == 1) begin
                    case(x_meta[5:2]) // synopsys full_case
                        4'b0001: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd0; // from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b1; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = cnt_x_read_r ? 2'd2 : 2'd1; // 1: to vertical, 0: to right
                            m_axil_wdata[12:2]  = x_meta[19]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r, 1'b0})):
                                                  &x_meta[18:17] ? (x_meta[16:6] + (|x_meta[1:0] ? ({cnt_y_write_r, cnt_x_read_r, 4'd0} + {cnt_y_write_r, cnt_x_read_r, 3'd0} + cnt_k_r) :
                                                                                                   ({cnt_y_write_r, cnt_x_read_r, 5'd0} + {cnt_y_write_r, cnt_x_read_r, 4'd0} + {cnt_k_r, 1'b0}))):
                                                  x_meta[18]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:0]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:0], 1'b0})):
                                                                   (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:0]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:0], 1'b0}));
                        end
                        4'b0010: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd1; // from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0100: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd2; // from vertical
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd2; // from vertical
                            m_axil_wdata[14:13] = 2'd1; // to right
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1000: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd1; // from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0011: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_k_r[0]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = cnt_x_read_r ? 2'd2 : 2'd1; // 1: to vertical, 0: to right
                            m_axil_wdata[12:2]  = cnt_k_r[0]     ? 11'd0 : // not used
                                                  x_meta[19]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:1], 1'b0})):
                                                  &x_meta[18:17] ? (x_meta[16:6] + (|x_meta[1:0] ? ({cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_y_write_r, cnt_x_read_r, 2'd0} + cnt_k_r[4:1]) :
                                                                                                   ({cnt_y_write_r, cnt_x_read_r, 4'd0} + {cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0}))):
                                                  x_meta[18]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:1], 1'b0})):
                                                                   (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:1], 1'b0}));
                        end
                        4'b0101: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0] ? ~cnt_x_read_r : 1'b1; // path 2 valid
                            m_axil_wdata[16:15] = cnt_k_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                            m_axil_wdata[14:13] = cnt_k_r[0] ? 2'd1 : (cnt_x_read_r ? 2'd2 : 2'd1); // 1: to right, 0: (1: to vertical, 0: to right)
                            m_axil_wdata[12:2]  = cnt_k_r[0]     ? 11'd0 : // not used
                                                  x_meta[19]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:1], 1'b0})):
                                                  &x_meta[18:17] ? (x_meta[16:6] + (|x_meta[1:0] ? ({cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_y_write_r, cnt_x_read_r, 2'd0} + cnt_k_r[4:1]) :
                                                                                                   ({cnt_y_write_r, cnt_x_read_r, 4'd0} + {cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0}))):
                                                  x_meta[18]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:1], 1'b0})):
                                                                   (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:1], 1'b0}));
                        end
                        4'b1001: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_k_r[0]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = cnt_x_read_r ? 2'd2 : 2'd1; // 1: to vertical, 0: to right
                            m_axil_wdata[12:2]  = cnt_k_r[0]     ? 11'd0 : // not used
                                                  x_meta[19]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:1], 1'b0})):
                                                  &x_meta[18:17] ? (x_meta[16:6] + (|x_meta[1:0] ? ({cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_y_write_r, cnt_x_read_r, 2'd0} + cnt_k_r[4:1]) :
                                                                                                   ({cnt_y_write_r, cnt_x_read_r, 4'd0} + {cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0}))):
                                                  x_meta[18]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:1], 1'b0})):
                                                                   (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:1], 1'b0}));
                        end
                        4'b0110: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd2 : 2'd1; // 1: from vertical, 0: from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0] && ~cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd2; // from vertical
                            m_axil_wdata[14:13] = 2'd1; // to right
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1010: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd1; // from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1100: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd1 : 2'd2; // 1: from right, 0: from vertical
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_k_r[0] && ~cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd2; // from vertical
                            m_axil_wdata[14:13] = 2'd1; // to right
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1111: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd1 : (cnt_k_r[1] ? 2'd2 : 2'd0); // 1: from right, 0: (1: from vertical, 0: from left)
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_k_r[0] ? (cnt_k_r[1] ? ~cnt_x_read_r : 1'b1) : 1'b0; // path 2 valid
                            m_axil_wdata[16:15] = cnt_k_r[1] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                            m_axil_wdata[14:13] = cnt_k_r[1] ? 2'd1 : cnt_x_read_r ? 2'd2 : 2'd1; // 1: to right, 0: (1: to vertical, 0: to right)
                            m_axil_wdata[12:2]  = |cnt_k_r[1:0]  ? 11'd0 : // not used
                                                  x_meta[19]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:2]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:2], 1'b0})):
                                                  &x_meta[18:17] ? (x_meta[16:6] + (|x_meta[1:0] ? ({cnt_y_write_r, cnt_x_read_r, 2'd0} + {cnt_y_write_r, cnt_x_read_r, 1'd0} + cnt_k_r[4:2]) :
                                                                                                   ({cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_y_write_r, cnt_x_read_r, 2'd0} + {cnt_k_r[4:2], 1'b0}))):
                                                  x_meta[18]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:2]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:2], 1'b0})):
                                                                   (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2], 1'b0}));
                        end
                    endcase
                end
                else if (PE_COL == 2) begin
                    case(x_meta[5:2]) // synopsys full_case
                        4'b0001: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd0; // from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = 2'd1; // to right
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0010: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd1; // from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = 2'd0; // to left
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0100: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd0; // from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = 2'd1; // to right
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1000: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd1; // from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = 2'd0; // to left
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0011: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[14:13] = cnt_k_r[0] ? 2'd0 : 2'd1; // 1: to left, 0: to right
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0101: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd0; // from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = 2'd1; // to right
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1001: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[14:13] = cnt_k_r[0] ? 2'd0 : 2'd1; // 1: to left, 0: to right
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0110: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd0 : 2'd1; // 1: from left, 0: from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = cnt_k_r[0] ? 2'd0 : 2'd1; // 1: from left, 0: from right
                            m_axil_wdata[14:13] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: to right, 0: to left
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1010: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd1; // from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = 2'd0; // to left
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1100: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[16:15] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[14:13] = cnt_k_r[0] ? 2'd0 : 2'd1; // 1: to left, 0: to right
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1111: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[14:13] = cnt_k_r[0] ? 2'd0 : 2'd1; // 1: to left, 0: to right
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                    endcase
                end
                else begin
                    case(x_meta[5:2]) // synopsys full_case
                        4'b0001: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd0; // from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0010: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd1; // from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b1; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = cnt_x_read_r ? 2'd2 : 2'd0; // 1: to vertical, 0: to left
                            m_axil_wdata[12:2]  = x_meta[19]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r, 1'b0})):
                                                  &x_meta[18:17] ? (x_meta[16:6] + (|x_meta[1:0] ? ({cnt_y_write_r, cnt_x_read_r, 4'd0} + {cnt_y_write_r, cnt_x_read_r, 3'd0} + cnt_k_r) :
                                                                                                   ({cnt_y_write_r, cnt_x_read_r, 5'd0} + {cnt_y_write_r, cnt_x_read_r, 4'd0} + {cnt_k_r, 1'b0}))):
                                                  x_meta[18]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:0]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:0], 1'b0})):
                                                                   (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:0]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:0], 1'b0}));
                        end
                        4'b0100: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd0; // from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1000: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd2; // from vertical
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd2; // from vertical
                            m_axil_wdata[14:13] = 2'd0; // to left
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0011: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = cnt_x_read_r ? 2'd2 : 2'd0; // 1: to vertical, 0: to left
                            m_axil_wdata[12:2]  = ~cnt_k_r[0]    ? 11'd0 : // not used
                                                  x_meta[19]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:1], 1'b0})):
                                                  &x_meta[18:17] ? (x_meta[16:6] + (|x_meta[1:0] ? ({cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_y_write_r, cnt_x_read_r, 2'd0} + cnt_k_r[4:1]) :
                                                                                                   ({cnt_y_write_r, cnt_x_read_r, 4'd0} + {cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0}))):
                                                  x_meta[18]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:1], 1'b0})):
                                                                   (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:1], 1'b0}));
                        end
                        4'b0101: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd0; // from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1001: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0] && ~cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd2; // from vertical
                            m_axil_wdata[14:13] = 2'd0; // to left
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0110: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd0 : 2'd1; // 1: from left, 0: from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_k_r[0]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = cnt_x_read_r ? 2'd2 : 2'd0; // 1: to vertical, 0: to left
                            m_axil_wdata[12:2]  = cnt_k_r[0]     ? 11'd0 : // not used
                                                  x_meta[19]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:1], 1'b0})):
                                                  &x_meta[18:17] ? (x_meta[16:6] + (|x_meta[1:0] ? ({cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_y_write_r, cnt_x_read_r, 2'd0} + cnt_k_r[4:1]) :
                                                                                                   ({cnt_y_write_r, cnt_x_read_r, 4'd0} + {cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0}))):
                                                  x_meta[18]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:1], 1'b0})):
                                                                   (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:1], 1'b0}));
                        end
                        4'b1010: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd2 : 2'd1; // 1: from vertical, 0: from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0] ? ~cnt_x_read_r : 1'b1; // path 2 valid
                            m_axil_wdata[16:15] = cnt_k_r[0] ? 2'd2 : 2'd1; // 1: from vertical, 0: from right
                            m_axil_wdata[14:13] = cnt_k_r[0] ? 2'd0 : (cnt_x_read_r ? 2'd2 : 2'd0); // 1: to left, 0: (1: to vertical, 0: to left)
                            m_axil_wdata[12:2]  = cnt_k_r[0]     ? 11'd0 : // not used
                                                  x_meta[19]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:1], 1'b0})):
                                                  &x_meta[18:17] ? (x_meta[16:6] + (|x_meta[1:0] ? ({cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_y_write_r, cnt_x_read_r, 2'd0} + cnt_k_r[4:1]) :
                                                                                                   ({cnt_y_write_r, cnt_x_read_r, 4'd0} + {cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0}))):
                                                  x_meta[18]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:1], 1'b0})):
                                                                   (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:1], 1'b0}));
                        end
                        4'b1100: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0] && ~cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd2; // from vertical
                            m_axil_wdata[14:13] = 2'd0; // to left
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1111: begin
                            m_axil_wdata[22]    = ~cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = ~cnt_k_r[0] ? 2'd0 : (cnt_k_r[1] ? 2'd2 : 2'd1); // 1: from left, 0: (1: from vertical, 0: from right)
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0] ? (cnt_k_r[1] ? ~cnt_x_read_r : 1'b1) : 1'b0; // path 2 valid
                            m_axil_wdata[16:15] = cnt_k_r[1] ? 2'd2 : 2'd1; // 1: from vertical, 0: from right
                            m_axil_wdata[14:13] = cnt_k_r[1] ? 2'd0 : cnt_x_read_r ? 2'd2 : 2'd0; // 1: to left, 0: (1: to vertical, 0: to left)
                            m_axil_wdata[12:2]  = (cnt_k_r[1:0] != 2'd1) ? 11'd0 : // not used
                                                  x_meta[19]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:2]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:2], 1'b0})):
                                                  &x_meta[18:17] ? (x_meta[16:6] + (|x_meta[1:0] ? ({cnt_y_write_r, cnt_x_read_r, 2'd0} + {cnt_y_write_r, cnt_x_read_r, 1'd0} + cnt_k_r[4:2]) :
                                                                                                   ({cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_y_write_r, cnt_x_read_r, 2'd0} + {cnt_k_r[4:2], 1'b0}))):
                                                  x_meta[18]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:2]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:2], 1'b0})):
                                                                   (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2], 1'b0}));
                        end
                    endcase
                end
            end
            else begin
                if (PE_COL == 1) begin
                    case(x_meta[5:2]) // synopsys full_case
                    4'b0001: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd2; // from vertical
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd2; // from vertical
                            m_axil_wdata[14:13] = 2'd1; // to right
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0010: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd1; // from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0100: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd0; // from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b1; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = ~cnt_x_read_r ? 2'd2 : 2'd1; // 1: to vertical, 0: to right
                            m_axil_wdata[12:2]  = x_meta[19]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r, 1'b0})):
                                                  &x_meta[18:17] ? (x_meta[16:6] + (|x_meta[1:0] ? ({cnt_y_write_r, cnt_x_read_r, 4'd0} + {cnt_y_write_r, cnt_x_read_r, 3'd0} + cnt_k_r) :
                                                                                                   ({cnt_y_write_r, cnt_x_read_r, 5'd0} + {cnt_y_write_r, cnt_x_read_r, 4'd0} + {cnt_k_r, 1'b0}))):
                                                  x_meta[18]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:0]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:0], 1'b0})):
                                                                   (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:0]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:0], 1'b0}));
                        end
                        4'b1000: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd1; // from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0011: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd1 : 2'd2; // 1: from right, 0: from vertical
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_k_r[0] && cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd2; // from vertical
                            m_axil_wdata[14:13] = 2'd1; // to right
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0101: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = ~cnt_k_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_k_r[0] ? cnt_x_read_r : 1'b1; // path 2 valid
                            m_axil_wdata[16:15] = ~cnt_k_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                            m_axil_wdata[14:13] = ~cnt_k_r[0] ? 2'd1 : (~cnt_x_read_r ? 2'd2 : 2'd1); // 1: to right, 0: (1: to vertical, 0: to right)
                            m_axil_wdata[12:2]  = ~cnt_k_r[0]    ? 11'd0 : // not used
                                                  x_meta[19]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:1], 1'b0})):
                                                  &x_meta[18:17] ? (x_meta[16:6] + (|x_meta[1:0] ? ({cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_y_write_r, cnt_x_read_r, 2'd0} + cnt_k_r[4:1]) :
                                                                                                   ({cnt_y_write_r, cnt_x_read_r, 4'd0} + {cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0}))):
                                                  x_meta[18]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:1], 1'b0})):
                                                                   (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:1], 1'b0}));
                        end
                        4'b1001: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = ~cnt_k_r[0] ? 2'd2 : 2'd1; // 1: from vertical, 0: from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_k_r[0] && cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd2; // from vertical
                            m_axil_wdata[14:13] = 2'd1; // to right
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0110: begin  
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = ~cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = ~cnt_x_read_r ? 2'd2 : 2'd1; // 1: to vertical, 0: to right
                            m_axil_wdata[12:2]  = ~cnt_k_r[0]    ? 11'd0 : // not used
                                                  x_meta[19]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:1], 1'b0})):
                                                  &x_meta[18:17] ? (x_meta[16:6] + (|x_meta[1:0] ? ({cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_y_write_r, cnt_x_read_r, 2'd0} + cnt_k_r[4:1]) :
                                                                                                   ({cnt_y_write_r, cnt_x_read_r, 4'd0} + {cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0}))):
                                                  x_meta[18]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:1], 1'b0})):
                                                                   (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:1], 1'b0}));
                        end
                        4'b1010: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd1; // from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1100: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_k_r[0]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = ~cnt_x_read_r ? 2'd2 : 2'd1; // 1: to vertical, 0: to right
                            m_axil_wdata[12:2]  = cnt_k_r[0]     ? 11'd0 : // not used
                                                  x_meta[19]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:1], 1'b0})):
                                                  &x_meta[18:17] ? (x_meta[16:6] + (|x_meta[1:0] ? ({cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_y_write_r, cnt_x_read_r, 2'd0} + cnt_k_r[4:1]) :
                                                                                                   ({cnt_y_write_r, cnt_x_read_r, 4'd0} + {cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0}))):
                                                  x_meta[18]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:1], 1'b0})):
                                                                   (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:1], 1'b0}));
                        end
                        4'b1111: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd1 : (~cnt_k_r[1] ? 2'd2 : 2'd0); // 1: from right, 0: (1: from vertical, 0: from left)
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_k_r[0] ? (~cnt_k_r[1] ? cnt_x_read_r : 1'b1) : 1'b0; // path 2 valid
                            m_axil_wdata[16:15] = ~cnt_k_r[1] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                            m_axil_wdata[14:13] = ~cnt_k_r[1] ? 2'd1 : (~cnt_x_read_r ? 2'd2 : 2'd1); // 1: to right, 0: (1: to vertical, 0: to right)
                            m_axil_wdata[12:2]  = (cnt_k_r[1:0] != 2'd2) ? 11'd0 : // not used
                                                  x_meta[19]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:2]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:2], 1'b0})):
                                                  &x_meta[18:17] ? (x_meta[16:6] + (|x_meta[1:0] ? ({cnt_y_write_r, cnt_x_read_r, 2'd0} + {cnt_y_write_r, cnt_x_read_r, 1'd0} + cnt_k_r[4:2]) :
                                                                                                   ({cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_y_write_r, cnt_x_read_r, 2'd0} + {cnt_k_r[4:2], 1'b0}))):
                                                  x_meta[18]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:2]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:2], 1'b0})):
                                                                   (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2], 1'b0}));
                        end
                    endcase
                end
                else if (PE_COL == 2) begin
                    case(x_meta[5:2]) // synopsys full_case
                        4'b0001: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd0; // from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = 2'd1; // to right
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0010: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd1; // from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = 2'd0; // to left
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0100: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd0; // from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = 2'd1; // to right
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1000: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd1; // from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = 2'd0; // to left
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0011: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[14:13] = cnt_k_r[0] ? 2'd0 : 2'd1; // 1: to left, 0: to right
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0101: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd0; // from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = 2'd1; // to right
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1001: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[14:13] = cnt_k_r[0] ? 2'd0 : 2'd1; // 1: to left, 0: to right
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0110: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd0 : 2'd1; // 1: from left, 0: from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = cnt_k_r[0] ? 2'd0 : 2'd1; // 1: from left, 0: from right
                            m_axil_wdata[14:13] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: to right, 0: to left
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1010: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd1; // from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = 2'd0; // to left
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1100: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[14:13] = cnt_k_r[0] ? 2'd0 : 2'd1; // 1: to left, 0: to right
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1111: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[14:13] = cnt_k_r[0] ? 2'd0 : 2'd1; // 1: to left, 0: to right
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                    endcase
                end
                else begin
                    case(x_meta[5:2]) // synopsys full_case
                        4'b0001: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd0; // from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0010: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd2; // from vertical
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd2; // from vertical
                            m_axil_wdata[14:13] = 2'd0; // to left
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0100: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd0; // from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1000: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd1; // from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b1; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = ~cnt_x_read_r ? 2'd2 : 2'd0; // 1: to vertical, 0: to left
                            m_axil_wdata[12:2]  = x_meta[19]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r, 1'b0})):
                                                  &x_meta[18:17] ? (x_meta[16:6] + (|x_meta[1:0] ? ({cnt_y_write_r, cnt_x_read_r, 4'd0} + {cnt_y_write_r, cnt_x_read_r, 3'd0} + cnt_k_r) :
                                                                                                   ({cnt_y_write_r, cnt_x_read_r, 5'd0} + {cnt_y_write_r, cnt_x_read_r, 4'd0} + {cnt_k_r, 1'b0}))):
                                                  x_meta[18]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:0]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:0], 1'b0})):
                                                                   (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:0]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:0], 1'b0}));
                        end
                        4'b0011: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0] && cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd2; // from vertical
                            m_axil_wdata[14:13] = 2'd0; // to left
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0101: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd0; // from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1001: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = ~cnt_k_r[0] ? 2'd0 : 2'd1; // 1: from left, 0: from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = ~cnt_x_read_r ? 2'd2 : 2'd0; // 1: to vertical, 0: to left
                            m_axil_wdata[12:2]  = ~cnt_k_r[0]    ? 11'd0 : // not used
                                                  x_meta[19]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:1], 1'b0})):
                                                  &x_meta[18:17] ? (x_meta[16:6] + (|x_meta[1:0] ? ({cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_y_write_r, cnt_x_read_r, 2'd0} + cnt_k_r[4:1]) :
                                                                                                   ({cnt_y_write_r, cnt_x_read_r, 4'd0} + {cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0}))):
                                                  x_meta[18]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:1], 1'b0})):
                                                                   (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:1], 1'b0}));
                        end
                        4'b0110: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = ~cnt_k_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_k_r[0] && cnt_x_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd2; // from vertical
                            m_axil_wdata[14:13] = 2'd0; // to left
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1010: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = ~cnt_k_r[0] ? 2'd2 : 2'd1; // 1: from vertical, 0: from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_k_r[0] ? cnt_x_read_r : 1'b1; // path 2 valid
                            m_axil_wdata[16:15] = ~cnt_k_r[0] ? 2'd2 : 2'd1; // 1: from vertical, 0: from right
                            m_axil_wdata[14:13] = ~cnt_k_r[0] ? 2'd0 : (~cnt_x_read_r ? 2'd2 : 2'd0); // 1: to left, 0: (1: to vertical, 0: to left)
                            m_axil_wdata[12:2]  = ~cnt_k_r[0]    ? 11'd0 : // not used
                                                  x_meta[19]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:1], 1'b0})):
                                                  &x_meta[18:17] ? (x_meta[16:6] + (|x_meta[1:0] ? ({cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_y_write_r, cnt_x_read_r, 2'd0} + cnt_k_r[4:1]) :
                                                                                                   ({cnt_y_write_r, cnt_x_read_r, 4'd0} + {cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0}))):
                                                  x_meta[18]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:1], 1'b0})):
                                                                   (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:1], 1'b0}));
                        end
                        4'b1100: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = ~cnt_x_read_r ? 2'd2 : 2'd0; // 1: to vertical, 0: to left
                            m_axil_wdata[12:2]  = ~cnt_k_r[0]    ? 11'd0 : // not used
                                                  x_meta[19]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:1], 1'b0})):
                                                  &x_meta[18:17] ? (x_meta[16:6] + (|x_meta[1:0] ? ({cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_y_write_r, cnt_x_read_r, 2'd0} + cnt_k_r[4:1]) :
                                                                                                   ({cnt_y_write_r, cnt_x_read_r, 4'd0} + {cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0}))):
                                                  x_meta[18]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:1], 1'b0})):
                                                                   (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:1]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2:1], 1'b0}));
                        end
                        4'b1111: begin
                            m_axil_wdata[22]    = cnt_x_read_r; // path 1 valid
                            m_axil_wdata[21:20] = ~cnt_k_r[0] ? 2'd0 : (~cnt_k_r[1] ? 2'd2 : 2'd1); // 1: from left, 0: (1: from vertical, 0: from right)
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0] ? (~cnt_k_r[1] ? cnt_x_read_r : 1'b1) : 1'b0; // path 2 valid
                            m_axil_wdata[16:15] = ~cnt_k_r[1] ? 2'd2 : 2'd1; // 1: from vertical, 0: from right
                            m_axil_wdata[14:13] = ~cnt_k_r[1] ? 2'd0 : (~cnt_x_read_r ? 2'd2 : 2'd0); // 1: to left, 0: (1: to vertical, 0: to left)
                            m_axil_wdata[12:2]  = ~&cnt_k_r[1:0] ? 11'd0 : // not used
                                                  x_meta[19]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:2]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[4:2], 1'b0})):
                                                  &x_meta[18:17] ? (x_meta[16:6] + (|x_meta[1:0] ? ({cnt_y_write_r, cnt_x_read_r, 2'd0} + {cnt_y_write_r, cnt_x_read_r, 1'd0} + cnt_k_r[4:2]) :
                                                                                                   ({cnt_y_write_r, cnt_x_read_r, 3'd0} + {cnt_y_write_r, cnt_x_read_r, 2'd0} + {cnt_k_r[4:2], 1'b0}))):
                                                  x_meta[18]     ? (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:2]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[3:2], 1'b0})):
                                                                   (x_meta[16:6] + (|x_meta[1:0] ? {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2]} : {cnt_y_write_r, cnt_x_read_r, cnt_k_r[2], 1'b0}));
                        end
                    endcase
                end
            end
            m_axil_wdata[1:0] = x_meta[1:0];
        end
        else if (state_r == DATA_Y || state_r == RESP_Y || state_r == WAIT_Y) begin
            m_axil_wdata[38] = 1'b0; // not used
            m_axil_wdata[37:36] = 2'd1; // config
            m_axil_wdata[35] = y_meta[31]; // n_row_devided_by_256
            m_axil_wdata[34:28] = y_meta[30:24]; // n_row
            m_axil_wdata[27:26] = y_meta[19] ? 2'd3 : &y_meta[18:17] ? 2'd2 : y_meta[18] ? 2'd1 : 2'd0; // n_col
            m_axil_wdata[25] = PE_ROW[0];
            m_axil_wdata[24:23] = PE_COL[1:0];
            if (PE_ROW == 0) begin
                if (PE_COL == 1) begin
                    case(y_meta[5:2]) // synopsys full_case
                        4'b0001: begin
                            m_axil_wdata[22]    = ~|cnt_y_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd0; // from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b1; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = |cnt_y_read_r ? 2'd1 : 2'd2; // 1: to right, 0: to vertical
                            m_axil_wdata[12:2]  = y_meta[19]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 5'd0} + {cnt_y_read_r, 5'd0} + cnt_k_r) : 
                                                                                                   ({cnt_x_write_r, 7'd0} + {cnt_x_write_r, 6'd0} + {cnt_y_read_r, 6'd0} + {cnt_k_r, 1'b0}))) :
                                                  &y_meta[18:17] ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 4'd0} + {cnt_y_read_r, 3'd0} + cnt_k_r) : 
                                                                                                   ({cnt_x_write_r, 7'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 5'd0} + {cnt_y_read_r, 4'd0} + {cnt_k_r, 1'b0}))) :
                                                  y_meta[18]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + cnt_k_r) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 5'd0} + {cnt_y_read_r, 5'd0} + {cnt_k_r, 1'b0}))) :
                                                                   (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + cnt_k_r) : 
                                                                                                   ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + {cnt_k_r, 1'b0})));
                        end
                        4'b0010: begin
                            m_axil_wdata[22]    = ~|cnt_y_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd1; // from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~|cnt_y_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = 2'd2; // to vertical
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0100: begin
                            m_axil_wdata[22]    = ~|cnt_y_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd2; // from vertical
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1000: begin
                            m_axil_wdata[22]    = ~|cnt_y_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd2; // from vertical
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0011: begin
                            m_axil_wdata[22]    = ~|cnt_y_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0] ? ~|cnt_y_read_r : 1'b1; // path 2 valid
                            m_axil_wdata[16:15] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[14:13] = cnt_k_r[0] ? 2'd2 : (|cnt_y_read_r ? 2'd1 : 2'd2); // 1: to vertical, 0: (1: to right, 0: to vertical)
                            m_axil_wdata[12:2]  = cnt_k_r[0]     ? 11'd0 : // not used
                                                  y_meta[19]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 5'd0} + {cnt_y_read_r, 5'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                  &y_meta[18:17] ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 3'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 4'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                  y_meta[18]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                                   (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 3'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0})));
                        end
                        4'b0101: begin
                            m_axil_wdata[22]    = ~|cnt_y_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_k_r[0]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = |cnt_y_read_r ? 2'd1 : 2'd2; // 1: to right, 0: to vertical
                            m_axil_wdata[12:2]  = cnt_k_r[0]     ? 11'd0 : // not used
                                                  y_meta[19]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 5'd0} + {cnt_y_read_r, 5'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                  &y_meta[18:17] ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 3'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 4'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                  y_meta[18]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                                   (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 3'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0})));
                        end
                        4'b1001: begin
                            m_axil_wdata[22]    = ~|cnt_y_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_k_r[0]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = |cnt_y_read_r ? 2'd1 : 2'd2; // 1: to right, 0: to vertical
                            m_axil_wdata[12:2]  = cnt_k_r[0]     ? 11'd0 : // not used
                                                  y_meta[19]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 5'd0} + {cnt_y_read_r, 5'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                  &y_meta[18:17] ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 3'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 4'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                  y_meta[18]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                                   (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 3'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0})));
                        end
                        4'b0110: begin
                            m_axil_wdata[22]    = ~|cnt_y_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd2 : 2'd1; // 1: from vertical, 0: from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_k_r[0] && ~|cnt_y_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = 2'd2; // to vertical
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1010: begin
                            m_axil_wdata[22]    = ~|cnt_y_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd2 : 2'd1; // 1: from vertical, 0: from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_k_r[0] && ~|cnt_y_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = 2'd2; // to vertical
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1100: begin
                            m_axil_wdata[22]    = ~|cnt_y_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd2; // from vertical
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1111: begin
                            m_axil_wdata[22]    = ~|cnt_y_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[1] ? 2'd2 : (cnt_k_r[0] ? 2'd1 : 2'd0); // 1: from vertical, 0: (1: from right, 0: from left)
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[1] ? 1'b0 : (cnt_k_r[0] ? ~|cnt_y_read_r : 1'b1); // path 2 valid
                            m_axil_wdata[16:15] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[14:13] = cnt_k_r[0] ? 2'd2 : (|cnt_y_read_r ? 2'd1 : 2'd2); // 1: to vertical, 0: (1: to right, 0: to vertical)
                            m_axil_wdata[12:2]  = |cnt_k_r[1:0]  ? 11'd0 : // not used
                                                  y_meta[19]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + cnt_k_r[4:2]) : 
                                                                                                   ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + {cnt_k_r[4:2], 1'b0}))) :
                                                  &y_meta[18:17] ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 1'd0} + {cnt_y_read_r, 2'd0} + {cnt_y_read_r, 1'd0} + cnt_k_r[4:2]) : 
                                                                                                   ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 3'd0} + {cnt_y_read_r, 2'd0} + {cnt_k_r[4:2], 1'b0}))) :
                                                  y_meta[18]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 3'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:2]) : 
                                                                                                   ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:2], 1'b0}))) :
                                                                   (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 2'd0} + {cnt_x_write_r, 1'd0} + {cnt_y_read_r, 1'd0} + cnt_k_r[4:2]) : 
                                                                                                   ({cnt_x_write_r, 3'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 2'd0} + {cnt_k_r[4:2], 1'b0})));
                        end
                    endcase
                end
                else if (PE_COL == 2) begin
                    case(y_meta[5:2]) // synopsys full_case
                        4'b0001: begin
                            m_axil_wdata[22]    = cnt_y_read_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = 2'd0; // from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = |cnt_y_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = cnt_y_read_r[0] ? 2'd2 : 2'd1; // 1: to vertical, 0: to right
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0010: begin
                            m_axil_wdata[22]    = cnt_y_read_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = 2'd1; // from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_y_read_r[1]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = cnt_y_read_r[0] ? 2'd2 : 2'd0; // 1: to vertical, 0: to left
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0100: begin
                            m_axil_wdata[22]    = cnt_y_read_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = 2'd2; // from vertical
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1000: begin
                            m_axil_wdata[22]    = cnt_y_read_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = 2'd2; // from vertical
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0011: begin
                            m_axil_wdata[22]    = cnt_y_read_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0] ? ~cnt_y_read_r[1] : |cnt_y_read_r; // path 2 valid
                            m_axil_wdata[16:15] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[14:13] = cnt_y_read_r[0] ? 2'd2 : (cnt_k_r[0] ? 2'd0 : 2'd1); // 1: to vertical, 0: (1: to left, 0: to right)
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0101: begin
                            m_axil_wdata[22]    = cnt_y_read_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_k_r[0] && |cnt_y_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = cnt_y_read_r[0] ? 2'd2 : 2'd1; // 1: to vertical, 0: to right
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1001: begin
                            m_axil_wdata[22]    = cnt_y_read_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_k_r[0] && |cnt_y_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = cnt_y_read_r[0] ? 2'd2 : 2'd1; // 1: to vertical, 0: to right
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0110: begin
                            m_axil_wdata[22]    = cnt_y_read_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd2 : 2'd1; // 1: from vertical, 0: from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_k_r[0] && ~cnt_y_read_r[1]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = cnt_y_read_r[0] ? 2'd2 : 2'd0; // 1: to vertical, 0: to left
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1010: begin
                            m_axil_wdata[22]    = cnt_y_read_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd2 : 2'd1; // 1: from vertical, 0: from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_k_r[0] && ~cnt_y_read_r[1]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = cnt_y_read_r[0] ? 2'd2 : 2'd0; // 1: to vertical, 0: to left
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1100: begin
                            m_axil_wdata[22]    = cnt_y_read_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = 2'd2; // from vertical
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1111: begin
                            m_axil_wdata[22]    = cnt_y_read_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[1] ? 2'd2 : (cnt_k_r[0] ? 2'd1 : 2'd0); // 1: from vertical, 0: (1: from right, 0: from left)
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_k_r[1] ? (cnt_k_r[0] ? ~cnt_y_read_r[1] : |cnt_y_read_r) : 1'b0; // path 2 valid
                            m_axil_wdata[16:15] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[14:13] = cnt_y_read_r[0] ? 2'd2 : (cnt_k_r[0] ? 2'd0 : 2'd1); // 1: to vertical, 0: (1: to left, 0: to right)
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                    endcase
                end
                else begin
                    case(y_meta[5:2]) // synopsys full_case
                        4'b0001: begin
                            m_axil_wdata[22]    = cnt_y_read_r[1]; // path 1 valid
                            m_axil_wdata[21:20] = 2'd0; // from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_y_read_r[1]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = 2'd2; // to vertical
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0010: begin
                            m_axil_wdata[22]    = cnt_y_read_r[1]; // path 1 valid
                            m_axil_wdata[21:20] = 2'd1; // from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b1; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = ~cnt_y_read_r[1] ? 2'd0 : 2'd2; // 1: to left, 0: to vertical
                            m_axil_wdata[12:2]  = y_meta[19]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 5'd0} + {cnt_y_read_r, 5'd0} + cnt_k_r) : 
                                                                                                   ({cnt_x_write_r, 7'd0} + {cnt_x_write_r, 6'd0} + {cnt_y_read_r, 6'd0} + {cnt_k_r, 1'b0}))) :
                                                  &y_meta[18:17] ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 4'd0} + {cnt_y_read_r, 3'd0} + cnt_k_r) : 
                                                                                                   ({cnt_x_write_r, 7'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 5'd0} + {cnt_y_read_r, 4'd0} + {cnt_k_r, 1'b0}))) :
                                                  y_meta[18]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + cnt_k_r) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 5'd0} + {cnt_y_read_r, 5'd0} + {cnt_k_r, 1'b0}))) :
                                                                   (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + cnt_k_r) : 
                                                                                                   ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + {cnt_k_r, 1'b0})));
                        end
                        4'b0100: begin
                            m_axil_wdata[22]    = cnt_y_read_r[1]; // path 1 valid
                            m_axil_wdata[21:20] = 2'd2; // from vertical
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1000: begin
                            m_axil_wdata[22]    = cnt_y_read_r[1]; // path 1 valid
                            m_axil_wdata[21:20] = 2'd2; // from vertical
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0011: begin
                            m_axil_wdata[22]    = cnt_y_read_r[1]; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0] ? 1'b1 : cnt_y_read_r[1]; // path 2 valid
                            m_axil_wdata[16:15] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[14:13] = cnt_k_r[0] ? (~cnt_y_read_r[1] ? 2'd0 : 2'd2) : 2'd2; // 1: (1: to left, 0: to vertical), 0: to vertical
                            m_axil_wdata[12:2]  = ~cnt_k_r[0]    ? 11'd0 : // not used
                                                  y_meta[19]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 5'd0} + {cnt_y_read_r, 5'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                  &y_meta[18:17] ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 3'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 4'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                  y_meta[18]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                                   (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 3'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0})));
                        end
                        4'b0101: begin
                            m_axil_wdata[22]    = cnt_y_read_r[1]; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_k_r[0] && cnt_y_read_r[1]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = 2'd2; // to vertical
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1001: begin
                            m_axil_wdata[22]    = cnt_y_read_r[1]; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_k_r[0] && cnt_y_read_r[1]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = 2'd2; // to vertical
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0110: begin
                            m_axil_wdata[22]    = cnt_y_read_r[1]; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd2 : 2'd1; // 1: from vertical, 0: from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_k_r[0]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = ~cnt_y_read_r[1] ? 2'd0 : 2'd2; // 1: to left, 0: to vertical
                            m_axil_wdata[12:2]  = cnt_k_r[0]     ? 11'd0 : // not used
                                                  y_meta[19]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 5'd0} + {cnt_y_read_r, 5'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                  &y_meta[18:17] ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 3'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 4'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                  y_meta[18]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                                   (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 3'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0})));
                        end
                        4'b1010: begin
                            m_axil_wdata[22]    = cnt_y_read_r[1]; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd2 : 2'd1; // 1: from vertical, 0: from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_k_r[0]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = ~cnt_y_read_r[1] ? 2'd0 : 2'd2; // 1: to left, 0: to vertical
                            m_axil_wdata[12:2]  = cnt_k_r[0]     ? 11'd0 : // not used
                                                  y_meta[19]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 5'd0} + {cnt_y_read_r, 5'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                  &y_meta[18:17] ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 3'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 4'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                  y_meta[18]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                                   (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 3'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0})));
                        end
                        4'b1100: begin
                            m_axil_wdata[22]    = cnt_y_read_r[1]; // path 1 valid
                            m_axil_wdata[21:20] = 2'd2; // from vertical
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1111: begin
                            m_axil_wdata[22]    = cnt_y_read_r[1]; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[1] ? 2'd2 : (cnt_k_r[0] ? 2'd1 : 2'd0); // 1: from vertical, 0: (1: from right, 0: from left)
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[1] ? 1'b0 : (cnt_k_r[0] ? 1'b1 : cnt_y_read_r[1]); // path 2 valid
                            m_axil_wdata[16:15] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[14:13] = cnt_k_r[0] ? (~cnt_y_read_r[1] ? 2'd0 : 2'd2) : 2'd2; // 1: (1: to left, 0: to vertical), 0: to vertical
                            m_axil_wdata[12:2]  = (cnt_k_r[1:0] != 2'd1) ? 11'd0 : // not used
                                                  y_meta[19]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + cnt_k_r[4:2]) : 
                                                                                                   ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + {cnt_k_r[4:2], 1'b0}))) :
                                                  &y_meta[18:17] ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 1'd0} + {cnt_y_read_r, 2'd0} + {cnt_y_read_r, 1'd0} + cnt_k_r[4:2]) : 
                                                                                                   ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 3'd0} + {cnt_y_read_r, 2'd0} + {cnt_k_r[4:2], 1'b0}))) :
                                                  y_meta[18]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 3'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:2]) : 
                                                                                                   ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:2], 1'b0}))) :
                                                                   (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 2'd0} + {cnt_x_write_r, 1'd0} + {cnt_y_read_r, 1'd0} + cnt_k_r[4:2]) : 
                                                                                                   ({cnt_x_write_r, 3'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 2'd0} + {cnt_k_r[4:2], 1'b0})));
                        end
                    endcase
                end
            end
            else begin
                if (PE_COL == 1) begin
                    case(y_meta[5:2]) // synopsys full_case
                    4'b0001: begin
                            m_axil_wdata[22]    = ~|cnt_y_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd2; // from vertical
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0010: begin
                            m_axil_wdata[22]    = ~|cnt_y_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd2; // from vertical
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0100: begin
                            m_axil_wdata[22]    = ~|cnt_y_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd0; // from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b1; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = |cnt_y_read_r ? 2'd1 : 2'd2; // 1: to right, 0: to vertical
                            m_axil_wdata[12:2]  = y_meta[19]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 5'd0} + {cnt_y_read_r, 5'd0} + cnt_k_r) : 
                                                                                                   ({cnt_x_write_r, 7'd0} + {cnt_x_write_r, 6'd0} + {cnt_y_read_r, 6'd0} + {cnt_k_r, 1'b0}))) :
                                                  &y_meta[18:17] ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 4'd0} + {cnt_y_read_r, 3'd0} + cnt_k_r) : 
                                                                                                   ({cnt_x_write_r, 7'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 5'd0} + {cnt_y_read_r, 4'd0} + {cnt_k_r, 1'b0}))) :
                                                  y_meta[18]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + cnt_k_r) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 5'd0} + {cnt_y_read_r, 5'd0} + {cnt_k_r, 1'b0}))) :
                                                                   (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + cnt_k_r) : 
                                                                                                   ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + {cnt_k_r, 1'b0})));
                        end
                        4'b1000: begin
                            m_axil_wdata[22]    = ~|cnt_y_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd1; // from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~|cnt_y_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = 2'd2; // to vertical
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0011: begin
                            m_axil_wdata[22]    = ~|cnt_y_read_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd2; // from vertical
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0101: begin
                            m_axil_wdata[22]    = ~|cnt_y_read_r; // path 1 valid
                            m_axil_wdata[21:20] = ~cnt_k_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = |cnt_y_read_r ? 2'd1 : 2'd2; // 1: to right, 0: to vertical
                            m_axil_wdata[12:2]  = ~cnt_k_r[0]    ? 11'd0 : // not used
                                                  y_meta[19]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 5'd0} + {cnt_y_read_r, 5'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                  &y_meta[18:17] ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 3'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 4'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                  y_meta[18]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                                   (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 3'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0})));
                        end
                        4'b1001: begin
                            m_axil_wdata[22]    = ~|cnt_y_read_r; // path 1 valid
                            m_axil_wdata[21:20] = ~cnt_k_r[0] ? 2'd2 : 2'd1; // 1: from vertical, 0: from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0] && ~|cnt_y_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = 2'd2; // to vertical
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0110: begin
                            m_axil_wdata[22]    = ~|cnt_y_read_r; // path 1 valid
                            m_axil_wdata[21:20] = ~cnt_k_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = |cnt_y_read_r ? 2'd1 : 2'd2; // 1: to right, 0: to vertical
                            m_axil_wdata[12:2]  = ~cnt_k_r[0]    ? 11'd0 : // not used
                                                  y_meta[19]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 5'd0} + {cnt_y_read_r, 5'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                  &y_meta[18:17] ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 3'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 4'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                  y_meta[18]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                                   (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 3'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0})));
                        end
                        4'b1010: begin
                            m_axil_wdata[22]    = ~|cnt_y_read_r; // path 1 valid
                            m_axil_wdata[21:20] = ~cnt_k_r[0] ? 2'd2 : 2'd1; // 1: from vertical, 0: from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0] && ~|cnt_y_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = 2'd2; // to vertical
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1100: begin
                            m_axil_wdata[22]    = ~|cnt_y_read_r; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0] ? ~|cnt_y_read_r : 1'b1; // path 2 valid
                            m_axil_wdata[16:15] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[14:13] = cnt_k_r[0] ? 2'd2 : (|cnt_y_read_r ? 2'd1 : 2'd2); // 1: to vertical, 0: (1: to right, 0: to vertical)
                            m_axil_wdata[12:2]  = cnt_k_r[0]     ? 11'd0 : // not used
                                                  y_meta[19]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 5'd0} + {cnt_y_read_r, 5'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                  &y_meta[18:17] ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 3'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 4'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                  y_meta[18]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                                   (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 3'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0})));
                        end
                        4'b1111: begin
                            m_axil_wdata[22]    = ~|cnt_y_read_r; // path 1 valid
                            m_axil_wdata[21:20] = ~cnt_k_r[1] ? 2'd2 : (cnt_k_r[0] ? 2'd1 : 2'd0); // 1: from vertical, 0: (1: from right, 0: from left)
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_k_r[1] ? 1'b0 : (cnt_k_r[0] ? ~|cnt_y_read_r : 1'b1); // path 2 valid
                            m_axil_wdata[16:15] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[14:13] = cnt_k_r[0] ? 2'd2 : (|cnt_y_read_r ? 2'd1 : 2'd2); // 1: to vertical, 0: (1: to right, 0: to vertical)
                            m_axil_wdata[12:2]  = (cnt_k_r[1:0] != 2'd2) ? 11'd0 : // not used
                                                  y_meta[19]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + cnt_k_r[4:2]) : 
                                                                                                   ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + {cnt_k_r[4:2], 1'b0}))) :
                                                  &y_meta[18:17] ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 1'd0} + {cnt_y_read_r, 2'd0} + {cnt_y_read_r, 1'd0} + cnt_k_r[4:2]) : 
                                                                                                   ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 3'd0} + {cnt_y_read_r, 2'd0} + {cnt_k_r[4:2], 1'b0}))) :
                                                  y_meta[18]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 3'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:2]) : 
                                                                                                   ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:2], 1'b0}))) :
                                                                   (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 2'd0} + {cnt_x_write_r, 1'd0} + {cnt_y_read_r, 1'd0} + cnt_k_r[4:2]) : 
                                                                                                   ({cnt_x_write_r, 3'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 2'd0} + {cnt_k_r[4:2], 1'b0})));
                        end
                    endcase
                end
                else if (PE_COL == 2) begin
                    case(y_meta[5:2]) // synopsys full_case
                        4'b0001: begin
                            m_axil_wdata[22]    = cnt_y_read_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = 2'd2; // from vertical
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0010: begin
                            m_axil_wdata[22]    = cnt_y_read_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = 2'd2; // from vertical
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0100: begin
                            m_axil_wdata[22]    = cnt_y_read_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = 2'd0; // from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = |cnt_y_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = cnt_y_read_r[0] ? 2'd2 : 2'd1; // 1: to vertical, 0: to right
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1000: begin
                            m_axil_wdata[22]    = cnt_y_read_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = 2'd1; // from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_y_read_r[1]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = cnt_y_read_r[0] ? 2'd2 : 2'd0; // 1: to vertical, 0: to left
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0011: begin
                            m_axil_wdata[22]    = cnt_y_read_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = 2'd2; // from vertical
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0101: begin
                            m_axil_wdata[22]    = cnt_y_read_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = ~cnt_k_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0] && |cnt_y_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = cnt_y_read_r[0] ? 2'd2 : 2'd1; // 1: to vertical, 0: to right
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1001: begin
                            m_axil_wdata[22]    = cnt_y_read_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = ~cnt_k_r[0] ? 2'd2 : 2'd1; // 1: from vertical, 0: from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0] && ~cnt_y_read_r[1]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = cnt_y_read_r[0] ? 2'd2 : 2'd0; // 1: to vertical, 0: to left
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0110: begin
                            m_axil_wdata[22]    = cnt_y_read_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = ~cnt_k_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0] && |cnt_y_read_r; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = cnt_y_read_r[0] ? 2'd2 : 2'd1; // 1: to vertical, 0: to right
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1010: begin
                            m_axil_wdata[22]    = cnt_y_read_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = ~cnt_k_r[0] ? 2'd2 : 2'd1; // 1: from vertical, 0: from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0] && ~cnt_y_read_r[1]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = cnt_y_read_r[0] ? 2'd2 : 2'd0; // 1: to vertical, 0: to left
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1100: begin
                            m_axil_wdata[22]    = cnt_y_read_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0] ? ~cnt_y_read_r[1] : |cnt_y_read_r; // path 2 valid
                            m_axil_wdata[16:15] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[14:13] = cnt_y_read_r[0] ? 2'd2 : (cnt_k_r[0] ? 2'd0 : 2'd1); // 1: to vertical, 0: (1: to left, 0: to right)
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1111: begin
                            m_axil_wdata[22]    = cnt_y_read_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = ~cnt_k_r[1] ? 2'd2 : (cnt_k_r[0] ? 2'd1 : 2'd0); // 1: from vertical, 0: (1: from right, 0: from left)
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[1] ? (cnt_k_r[0] ? ~cnt_y_read_r[1] : |cnt_y_read_r) : 1'b0; // path 2 valid
                            m_axil_wdata[16:15] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[14:13] = cnt_y_read_r[0] ? 2'd2 : (cnt_k_r[0] ? 2'd0 : 2'd1); // 1: to vertical, 0: (1: to left, 0: to right)
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                    endcase
                end
                else begin
                    case(y_meta[5:2]) // synopsys full_case
                        4'b0001: begin
                            m_axil_wdata[22]    = cnt_y_read_r[1]; // path 1 valid
                            m_axil_wdata[21:20] = 2'd2; // from vertical
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0010: begin
                            m_axil_wdata[22]    = cnt_y_read_r[1]; // path 1 valid
                            m_axil_wdata[21:20] = 2'd2; // from vertical
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0100: begin
                            m_axil_wdata[22]    = cnt_y_read_r[1]; // path 1 valid
                            m_axil_wdata[21:20] = 2'd0; // from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_y_read_r[1]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = 2'd2; // to vertical
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1000: begin
                            m_axil_wdata[22]    = cnt_y_read_r[1]; // path 1 valid
                            m_axil_wdata[21:20] = 2'd1; // from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b1; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = ~cnt_y_read_r[1] ? 2'd0 : 2'd2; // 1: to left, 0: to vertical
                            m_axil_wdata[12:2]  = y_meta[19]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 5'd0} + {cnt_y_read_r, 5'd0} + cnt_k_r) : 
                                                                                                   ({cnt_x_write_r, 7'd0} + {cnt_x_write_r, 6'd0} + {cnt_y_read_r, 6'd0} + {cnt_k_r, 1'b0}))) :
                                                  &y_meta[18:17] ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 4'd0} + {cnt_y_read_r, 3'd0} + cnt_k_r) : 
                                                                                                   ({cnt_x_write_r, 7'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 5'd0} + {cnt_y_read_r, 4'd0} + {cnt_k_r, 1'b0}))) :
                                                  y_meta[18]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + cnt_k_r) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 5'd0} + {cnt_y_read_r, 5'd0} + {cnt_k_r, 1'b0}))) :
                                                                   (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + cnt_k_r) : 
                                                                                                   ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + {cnt_k_r, 1'b0})));
                        end
                        4'b0011: begin
                            m_axil_wdata[22]    = cnt_y_read_r[1]; // path 1 valid
                            m_axil_wdata[21:20] = 2'd2; // from vertical
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0101: begin
                            m_axil_wdata[22]    = cnt_y_read_r[1]; // path 1 valid
                            m_axil_wdata[21:20] = ~cnt_k_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0] && cnt_y_read_r[1]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = 2'd2; // to vertical
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1001: begin
                            m_axil_wdata[22]    = cnt_y_read_r[1]; // path 1 valid
                            m_axil_wdata[21:20] = ~cnt_k_r[0] ? 2'd2 : 2'd1; // 1: from vertical, 0: from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = ~cnt_y_read_r[1] ? 2'd0 : 2'd2; // 1: to left, 0: to vertical
                            m_axil_wdata[12:2]  = ~cnt_k_r[0]    ? 11'd0 : // not used
                                                  y_meta[19]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 5'd0} + {cnt_y_read_r, 5'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                  &y_meta[18:17] ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 3'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 4'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                  y_meta[18]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                                   (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 3'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0})));
                        end
                        4'b0110: begin
                            m_axil_wdata[22]    = cnt_y_read_r[1]; // path 1 valid
                            m_axil_wdata[21:20] = ~cnt_k_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0] && cnt_y_read_r[1]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd0; // from left
                            m_axil_wdata[14:13] = 2'd2; // to vertical
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1010: begin
                            m_axil_wdata[22]    = cnt_y_read_r[1]; // path 1 valid
                            m_axil_wdata[21:20] = ~cnt_k_r[0] ? 2'd2 : 2'd1; // 1: from vertical, 0: from right
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0]; // path 2 valid
                            m_axil_wdata[16:15] = 2'd1; // from right
                            m_axil_wdata[14:13] = ~cnt_y_read_r[1] ? 2'd0 : 2'd2; // 1: to left, 0: to vertical
                            m_axil_wdata[12:2]  = ~cnt_k_r[0]    ? 11'd0 : // not used
                                                  y_meta[19]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 5'd0} + {cnt_y_read_r, 5'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                  &y_meta[18:17] ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 3'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 4'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                  y_meta[18]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                                   (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 3'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0})));
                        end
                        4'b1100: begin
                            m_axil_wdata[22]    = cnt_y_read_r[1]; // path 1 valid
                            m_axil_wdata[21:20] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = cnt_k_r[0] ? 1'b1 : cnt_y_read_r[1]; // path 2 valid
                            m_axil_wdata[16:15] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[14:13] = cnt_k_r[0] ? (~cnt_y_read_r[1] ? 2'd0 : 2'd2) : 2'd2; // 1: (1: to left, 0: to vertical), 0: to vertical
                            m_axil_wdata[12:2]  = ~cnt_k_r[0]    ? 11'd0 : // not used
                                                  y_meta[19]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 5'd0} + {cnt_y_read_r, 5'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                  &y_meta[18:17] ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 3'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 6'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 4'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                  y_meta[18]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + {cnt_k_r[4:1], 1'b0}))) :
                                                                   (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 3'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:1]) : 
                                                                                                   ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:1], 1'b0})));
                        end
                        4'b1111: begin
                            m_axil_wdata[22]    = cnt_y_read_r[1]; // path 1 valid
                            m_axil_wdata[21:20] = ~cnt_k_r[1] ? 2'd2 : (cnt_k_r[0] ? 2'd1 : 2'd0); // 1: from vertical, 0: (1: from right, 0: from left)
                            m_axil_wdata[19:18] = 2'd3; // to self
                            m_axil_wdata[17]    = ~cnt_k_r[1] ? 1'b0 : (cnt_k_r[0] ? 1'b1 : cnt_y_read_r[1]); // path 2 valid
                            m_axil_wdata[16:15] = cnt_k_r[0] ? 2'd1 : 2'd0; // 1: from right, 0: from left
                            m_axil_wdata[14:13] = cnt_k_r[0] ? (~cnt_y_read_r[1] ? 2'd0 : 2'd2) : 2'd2; // 1: (1: to left, 0: to vertical), 0: to vertical
                            m_axil_wdata[12:2]  = ~&cnt_k_r[1:0] ? 11'd0 : // not used
                                                  y_meta[19]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + cnt_k_r[4:2]) : 
                                                                                                   ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 4'd0} + {cnt_y_read_r, 4'd0} + {cnt_k_r[4:2], 1'b0}))) :
                                                  &y_meta[18:17] ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 1'd0} + {cnt_y_read_r, 2'd0} + {cnt_y_read_r, 1'd0} + cnt_k_r[4:2]) : 
                                                                                                   ({cnt_x_write_r, 5'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 3'd0} + {cnt_y_read_r, 2'd0} + {cnt_k_r[4:2], 1'b0}))) :
                                                  y_meta[18]     ? (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 3'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 2'd0} + cnt_k_r[4:2]) : 
                                                                                                   ({cnt_x_write_r, 4'd0} + {cnt_x_write_r, 3'd0} + {cnt_y_read_r, 3'd0} + {cnt_k_r[4:2], 1'b0}))) :
                                                                   (y_meta[16:6] + (|y_meta[1:0] ? ({cnt_x_write_r, 2'd0} + {cnt_x_write_r, 1'd0} + {cnt_y_read_r, 1'd0} + cnt_k_r[4:2]) : 
                                                                                                   ({cnt_x_write_r, 3'd0} + {cnt_x_write_r, 2'd0} + {cnt_y_read_r, 2'd0} + {cnt_k_r[4:2], 1'b0})));
                        end
                    endcase
                end
            end
            m_axil_wdata[1:0] = y_meta[1:0];
        end
        else if (state_r == DATA_Z || state_r == RESP_Z || state_r == WAIT_Z) begin
            m_axil_wdata[38] = 1'b0; // not used
            m_axil_wdata[37:36] = 2'd2; // config
            m_axil_wdata[35] = z_meta[31]; // n_row_devided_by_256
            m_axil_wdata[34:28] = z_meta[30:24]; // n_row
            m_axil_wdata[27:26] = z_meta[19] ? 2'd3 : &z_meta[18:17] ? 2'd2 : z_meta[18] ? 2'd1 : 2'd0; // n_col
            m_axil_wdata[25] = PE_ROW[0];
            m_axil_wdata[24:23] = PE_COL[1:0];
            if (PE_ROW == 0) begin
                if (PE_COL == 1) begin
                    case(z_meta[5:2]) 
                        4'b0001: begin
                            m_axil_wdata[22]    = 1'b1; // path 1 valid
                            m_axil_wdata[21:20] = cnt_z_r[0] ? 2'd2 : (~|cnt_z_r[2:1] ? 2'd3 : 2'd1); // 1: from vertical, 0: (1: from self, 0: from right)
                            m_axil_wdata[19:18] = 2'd0; // to left
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r, 1'b0} + cnt_x_write_r + cnt_z_r[2:1] : 
                                                                                                   {cnt_y_write_r, cnt_z_r[0], 6'd0} + {cnt_x_write_r, 2'd0} + {cnt_x_write_r, 1'b0} + {cnt_z_r[2:1], 1'b0})) :
                                                  &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r, 1'b0} + cnt_x_write_r + cnt_z_r[2:1] : 
                                                                                                   {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r, 2'd0} + {cnt_x_write_r, 1'b0} + {cnt_z_r[2:1], 1'b0})) :
                                                  z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r, 1'b0} + cnt_x_write_r + cnt_z_r[2:1] : 
                                                                                                   {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r, 2'd0} + {cnt_x_write_r, 1'b0} + {cnt_z_r[2:1], 1'b0})) :
                                                                   (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r, 1'b0} + cnt_x_write_r + cnt_z_r[2:1] : 
                                                                                                   {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r, 2'd0} + {cnt_x_write_r, 1'b0} + {cnt_z_r[2:1], 1'b0}));
                        end
                        4'b0010: begin
                            m_axil_wdata[22]    = ~|cnt_z_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd3; // from self
                            m_axil_wdata[19:18] = 2'd1; // to right
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0100: begin
                            m_axil_wdata[22]    = ~cnt_z_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = |cnt_z_r[2:1] ? 2'd1 : 2'd3; //1: from right, 0: from self
                            m_axil_wdata[19:18] = 2'd2; // to vertical
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1000: begin
                            m_axil_wdata[22]    = ~|cnt_z_r; // path 1 valid
                            m_axil_wdata[21:20] = 2'd3; // from self
                            m_axil_wdata[19:18] = 2'd1; // to right
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0011: begin
                            if (cnt_x_write_r[0]) begin // BAB
                                m_axil_wdata[22]    = y_only_one_tile ? 1'b0 : ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[0] ? 2'd1 : 2'd2; // 1: from right, 0: from vertical
                                m_axil_wdata[19:18] = 2'd0; // to left
                                m_axil_wdata[17]    = ~|cnt_z_r[1:0]; // path 2 valid
                                m_axil_wdata[16:15] = 2'd3; // from self
                                m_axil_wdata[14:13] = 2'd1; // to right
                                m_axil_wdata[12:2]  = cnt_z_r[1]     ? 11'd0 : // not used
                                                      z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + 2'd2 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + 3'd4)) :
                                                      &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + 2'd2 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + 3'd4)) :
                                                      z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + 2'd2 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + 3'd4)) :
                                                                       (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + 2'd2 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + 3'd4));
                            end
                            else begin // ABA
                                m_axil_wdata[22]    = 1'b1; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[0] ? 2'd2 : (cnt_z_r[1] ? 2'd1 : 2'd3); // 1: from vertical, 0: (1: from right, 0: from self)
                                m_axil_wdata[19:18] = 2'd0; // to left
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0})) :
                                                      &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0})) :
                                                      z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0})) :
                                                                       (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0}));
                            end
                        end
                        4'b0101: begin
                            if (cnt_x_write_r[0]) begin // CAC
                                m_axil_wdata[22]    = y_only_one_tile ? 1'b0 : ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[0] ? 2'd2 : 2'd1; // 1: from vertical, 0: from right
                                m_axil_wdata[19:18] = 2'd0; // to left
                                m_axil_wdata[17]    = ~cnt_z_r[0]; // path 2 valid
                                m_axil_wdata[16:15] = cnt_z_r[1] ? 2'd1 : 2'd3; // 1: from right, 0: from self
                                m_axil_wdata[14:13] = 2'd2; // to vertical
                                m_axil_wdata[12:2]  = cnt_z_r[1]     ? 11'd0 : // not used
                                                      z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + 2'd2 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + 3'd4)) :
                                                      &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + 2'd2 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + 3'd4)) :
                                                      z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + 2'd2 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + 3'd4)) :
                                                                       (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + 2'd2 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + 3'd4));
                            end
                            else begin // ACA
                                m_axil_wdata[22]    = 1'b1; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[0] ? 2'd2 : (cnt_z_r[1] ? 2'd1 : 2'd3); // 1: from vertical, 0: (1: from right, 0: from self)
                                m_axil_wdata[19:18] = 2'd0; // to left
                                m_axil_wdata[17]    = ~|cnt_z_r[1:0]; // path 2 valid
                                m_axil_wdata[16:15] = 2'd1; // from right
                                m_axil_wdata[14:13] = 2'd2; // to vertical
                                m_axil_wdata[12:2]  = z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0})) :
                                                      &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0})) :
                                                      z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0})) :
                                                                       (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0}));
                            end
                        end
                        4'b1001: begin
                            if (cnt_x_write_r[0]) begin // DAD
                                m_axil_wdata[22]    = y_only_one_tile ? 1'b0 : ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = 2'd1; // from right
                                m_axil_wdata[19:18] = 2'd0; // to left
                                m_axil_wdata[17]    = ~|cnt_z_r[1:0]; // path 2 valid
                                m_axil_wdata[16:15] = 2'd3; // from self
                                m_axil_wdata[14:13] = 2'd2; // to vertical
                                m_axil_wdata[12:2]  = cnt_z_r[1]     ? 11'd0 : // not used
                                                      z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + 2'd2 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + 3'd4)) :
                                                      &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + 2'd2 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + 3'd4)) :
                                                      z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + 2'd2 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + 3'd4)) :
                                                                       (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + 2'd2 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + 3'd4));
                            end
                            else begin // ADA
                                m_axil_wdata[22]    = 1'b1; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[0] ? 2'd2 : (cnt_z_r[1] ? 2'd1 : 2'd3); // 1: from vertical, 0: (1: from right, 0: from self)
                                m_axil_wdata[19:18] = 2'd0; // to left
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0})) :
                                                      &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0})) :
                                                      z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0})) :
                                                                       (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0}));
                            end
                        end
                        4'b0110: begin
                            if (cnt_x_write_r[0]) begin // CBC
                                m_axil_wdata[22]    = ~cnt_z_r[0]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd1 : 2'd3; // 1: from right, 0: from self
                                m_axil_wdata[19:18] = 2'd2; // to vertical
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                            else begin // BCB
                                m_axil_wdata[22]    = ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[0] ? 2'd2 : 2'd3; // 1: from vertical, 0: from self
                                m_axil_wdata[19:18] = 2'd1; // to right
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                        end
                        4'b1010: begin
                            if (cnt_x_write_r[0]) begin // DBD
                                m_axil_wdata[22]    = ~|cnt_z_r[1:0]; // path 1 valid
                                m_axil_wdata[21:20] = 2'd3; // from self
                                m_axil_wdata[19:18] = 2'd2; // to vertical
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                            else begin // BDB
                                m_axil_wdata[22]    = ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[0] ? 2'd2 : 2'd3; // 1: from vertical, 0: from self
                                m_axil_wdata[19:18] = 2'd1; // to right
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                        end
                        4'b1100: begin
                            if (cnt_x_write_r[0]) begin // DCD
                                m_axil_wdata[22]    = ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[0] ? 2'd1 : 2'd3; // 1: from right, 0: from self
                                m_axil_wdata[19:18] = cnt_z_r[0] ? 2'd2 : 2'd1; // 1: to vertical, 0: to right
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                            else begin // CDC
                                m_axil_wdata[22]    = ~cnt_z_r[0]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd1 : 2'd3; // 1: from right, 0: from self
                                m_axil_wdata[19:18] = 2'd2; // to vertical
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                        end
                        4'b1111: begin
                            case(cnt_x_write_r[1:0])
                                4'd0: begin // ABC
                                    m_axil_wdata[22]    = 1'b1; // path 1 valid
                                    m_axil_wdata[21:20] = cnt_z_r[0] ? 2'd2 : 2'd3; // 1: from vertical, 0: from self
                                    m_axil_wdata[19:18] = 2'd0; // to left
                                    m_axil_wdata[17]    = 1'b0; // not used
                                    m_axil_wdata[16:15] = 2'd0; // not used
                                    m_axil_wdata[14:13] = 2'd0; // not used
                                    m_axil_wdata[12:2]  = z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0})) :
                                                          &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_y_write_r, cnt_z_r[0], 1'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0})) :
                                                          z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0})) :
                                                                           (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 1'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0}));
                                end
                                4'd1: begin // DAB
                                    m_axil_wdata[22]    = ~x_last; // path 1 valid
                                    m_axil_wdata[21:20] = 2'd1; // from right
                                    m_axil_wdata[19:18] = 2'd0; // to left
                                    m_axil_wdata[17]    = ~cnt_z_r[0]; // path 2 valid
                                    m_axil_wdata[16:15] = 2'd3; // from self
                                    m_axil_wdata[14:13] = 2'd2; // to vertical
                                    m_axil_wdata[12:2]  = x_last         ? 11'd0 : // not used
                                                          z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 1'b1 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 2'd2)) :
                                                          &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_y_write_r, cnt_z_r[0], 1'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 1'b1 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 2'd2)) :
                                                          z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 1'b1 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 2'd2)) :
                                                                           (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 1'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 1'b1 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 2'd2));
                                end
                                4'd2: begin // CDA
                                    m_axil_wdata[22]    = ~x_last; // path 1 valid
                                    m_axil_wdata[21:20] = 2'd1; // from right
                                    m_axil_wdata[19:18] = 2'd0; // to left
                                    m_axil_wdata[17]    = ~cnt_z_r[0]; // path 2 valid
                                    m_axil_wdata[16:15] = 2'd3; // from self
                                    m_axil_wdata[14:13] = 2'd2; // to vertical
                                    m_axil_wdata[12:2]  = x_last         ? 11'd0 : // not used
                                                          z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 2'd2 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 3'd4)) :
                                                          &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_y_write_r, cnt_z_r[0], 1'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 2'd2 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 3'd4)) :
                                                          z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 2'd2 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 3'd4)) :
                                                                           (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 1'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 2'd2 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 3'd4));
                                end
                                4'd3: begin // BCD
                                    m_axil_wdata[22]    = 1'b1; // path 1 valid
                                    m_axil_wdata[21:20] = cnt_z_r[0] ? 2'd2 : 2'd3; // 1: from vertical, 0: from self
                                    m_axil_wdata[19:18] = 2'd1; // to right
                                    m_axil_wdata[17]    = 1'b0; // not used
                                    m_axil_wdata[16:15] = 2'd0; // not used
                                    m_axil_wdata[14:13] = 2'd0; // not used
                                    m_axil_wdata[12:2]  = 11'd0; // not used
                                end
                            endcase
                        end
                    endcase
                end
                else if (PE_COL == 2) begin
                    case(z_meta[5:2]) 
                        4'b0001: begin
                            m_axil_wdata[22]    = |cnt_z_r[2:1] && ~cnt_z_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd3 : 2'd1; // 1: from self, 0: from right
                            m_axil_wdata[19:18] = 2'd0; // to left
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0010: begin
                            m_axil_wdata[22]    = ~cnt_z_r[2] && ~cnt_z_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd3 : 2'd0; // 1: from self, 0: from left
                            m_axil_wdata[19:18] = 2'd1; // to right
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0100: begin
                            m_axil_wdata[22]    = |cnt_z_r[2:1] && ~cnt_z_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd3 : 2'd1; // 1: from self, 0: from right
                            m_axil_wdata[19:18] = 2'd0; // to left
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1000: begin
                            m_axil_wdata[22]    = ~cnt_z_r[2] && ~cnt_z_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd3 : 2'd0; // 1: from self, 0: from left
                            m_axil_wdata[19:18] = 2'd1; // to right
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0011: begin
                            if (cnt_x_write_r[0]) begin // BAB
                                m_axil_wdata[22]    = ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                                m_axil_wdata[19:18] = cnt_z_r[0] ? 2'd0 : 2'd1; // 1: to left, 0: to right
                                m_axil_wdata[17]    = ~|cnt_z_r[1:0]; // path 2 valid
                                m_axil_wdata[16:15] = 2'd3; // from self
                                m_axil_wdata[14:13] = 2'd2; // to vertical
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                            else begin // ABA
                                m_axil_wdata[22]    = ~cnt_z_r[0]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd1 : 2'd3; // 1: from right, 0: from self
                                m_axil_wdata[19:18] = cnt_z_r[1] ? 2'd0 : 2'd1; // 1: to left, 0: to right
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                        end
                        4'b0101: begin
                            if (cnt_x_write_r[0]) begin // CAC
                                m_axil_wdata[22]    = ~cnt_z_r[0]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd1 : 2'd3; // 1: from right, 0: from self
                                m_axil_wdata[19:18] = 2'd0; // to left
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                            else begin // ACA
                                m_axil_wdata[22]    = ~cnt_z_r[0]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd1 : 2'd3; // 1: from right, 0: from self
                                m_axil_wdata[19:18] = 2'd0; // to left
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                        end
                        4'b1001: begin
                            if (cnt_x_write_r[0]) begin // DAD
                                m_axil_wdata[22]    = ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[0] ? 2'd2 : 2'd3; // 1: from vertical, 0: from self
                                m_axil_wdata[19:18] = 2'd0; // to left
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                            else begin // ADA
                                m_axil_wdata[22]    = ~cnt_z_r[0]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd1 : 2'd3; // 1: from right, 0: from self
                                m_axil_wdata[19:18] = cnt_z_r[1] ? 2'd0 : 2'd1; // 1: to left, 0: to right
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                        end
                        4'b0110: begin
                            if (cnt_x_write_r[0]) begin // CBC
                                m_axil_wdata[22]    = ~cnt_z_r[0]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd1 : 2'd3; // 1: from right, 0: from self
                                m_axil_wdata[19:18] = cnt_z_r[1] ? 2'd0 : 2'd1; // 1: to left, 0: to right
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                            else begin // BCB
                                m_axil_wdata[22]    = ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = 2'd0; // from left
                                m_axil_wdata[19:18] = 2'd1; // to right
                                m_axil_wdata[17]    = ~|cnt_z_r[1:0]; // path 2 valid
                                m_axil_wdata[16:15] = 2'd3; // from self
                                m_axil_wdata[14:13] = 2'd2; // to vertical
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                        end
                        4'b1010: begin
                            if (cnt_x_write_r[0]) begin // DBD
                                m_axil_wdata[22]    = ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[0] ? 2'd2 : 2'd3; // 1: from vertical, 0: from self
                                m_axil_wdata[19:18] = 2'd1; // to right
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                            else begin // BDB
                                m_axil_wdata[22]    = ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = 2'd0; // from left
                                m_axil_wdata[19:18] = 2'd1; // to right
                                m_axil_wdata[17]    = ~|cnt_z_r[1:0]; // path 2 valid
                                m_axil_wdata[16:15] = 2'd3; // from self
                                m_axil_wdata[14:13] = 2'd2; // to vertical
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                        end
                        4'b1100: begin
                            if (cnt_x_write_r[0]) begin // DCD
                                m_axil_wdata[22]    = ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                                m_axil_wdata[19:18] = cnt_z_r[0] ? 2'd0 : 2'd1; // 1: to left, 0: to right
                                m_axil_wdata[17]    = ~|cnt_z_r[1:0]; // path 2 valid
                                m_axil_wdata[16:15] = 2'd3; // from self
                                m_axil_wdata[14:13] = 2'd2; // to vertical
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                            else begin // CDC
                                m_axil_wdata[22]    = ~cnt_z_r[0]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd1 : 2'd3; // 1: from right, 0: from self
                                m_axil_wdata[19:18] = cnt_z_r[1] ? 2'd0 : 2'd1; // 1: to left, 0: to right
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                        end
                        4'b1111: begin
                            case(cnt_x_write_r[1:0])
                                4'd0: begin // ABC
                                    m_axil_wdata[22]    = 1'b1; // path 1 valid
                                    m_axil_wdata[21:20] = cnt_z_r[0] ? 2'd2 : 2'd3; // 1: from vertical, 0: from self
                                    m_axil_wdata[19:18] = 2'd1; // to right
                                    m_axil_wdata[17]    = 1'b0; // not used
                                    m_axil_wdata[16:15] = 2'd0; // not used
                                    m_axil_wdata[14:13] = 2'd0; // not used
                                    m_axil_wdata[12:2]  = 11'd0; // not used
                                end
                                4'd1: begin // DAB
                                    m_axil_wdata[22]    = 1'b1; // path 1 valid
                                    m_axil_wdata[21:20] = cnt_z_r[0] ? 2'd2 : 2'd3; // 1: from vertical, 0: from self
                                    m_axil_wdata[19:18] = 2'd0; // to left
                                    m_axil_wdata[17]    = 1'b0; // not used
                                    m_axil_wdata[16:15] = 2'd0; // not used
                                    m_axil_wdata[14:13] = 2'd0; // not used
                                    m_axil_wdata[12:2]  = 11'd0; // not used
                                end
                                4'd2: begin // CDA
                                    m_axil_wdata[22]    = 1'b1; // path 1 valid
                                    m_axil_wdata[21:20] = 2'd1; // from right
                                    m_axil_wdata[19:18] = 2'd0; // to left
                                    m_axil_wdata[17]    = ~cnt_z_r[0]; // path 2 valid
                                    m_axil_wdata[16:15] = 2'd3; // from self
                                    m_axil_wdata[14:13] = 2'd2; // to vertical
                                    m_axil_wdata[12:2]  = 11'd0; // not used
                                end
                                4'd3: begin // BCD
                                    m_axil_wdata[22]    = 1'b1; // path 1 valid
                                    m_axil_wdata[21:20] = 2'd0; // from left
                                    m_axil_wdata[19:18] = 2'd1; // to right
                                    m_axil_wdata[17]    = ~cnt_z_r[0]; // path 2 valid
                                    m_axil_wdata[16:15] = 2'd3; // from self
                                    m_axil_wdata[14:13] = 2'd2; // to vertical
                                    m_axil_wdata[12:2]  = 11'd0; // not used
                                end
                            endcase
                        end
                    endcase
                end
                else begin
                    case(z_meta[5:2]) 
                        4'b0001: begin
                            m_axil_wdata[22]    = cnt_z_r[2] && ~cnt_z_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = 2'd3; // from self
                            m_axil_wdata[19:18] = 2'd0; // to left
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0010: begin
                            m_axil_wdata[22]    = 1'b1; // path 1 valid
                            m_axil_wdata[21:20] = cnt_z_r[0] ? 2'd2 : (cnt_z_r[2] ? 2'd3 : 2'd0); // 1: from vertical, 0: (1: from self, 0: from left)
                            m_axil_wdata[19:18] = 2'd1; // to right
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r, 1'b0} + cnt_x_write_r + cnt_z_r[2:1] : 
                                                                                                   {cnt_y_write_r, cnt_z_r[0], 6'd0} + {cnt_x_write_r, 2'd0} + {cnt_x_write_r, 1'b0} + {cnt_z_r[2:1], 1'b0})) :
                                                  &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r, 1'b0} + cnt_x_write_r + cnt_z_r[2:1] : 
                                                                                                   {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r, 2'd0} + {cnt_x_write_r, 1'b0} + {cnt_z_r[2:1], 1'b0})) :
                                                  z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r, 1'b0} + cnt_x_write_r + cnt_z_r[2:1] : 
                                                                                                   {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r, 2'd0} + {cnt_x_write_r, 1'b0} + {cnt_z_r[2:1], 1'b0})) :
                                                                   (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r, 1'b0} + cnt_x_write_r + cnt_z_r[2:1] : 
                                                                                                   {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r, 2'd0} + {cnt_x_write_r, 1'b0} + {cnt_z_r[2:1], 1'b0}));
                        end
                        4'b0100: begin
                            m_axil_wdata[22]    = cnt_z_r[2] && ~cnt_z_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = 2'd3; // from self
                            m_axil_wdata[19:18] = 2'd0; // to left
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1000: begin
                            m_axil_wdata[22]    = ~cnt_z_r[0];
                            m_axil_wdata[21:20] = cnt_z_r[2] ? 2'd3 : 2'd0; // 1: from self, 0: from left
                            m_axil_wdata[19:18] = 2'd2; // to vertical
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0011: begin
                            if (cnt_x_write_r[0]) begin // BAB
                                m_axil_wdata[22]    = 1'b1; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[0] ? 2'd2 : (cnt_z_r[1] ? 2'd3 : 2'd0); // 1: from vertical, 0: (1: from self, 0: from left)
                                m_axil_wdata[19:18] = 2'd1; // to right
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] + 1'b1 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0} + 2'd2)) :
                                                      &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] + 1'b1 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0} + 2'd2)) :
                                                      z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] + 1'b1 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0} + 2'd2)) :
                                                                       (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] + 1'b1 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0} + 2'd2));
                            end
                            else begin // ABA
                                m_axil_wdata[22]    = ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                                m_axil_wdata[19:18] = 2'd1; // to right
                                m_axil_wdata[17]    = cnt_z_r[1] && ~cnt_z_r[0]; // path 2 valid
                                m_axil_wdata[16:15] = 2'd3; // from self
                                m_axil_wdata[14:13] = 2'd0; // to left
                                m_axil_wdata[12:2]  = cnt_z_r[1]     ? 11'd0 : // not used
                                                      z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0})) :
                                                      &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0})) :
                                                      z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0})) :
                                                                       (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0}));
                            end
                        end
                        4'b0101: begin
                            if (cnt_x_write_r[0]) begin // CAC
                                m_axil_wdata[22]    = cnt_z_r[1] && ~cnt_z_r[0]; // path 1 valid
                                m_axil_wdata[21:20] = 2'd3; // from self
                                m_axil_wdata[19:18] = 2'd0; // to left
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                            else begin // ACA
                                m_axil_wdata[22]    = cnt_z_r[1] && ~cnt_z_r[0]; // path 1 valid
                                m_axil_wdata[21:20] = 2'd3; // from self
                                m_axil_wdata[19:18] = 2'd0; // to left
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                        end
                        4'b1001: begin
                            if (cnt_x_write_r[0]) begin // DAD
                                m_axil_wdata[22]    = cnt_z_r[1] && ~cnt_z_r[0]; // path 1 valid
                                m_axil_wdata[21:20] = 2'd3; // from self
                                m_axil_wdata[19:18] = 2'd2; // to vertical
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                            else begin // ADA
                                m_axil_wdata[22]    = ~cnt_z_r[0]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd3 : 2'd0; // 1: from self, 0: from left
                                m_axil_wdata[19:18] = cnt_z_r[1] ? 2'd0 : 2'd2; // 1: to left, 0: to vertical
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                        end
                        4'b0110: begin
                            if (cnt_x_write_r[0]) begin // CBC
                                m_axil_wdata[22]    = y_only_one_tile ? 1'b0 : ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                                m_axil_wdata[19:18] = 2'd1; // to right
                                m_axil_wdata[17]    = cnt_z_r[1] && ~cnt_z_r[0]; // path 2 valid
                                m_axil_wdata[16:15] = 2'd3; // from self
                                m_axil_wdata[14:13] = 2'd0; // to left
                                m_axil_wdata[12:2]  = cnt_z_r[1]     ? 11'd0 : // not used
                                                      z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + 2'd2 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + 3'd4)) :
                                                      &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + 2'd2 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + 3'd4)) :
                                                      z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + 2'd2 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + 3'd4)) :
                                                                       (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + 2'd2 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + 3'd4));
                            end
                            else begin // BCB
                                m_axil_wdata[22]    = 1'b1; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[1] ? (cnt_z_r[0] ? 2'd2 : 2'd3) : 2'd0; // 1: (1: from vertical, 0: from self), 0: from left
                                m_axil_wdata[19:18] = 2'd1; // to right
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0})) :
                                                      &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0})) :
                                                      z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0})) :
                                                                       (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] :
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0}));
                            end
                        end
                        4'b1010: begin
                            if (cnt_x_write_r[0]) begin // DBD
                                m_axil_wdata[22]    = y_only_one_tile ? 1'b0 : ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = 2'd0; // from left
                                m_axil_wdata[19:18] = 2'd1; // to right
                                m_axil_wdata[17]    = cnt_z_r[1] && ~cnt_z_r[0]; // path 2 valid
                                m_axil_wdata[16:15] = 2'd3; // from self
                                m_axil_wdata[14:13] = 2'd2; // to vertical
                                m_axil_wdata[12:2]  = cnt_z_r[1]     ? 11'd0 : // not used
                                                      z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + 2'd2 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + 3'd4)) :
                                                      &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + 2'd2 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + 3'd4)) :
                                                      z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + 2'd2 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + 3'd4)) :
                                                                       (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + 2'd2 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + 3'd4));
                            end
                            else begin // BDB
                                m_axil_wdata[22]    = 1'b1; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[1] ? (cnt_z_r[0] ? 2'd2 : 2'd3) : 2'd0; // 1: (1: from vertical, 0: from self), 0: from left
                                m_axil_wdata[19:18] = 2'd1; // to right
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0})) :
                                                      &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0})) :
                                                      z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0})) :
                                                                       (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] :
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0}));
                            end
                        end
                        4'b1100: begin
                            if (cnt_x_write_r[0]) begin // DCD
                                m_axil_wdata[22]    = ~cnt_z_r[0]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd3 : 2'd0; // 1: from self, 0: from left
                                m_axil_wdata[19:18] = 2'd2; // to vertical
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                            else begin // CDC
                                m_axil_wdata[22]    = ~cnt_z_r[0]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd3 : 2'd0; // 1: from self, 0: from left
                                m_axil_wdata[19:18] = cnt_z_r[1] ? 2'd0 : 2'd2; // 1: to left, 0: to vertical
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                        end
                        4'b1111: begin
                            case(cnt_x_write_r[1:0])
                                4'd0: begin // ABC
                                    m_axil_wdata[22]    = 1'b1; // path 1 valid
                                    m_axil_wdata[21:20] = 2'd0; // from left
                                    m_axil_wdata[19:18] = 2'd1; // to right
                                    m_axil_wdata[17]    = ~cnt_z_r[0]; // path 2 valid
                                    m_axil_wdata[16:15] = 2'd3; // from self
                                    m_axil_wdata[14:13] = 2'd2; // to vertical
                                    m_axil_wdata[12:2]  = z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0})) :
                                                          &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_y_write_r, cnt_z_r[0], 1'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0})) :
                                                          z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0})) :
                                                                           (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 1'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0}));
                                end
                                4'd1: begin // DAB
                                    m_axil_wdata[22]    = ~x_last; // path 1 valid
                                    m_axil_wdata[21:20] = cnt_z_r[0] ? 2'd2 : 2'd3; // 1: from vertical, 0: from self
                                    m_axil_wdata[19:18] = 2'd1; // to right
                                    m_axil_wdata[17]    = 1'b0; // not used
                                    m_axil_wdata[16:15] = 2'd0; // not used
                                    m_axil_wdata[14:13] = 2'd0; // not used
                                    m_axil_wdata[12:2]  = x_last         ? 11'd0 : // not used
                                                          z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 1'b1 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 2'd2)) :
                                                          &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_y_write_r, cnt_z_r[0], 1'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 1'b1 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 2'd2)) :
                                                          z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 1'b1 :
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 2'd2)) :
                                                                           (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 1'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 1'b1 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 2'd2));
                                end
                                4'd2: begin // CDA
                                    m_axil_wdata[22]    = ~x_last; // path 1 valid
                                    m_axil_wdata[21:20] = cnt_z_r[0] ? 2'd2 : 2'd3; // 1: from vertical, 0: from self
                                    m_axil_wdata[19:18] = 2'd0; // to left
                                    m_axil_wdata[17]    = 1'b0; // not used
                                    m_axil_wdata[16:15] = 2'd0; // not used
                                    m_axil_wdata[14:13] = 2'd0; // not used
                                    m_axil_wdata[12:2]  = 11'd0; // not used
                                end
                                4'd3: begin // BCD
                                    m_axil_wdata[22]    = 1'b1; // path 1 valid
                                    m_axil_wdata[21:20] = 2'd0; // from left
                                    m_axil_wdata[19:18] = 2'd1; // to right
                                    m_axil_wdata[17]    = ~cnt_z_r[0]; // path 2 valid
                                    m_axil_wdata[16:15] = 2'd3; // from self
                                    m_axil_wdata[14:13] = 2'd2; // to vertical
                                    m_axil_wdata[12:2]  = z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 2'd2 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 3'd4)) :
                                                          &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_y_write_r, cnt_z_r[0], 1'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 2'd2 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 3'd4)) :
                                                          z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 2'd2 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 3'd4)) :
                                                                           (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 1'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 2'd2 :
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 3'd4));
                                end
                            endcase
                        end
                    endcase
                end
            end
            else begin
                if (PE_COL == 1) begin
                    case(z_meta[5:2]) // synopsys full_case
                        4'b0001: begin
                            m_axil_wdata[22]    = cnt_z_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = |cnt_z_r[2:1] ? 2'd1 : 2'd3; //1: from right, 0: from self
                            m_axil_wdata[19:18] = 2'd2; // to vertical
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0010: begin
                            m_axil_wdata[22]    = cnt_z_r[0] && ~|cnt_z_r[2:1]; // path 1 valid
                            m_axil_wdata[21:20] = 2'd3; // from self
                            m_axil_wdata[19:18] = 2'd1; // to right
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0100: begin
                            m_axil_wdata[22]    = 1'b1; // path 1 valid
                            m_axil_wdata[21:20] = cnt_z_r[0] ? (~|cnt_z_r[2:1] ? 2'd3 : 2'd1) : 2'd2; // 1: (1: from self, 0: from right), 0: from vertical
                            m_axil_wdata[19:18] = 2'd0; // to left
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r, 1'b0} + cnt_x_write_r + cnt_z_r[2:1] : 
                                                                                                   {cnt_y_write_r, cnt_z_r[0], 6'd0} + {cnt_x_write_r, 2'd0} + {cnt_x_write_r, 1'b0} + {cnt_z_r[2:1], 1'b0})) :
                                                  &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r, 1'b0} + cnt_x_write_r + cnt_z_r[2:1] : 
                                                                                                   {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r, 2'd0} + {cnt_x_write_r, 1'b0} + {cnt_z_r[2:1], 1'b0})) :
                                                  z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r, 1'b0} + cnt_x_write_r + cnt_z_r[2:1] : 
                                                                                                   {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r, 2'd0} + {cnt_x_write_r, 1'b0} + {cnt_z_r[2:1], 1'b0})) :
                                                                   (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r, 1'b0} + cnt_x_write_r + cnt_z_r[2:1] : 
                                                                                                   {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r, 2'd0} + {cnt_x_write_r, 1'b0} + {cnt_z_r[2:1], 1'b0}));
                        end
                        4'b1000: begin
                            m_axil_wdata[22]    = cnt_z_r[0] && ~|cnt_z_r[2:1]; // path 1 valid
                            m_axil_wdata[21:20] = 2'd3; // from self
                            m_axil_wdata[19:18] = 2'd1; // to right
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0011: begin
                            if (cnt_x_write_r[0]) begin // BAB
                                m_axil_wdata[22]    = ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = ~cnt_z_r[0] ? 2'd1 : 2'd3; // 1: from right, 0: from self
                                m_axil_wdata[19:18] = ~cnt_z_r[0] ? 2'd2 : 2'd1; // 1: to vertical, 0: to right
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                            else begin // ABA
                                m_axil_wdata[22]    = cnt_z_r[0]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd1 : 2'd3; // 1: from right, 0: from self
                                m_axil_wdata[19:18] = 2'd2; // to vertical
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                        end
                        4'b0101: begin
                            if (cnt_x_write_r[0]) begin // CAC
                                m_axil_wdata[22]    = 1'b1; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[0] ? (cnt_z_r[1] ? 2'd1 : 2'd3) : 2'd2; // 1: (1: from right, 0: from self), 0: from vertical
                                m_axil_wdata[19:18] = 2'd0; // to left
                                m_axil_wdata[17]    = cnt_z_r[0] && ~cnt_z_r[1]; // path 2 valid
                                m_axil_wdata[16:15] = 2'd1; // from right
                                m_axil_wdata[14:13] = 2'd2; // to vertical
                                m_axil_wdata[12:2]  = z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] + 1'b1 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0} + 2'd2)) :
                                                      &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] + 1'b1 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0} + 2'd2)) :
                                                      z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] + 1'b1 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0} + 2'd2)) :
                                                                       (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] + 1'b1 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0} + 2'd2));
                            end
                            else begin // ACA
                                m_axil_wdata[22]    = ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = ~cnt_z_r[0] ? 2'd2 : 2'd1; // 1: from vertical, 0: from right
                                m_axil_wdata[19:18] = 2'd0; // to left
                                m_axil_wdata[17]    = cnt_z_r[0]; // path 2 valid
                                m_axil_wdata[16:15] = cnt_z_r[1] ? 2'd1 : 2'd3; // 1: from right, 0: from self
                                m_axil_wdata[14:13] = 2'd2; // to vertical
                                m_axil_wdata[12:2]  = cnt_z_r[1]     ? 11'd0 : // not used
                                                      z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0})) :
                                                      &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0})) :
                                                      z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0})) :
                                                                       (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0}));
                            end
                        end
                        4'b1001: begin
                            if (cnt_x_write_r[0]) begin // DAD
                                m_axil_wdata[22]    = ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = ~cnt_z_r[0] ? 2'd2 : 2'd3; // 1: from vertical, 0: from self
                                m_axil_wdata[19:18] = 2'd1; // to right
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                            else begin // ADA
                                m_axil_wdata[22]    = cnt_z_r[0]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd1 : 2'd3; // 1: from right, 0: from self
                                m_axil_wdata[19:18] = 2'd2; // to vertical
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                        end
                        4'b0110: begin
                            if (cnt_x_write_r[0]) begin // CBC
                                m_axil_wdata[22]    = 1'b1; // path 1 valid
                                m_axil_wdata[21:20] = ~cnt_z_r[0] ? 2'd2 : (cnt_z_r[1] ? 2'd1 : 2'd3); // 1: from vertical, 0: (1: from right, 0: from self)
                                m_axil_wdata[19:18] = 2'd0; // to left
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] + 1'b1 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0} + 2'd2)) :
                                                      &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] + 1'b1 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0} + 2'd2)) :
                                                      z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] + 1'b1 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0} + 2'd2)) :
                                                                       (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] + 1'b1 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0} + 2'd2));
                            end
                            else begin // BCB
                                m_axil_wdata[22]    = ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = 2'd1; // from right
                                m_axil_wdata[19:18] = 2'd0; // to left
                                m_axil_wdata[17]    = cnt_z_r[0] && ~cnt_z_r[1]; // path 2 valid
                                m_axil_wdata[16:15] = 2'd3; // from self
                                m_axil_wdata[14:13] = 2'd2; // to vertical
                                m_axil_wdata[12:2]  = cnt_z_r[1]     ? 11'd0 : // not used
                                                      z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0})) :
                                                      &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0})) :
                                                      z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0})) :
                                                                       (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0}));
                            end
                        end
                        4'b1010: begin
                            if (cnt_x_write_r[0]) begin // DBD
                                m_axil_wdata[22]    = ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = ~cnt_z_r[0] ? 2'd2 : 2'd3; // 1: from vertical, 0: from self
                                m_axil_wdata[19:18] = 2'd1; // to right
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                            else begin // BDB
                                m_axil_wdata[22]    = cnt_z_r[0] && ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = 2'd3; // from self
                                m_axil_wdata[19:18] = 2'd2; // to vertical
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                        end
                        4'b1100: begin
                            if (cnt_x_write_r[0]) begin // DCD
                                m_axil_wdata[22]    = y_only_one_tile ? 1'b0 : ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = ~cnt_z_r[0] ? 2'd1 : 2'd2; // 1: from right, 0: from vertical
                                m_axil_wdata[19:18] = 2'd0; // to left
                                m_axil_wdata[17]    = cnt_z_r[0] && ~cnt_z_r[1]; // path 2 valid
                                m_axil_wdata[16:15] = 2'd3; // from self
                                m_axil_wdata[14:13] = 2'd1; // to right
                                m_axil_wdata[12:2]  = cnt_z_r[1]     ? 11'd0 : // not used
                                                      z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + 2'd2 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + 3'd4)) :
                                                      &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + 2'd2 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + 3'd4)) :
                                                      z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + 2'd2 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + 3'd4)) :
                                                                       (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + 2'd2 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + 3'd4));
                            end
                            else begin // CDC
                                m_axil_wdata[22]    = 1'b1; // path 1 valid
                                m_axil_wdata[21:20] = ~cnt_z_r[0] ? 2'd2 : (cnt_z_r[1] ? 2'd1 : 2'd3); // 1: from vertical, 0: (1: from right, 0: from self)
                                m_axil_wdata[19:18] = 2'd0; // to left
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0})) :
                                                      &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0})) :
                                                      z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0})) :
                                                                       (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0}));
                            end
                        end
                        4'b1111: begin
                            case(cnt_x_write_r[1:0])
                                2'd0: begin // ABC
                                    m_axil_wdata[22]    = 1'b1; // path 1 valid
                                    m_axil_wdata[21:20] = 2'd1; // from right
                                    m_axil_wdata[19:18] = 2'd0; // to left
                                    m_axil_wdata[17]    = cnt_z_r[0]; // path 2 valid
                                    m_axil_wdata[16:15] = 2'd3; // from self
                                    m_axil_wdata[14:13] = 2'd2; // to vertical
                                    m_axil_wdata[12:2]  = z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0})) :
                                                          &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_y_write_r, cnt_z_r[0], 1'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0})) :
                                                          z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0})) :
                                                                           (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 1'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0}));
                                end
                                2'd1: begin // DAB
                                    m_axil_wdata[22]    = 1'b1; // path 1 valid
                                    m_axil_wdata[21:20] = ~cnt_z_r[0] ? 2'd2 : 2'd3; // 1: from vertical, 0: from self
                                    m_axil_wdata[19:18] = 2'd1; // to right
                                    m_axil_wdata[17]    = 1'b0; // not used
                                    m_axil_wdata[16:15] = 2'd0; // not used
                                    m_axil_wdata[14:13] = 2'd0; // not used
                                    m_axil_wdata[12:2]  = 11'd0; // not used
                                end
                                2'd2: begin // CDA
                                    m_axil_wdata[22]    = 1'b1; // path 1 valid
                                    m_axil_wdata[21:20] = ~cnt_z_r[0] ? 2'd2 : 2'd3; // 1: from vertical, 0: from self
                                    m_axil_wdata[19:18] = 2'd0; // to left
                                    m_axil_wdata[17]    = 1'b0; // not used
                                    m_axil_wdata[16:15] = 2'd0; // not used
                                    m_axil_wdata[14:13] = 2'd0; // not used
                                    m_axil_wdata[12:2]  = z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 1'b1 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 2'd2)) :
                                                          &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_y_write_r, cnt_z_r[0], 1'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 1'b1 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 2'd2)) :
                                                          z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 1'b1 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 2'd2)) :
                                                                           (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 1'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 1'b1 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 2'd2));
                                end
                                2'd3: begin // BCD
                                    m_axil_wdata[22]    = 1'b1; // path 1 valid
                                    m_axil_wdata[21:20] = 2'd1; // from right
                                    m_axil_wdata[19:18] = 2'd0; // to left
                                    m_axil_wdata[17]    = cnt_z_r[0]; // path 2 valid
                                    m_axil_wdata[16:15] = 2'd3; // from self
                                    m_axil_wdata[14:13] = 2'd2; // to vertical
                                    m_axil_wdata[12:2]  = z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 2'd2 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 3'd4)) :
                                                          &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_y_write_r, cnt_z_r[0], 1'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 2'd2 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 3'd4)) :
                                                          z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 2'd2 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 3'd4)) :
                                                                           (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 1'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 2'd2 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 3'd4));
                                end
                            endcase
                        end
                    endcase
                end
                else if (PE_COL == 2) begin
                    case(z_meta[5:2]) 
                        4'b0001: begin
                            m_axil_wdata[22]    = |cnt_z_r[2:1] && cnt_z_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd3 : 2'd1; // 1: from self, 0: from right
                            m_axil_wdata[19:18] = 2'd0; // to left
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0010: begin
                            m_axil_wdata[22]    = ~cnt_z_r[2] && cnt_z_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd3 : 2'd0; // 1: from self, 0: from left
                            m_axil_wdata[19:18] = 2'd1; // to right
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0100: begin
                            m_axil_wdata[22]    = |cnt_z_r[2:1] && cnt_z_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd3 : 2'd1; // 1: from self, 0: from right
                            m_axil_wdata[19:18] = 2'd0; // to left
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1000: begin
                            m_axil_wdata[22]    = ~cnt_z_r[2] && cnt_z_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd3 : 2'd0; // 1: from self, 0: from left
                            m_axil_wdata[19:18] = 2'd1; // to right
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0011: begin
                            if (cnt_x_write_r[0]) begin // BAB
                                m_axil_wdata[22]    = ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = ~cnt_z_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                                m_axil_wdata[19:18] = ~cnt_z_r[0] ? 2'd0 : 2'd1; // 1: to left, 0: to right
                                m_axil_wdata[17]    = cnt_z_r[0] && ~cnt_z_r[1]; // path 2 valid
                                m_axil_wdata[16:15] = 2'd3; // from self
                                m_axil_wdata[14:13] = 2'd2; // to vertical
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                            else begin // ABA
                                m_axil_wdata[22]    = cnt_z_r[0]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd1 : 2'd3; // 1: from right, 0: from self
                                m_axil_wdata[19:18] = cnt_z_r[1] ? 2'd0 : 2'd1; // 1: to left, 0: to right
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                        end
                        4'b0101: begin
                            if (cnt_x_write_r[0]) begin // CAC
                                m_axil_wdata[22]    = cnt_z_r[0]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd1 : 2'd3; // 1: from right, 0: from self
                                m_axil_wdata[19:18] = 2'd0; // to left
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                            else begin // ACA
                                m_axil_wdata[22]    = cnt_z_r[0]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd1 : 2'd3; // 1: from right, 0: from self
                                m_axil_wdata[19:18] = 2'd0; // to left
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                        end
                        4'b1001: begin
                            if (cnt_x_write_r[0]) begin // DAD
                                m_axil_wdata[22]    = ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = 2'd0; // from left
                                m_axil_wdata[19:18] = 2'd1; // to right
                                m_axil_wdata[17]    = cnt_z_r[0] && ~cnt_z_r[1]; // path 2 valid
                                m_axil_wdata[16:15] = 2'd3; // from self
                                m_axil_wdata[14:13] = 2'd2; // to vertical
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                            else begin // ADA
                                m_axil_wdata[22]    = cnt_z_r[0]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd1 : 2'd3; // 1: from right, 0: from self
                                m_axil_wdata[19:18] = cnt_z_r[1] ? 2'd0 : 2'd1; // 1: to left, 0: to right
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                        end
                        4'b0110: begin
                            if (cnt_x_write_r[0]) begin // CBC
                                m_axil_wdata[22]    = cnt_z_r[0]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd1 : 2'd3; // 1: from right, 0: from self
                                m_axil_wdata[19:18] = cnt_z_r[1] ? 2'd0 : 2'd1; // 1: to left, 0: to right
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                            else begin // BCB
                                m_axil_wdata[22]    = ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = ~cnt_z_r[0] ? 2'd2 : 2'd3; // 1: from vertical, 0: from self
                                m_axil_wdata[19:18] = 2'd0; // to left
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                        end
                        4'b1010: begin
                            if (cnt_x_write_r[0]) begin // DBD
                                m_axil_wdata[22]    = ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = 2'd0; // from left
                                m_axil_wdata[19:18] = 2'd1; // to right
                                m_axil_wdata[17]    = cnt_z_r[0] && ~cnt_z_r[1]; // path 2 valid
                                m_axil_wdata[16:15] = 2'd3; // from self
                                m_axil_wdata[14:13] = 2'd2; // to vertical
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                            else begin // BDB
                                m_axil_wdata[22]    = ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = ~cnt_z_r[0] ? 2'd2 : 2'd3; // 1: from vertical, 0: from self
                                m_axil_wdata[19:18] = 2'd1; // to right
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                        end
                        4'b1100: begin
                            if (cnt_x_write_r[0]) begin // DCD
                                m_axil_wdata[22]    = ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = ~cnt_z_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                                m_axil_wdata[19:18] = ~cnt_z_r[0] ? 2'd0 : 2'd1; // 1: to left, 0: to right
                                m_axil_wdata[17]    = cnt_z_r[0] && ~cnt_z_r[1]; // path 2 valid
                                m_axil_wdata[16:15] = 2'd3; // from self
                                m_axil_wdata[14:13] = 2'd2; // to vertical
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                            else begin // CDC
                                m_axil_wdata[22]    = cnt_z_r[0]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd1 : 2'd3; // 1: from right, 0: from self
                                m_axil_wdata[19:18] = cnt_z_r[1] ? 2'd0 : 2'd1; // 1: to left, 0: to right
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                        end
                        4'b1111: begin
                            case(cnt_x_write_r[1:0])
                                4'd0: begin // ABC
                                    m_axil_wdata[22]    = 1'b1; // path 1 valid
                                    m_axil_wdata[21:20] = 2'd1; // from right
                                    m_axil_wdata[19:18] = 2'd0; // to left
                                    m_axil_wdata[17]    = cnt_z_r[0]; // path 2 valid
                                    m_axil_wdata[16:15] = 2'd3; // from self
                                    m_axil_wdata[14:13] = 2'd2; // to vertical
                                    m_axil_wdata[12:2]  = 11'd0; // not used
                                end
                                4'd1: begin // DAB
                                    m_axil_wdata[22]    = 1'b1; // path 1 valid
                                    m_axil_wdata[21:20] = 2'd0; // from left
                                    m_axil_wdata[19:18] = 2'd1; // to right
                                    m_axil_wdata[17]    = cnt_z_r[0]; // path 2 valid
                                    m_axil_wdata[16:15] = 2'd3; // from self
                                    m_axil_wdata[14:13] = 2'd2; // to vertical
                                    m_axil_wdata[12:2]  = 11'd0; // not used
                                end
                                4'd2: begin // CDA
                                    m_axil_wdata[22]    = 1'b1; // path 1 valid
                                    m_axil_wdata[21:20] = ~cnt_z_r[0] ? 2'd2 : 2'd3; // 1: from vertical, 0: from self
                                    m_axil_wdata[19:18] = 2'd1; // to right
                                    m_axil_wdata[17]    = 1'b0; // not used
                                    m_axil_wdata[16:15] = 2'd0; // not used
                                    m_axil_wdata[14:13] = 2'd0; // not used
                                    m_axil_wdata[12:2]  = 11'd0; // not used
                                end
                                4'd3: begin // BCD
                                    m_axil_wdata[22]    = 1'b1; // path 1 valid
                                    m_axil_wdata[21:20] = ~cnt_z_r[0] ? 2'd2 : 2'd3; // 1: from vertical, 0: from self
                                    m_axil_wdata[19:18] = 2'd0; // to left
                                    m_axil_wdata[17]    = 1'b0; // not used
                                    m_axil_wdata[16:15] = 2'd0; // not used
                                    m_axil_wdata[14:13] = 2'd0; // not used
                                    m_axil_wdata[12:2]  = 11'd0; // not used
                                end
                            endcase
                        end
                    endcase
                end
                else begin
                    case(z_meta[5:2]) 
                        4'b0001: begin
                            m_axil_wdata[22]    = cnt_z_r[2] && cnt_z_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = 2'd3; // from self
                            m_axil_wdata[19:18] = 2'd0; // to left
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0010: begin
                            m_axil_wdata[22]    = cnt_z_r[0];
                            m_axil_wdata[21:20] = cnt_z_r[2] ? 2'd3 : 2'd0; // 1: from self, 0: from left
                            m_axil_wdata[19:18] = 2'd2; // to vertical
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b0100: begin
                            m_axil_wdata[22]    = cnt_z_r[2] && cnt_z_r[0]; // path 1 valid
                            m_axil_wdata[21:20] = 2'd3; // from self
                            m_axil_wdata[19:18] = 2'd0; // to left
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = 11'd0; // not used
                        end
                        4'b1000: begin
                            m_axil_wdata[22]    = 1'b1; // path 1 valid
                            m_axil_wdata[21:20] = ~cnt_z_r[0] ? 2'd2 : (cnt_z_r[2] ? 2'd3 : 2'd0); // 1: from vertical, 0: (1: from self, 0: from left)
                            m_axil_wdata[19:18] = 2'd1; // to right
                            m_axil_wdata[17]    = 1'b0; // not used
                            m_axil_wdata[16:15] = 2'd0; // not used
                            m_axil_wdata[14:13] = 2'd0; // not used
                            m_axil_wdata[12:2]  = z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r, 1'b0} + cnt_x_write_r + cnt_z_r[2:1] : 
                                                                                                   {cnt_y_write_r, cnt_z_r[0], 6'd0} + {cnt_x_write_r, 2'd0} + {cnt_x_write_r, 1'b0} + {cnt_z_r[2:1], 1'b0})) :
                                                  &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r, 1'b0} + cnt_x_write_r + cnt_z_r[2:1] : 
                                                                                                   {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r, 2'd0} + {cnt_x_write_r, 1'b0} + {cnt_z_r[2:1], 1'b0})) :
                                                  z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r, 1'b0} + cnt_x_write_r + cnt_z_r[2:1] : 
                                                                                                   {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r, 2'd0} + {cnt_x_write_r, 1'b0} + {cnt_z_r[2:1], 1'b0})) :
                                                                   (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r, 1'b0} + cnt_x_write_r + cnt_z_r[2:1] : 
                                                                                                   {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r, 2'd0} + {cnt_x_write_r, 1'b0} + {cnt_z_r[2:1], 1'b0}));
                        end
                        4'b0011: begin
                            if (cnt_x_write_r[0]) begin // BAB
                                m_axil_wdata[22]    = cnt_z_r[0]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd3 : 2'd0; // 1: from self, 0: from left
                                m_axil_wdata[19:18] = 2'd2; // to vertical
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                            else begin // ABA
                                m_axil_wdata[22]    = cnt_z_r[0]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd3 : 2'd0; // 1: from self, 0: from left
                                m_axil_wdata[19:18] = cnt_z_r[1] ? 2'd0 : 2'd2; // 1: to left, 0: to vertical
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                        end
                        4'b0101: begin
                            if (cnt_x_write_r[0]) begin // CAC
                                m_axil_wdata[22]    = &cnt_z_r[1:0]; // path 1 valid
                                m_axil_wdata[21:20] = 2'd3; // from self
                                m_axil_wdata[19:18] = 2'd0; // to left
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                            else begin // ACA
                                m_axil_wdata[22]    = &cnt_z_r[1:0]; // path 1 valid
                                m_axil_wdata[21:20] = 2'd3; // from self
                                m_axil_wdata[19:18] = 2'd0; // to left
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                        end
                        4'b1001: begin
                            if (cnt_x_write_r[0]) begin // DAD
                                m_axil_wdata[22]    = 1'b1; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[1] ? (~cnt_z_r[0] ? 2'd2 : 2'd3) : 2'd0; // 1: (1: from vertical, 0: from self), 0: from left
                                m_axil_wdata[19:18] = 2'd1; // to right
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] + 1'b1 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0} + 2'd2)) :
                                                      &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] + 1'b1 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0} + 2'd2)) :
                                                      z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] + 1'b1 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0} + 2'd2)) :
                                                                       (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] + 1'b1 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0} + 2'd2));
                            end
                            else begin // ADA
                                m_axil_wdata[22]    = ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = ~cnt_z_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                                m_axil_wdata[19:18] = 2'd1; // to right
                                m_axil_wdata[17]    = &cnt_z_r[1:0]; // path 2 valid
                                m_axil_wdata[16:15] = 2'd3; // from self
                                m_axil_wdata[14:13] = 2'd0; // to left
                                m_axil_wdata[12:2]  = cnt_z_r[1]     ? 11'd0 : // not used
                                                      z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0})) :
                                                      &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0})) :
                                                      z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0})) :
                                                                       (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0}));
                            end
                        end
                        4'b0110: begin
                            if (cnt_x_write_r[0]) begin // CBC
                                m_axil_wdata[22]    = cnt_z_r[0]; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[1] ? 2'd3 : 2'd0; // 1: from self, 0: from left
                                m_axil_wdata[19:18] = cnt_z_r[1] ? 2'd0 : 2'd2; // 1: to left, 0: to vertical
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                            else begin // BCB
                                m_axil_wdata[22]    = &cnt_z_r[1:0]; // path 1 valid
                                m_axil_wdata[21:20] = 2'd3; // from self
                                m_axil_wdata[19:18] = 2'd2; // to vertical
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = 11'd0; // not used
                            end
                        end
                        4'b1010: begin
                            if (cnt_x_write_r[0]) begin // DBD
                                m_axil_wdata[22]    = 1'b1; // path 1 valid
                                m_axil_wdata[21:20] = cnt_z_r[1] ? (~cnt_z_r[0] ? 2'd2 : 2'd3) : 2'd0; // 1: (1: from vertical, 0: from self), 0: from left
                                m_axil_wdata[19:18] = 2'd1; // to right
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] + 1'b1 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0} + 2'd2)) :
                                                      &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] + 1'b1 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0} + 2'd2)) :
                                                      z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] + 1'b1 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0} + 2'd2)) :
                                                                       (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] + 1'b1 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0} + 2'd2));
                            end
                            else begin // BDB
                                m_axil_wdata[22]    = ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = 2'd0; // from left
                                m_axil_wdata[19:18] = 2'd1; // to right
                                m_axil_wdata[17]    = &cnt_z_r[1:0]; // path 2 valid
                                m_axil_wdata[16:15] = 2'd3; // from self
                                m_axil_wdata[14:13] = 2'd2; // to vertical
                                m_axil_wdata[12:2]  = cnt_z_r[1]     ? 11'd0 : // not used
                                                      z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0})) :
                                                      &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0})) :
                                                      z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0})) :
                                                                       (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0}));
                            end
                        end
                        4'b1100: begin
                            if (cnt_x_write_r[0]) begin // DCD
                                m_axil_wdata[22]    = 1'b1; // path 1 valid
                                m_axil_wdata[21:20] = ~cnt_z_r[0] ? 2'd2 : (cnt_z_r[1] ? 2'd3 : 2'd0); // 1: from vertical, 0: (1: from self, 0: from left)
                                m_axil_wdata[19:18] = 2'd1; // to right
                                m_axil_wdata[17]    = 1'b0; // not used
                                m_axil_wdata[16:15] = 2'd0; // not used
                                m_axil_wdata[14:13] = 2'd0; // not used
                                m_axil_wdata[12:2]  = z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] + 1'b1 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0} + 2'd2)) :
                                                      &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] + 1'b1 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0} + 2'd2)) :
                                                      z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] + 1'b1 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0} + 2'd2)) :
                                                                       (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] + cnt_z_r[1] + 1'b1 : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + {cnt_z_r[1], 1'b0} + 2'd2));
                            end
                            else begin // CDC
                                m_axil_wdata[22]    = ~cnt_z_r[1]; // path 1 valid
                                m_axil_wdata[21:20] = ~cnt_z_r[0] ? 2'd2 : 2'd0; // 1: from vertical, 0: from left
                                m_axil_wdata[19:18] = 2'd1; // to right
                                m_axil_wdata[17]    = cnt_z_r[1] && cnt_z_r[0]; // path 2 valid
                                m_axil_wdata[16:15] = 2'd3; // from self
                                m_axil_wdata[14:13] = 2'd0; // to left
                                m_axil_wdata[12:2]  = cnt_z_r[1]     ? 11'd0 : // not used
                                                      z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 5'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0})) :
                                                      &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0})) :
                                                      z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0})) :
                                                                       (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:1], 1'b0} + cnt_x_write_r[3:1] : 
                                                                                                       {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:1], 2'd0} + {cnt_x_write_r[3:1], 1'b0}));
                            end
                        end
                        4'b1111: begin
                            case(cnt_x_write_r[1:0])
                                2'd0: begin // ABC
                                    m_axil_wdata[22]    = 1'b1; // path 1 valid
                                    m_axil_wdata[21:20] = cnt_z_r[0] ? 2'd3 : 2'd2; // 1: from self, 0: from vertical
                                    m_axil_wdata[19:18] = 2'd0; // to left
                                    m_axil_wdata[17]    = 1'b0; // not used
                                    m_axil_wdata[16:15] = 2'd0; // not used
                                    m_axil_wdata[14:13] = 2'd0; // not used
                                    m_axil_wdata[12:2]  = 11'd0; // not used
                                end
                                2'd1: begin // DAB
                                    m_axil_wdata[22]    = 1'b1; // path 1 valid
                                    m_axil_wdata[21:20] = 2'd0; // from left
                                    m_axil_wdata[19:18] = 2'd1; // to right
                                    m_axil_wdata[17]    = ~x_last && cnt_z_r[0]; // path 2 valid
                                    m_axil_wdata[16:15] = 2'd3; // from self
                                    m_axil_wdata[14:13] = 2'd2; // to vertical
                                    m_axil_wdata[12:2]  = z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0})) :
                                                          &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_y_write_r, cnt_z_r[0], 1'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0})) :
                                                          z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0})) :
                                                                           (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 1'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0}));
                                end
                                2'd2: begin // CDA
                                    m_axil_wdata[22]    = 1'b1; // path 1 valid
                                    m_axil_wdata[21:20] = 2'd0; // from left
                                    m_axil_wdata[19:18] = 2'd1; // to right
                                    m_axil_wdata[17]    = ~x_last && cnt_z_r[0]; // path 2 valid
                                    m_axil_wdata[16:15] = 2'd3; // from self
                                    m_axil_wdata[14:13] = 2'd2; // to vertical
                                    m_axil_wdata[12:2]  = z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 1'b1 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 2'd2)) :
                                                          &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_y_write_r, cnt_z_r[0], 1'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 1'b1 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 2'd2)) :
                                                          z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 1'b1: 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 2'd2)) :
                                                                           (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 1'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 1'b1 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 2'd2));
                                end
                                2'd3: begin // BCD
                                    m_axil_wdata[22]    = 1'b1; // path 1 valid
                                    m_axil_wdata[21:20] = cnt_z_r[0] ? 2'd3 : 2'd2; // 1: from self, 0: from vertical
                                    m_axil_wdata[19:18] = 2'd1; // to right
                                    m_axil_wdata[17]    = 1'b0; // not used
                                    m_axil_wdata[16:15] = 2'd0; // not used
                                    m_axil_wdata[14:13] = 2'd0; // not used
                                    m_axil_wdata[12:2]  = z_meta[19]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 2'd2 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 4'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 3'd4)) :
                                                          &z_meta[18:17] ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_y_write_r, cnt_z_r[0], 1'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 2'd2 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 3'd4)) :
                                                          z_meta[18]     ? (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 2'd2 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 3'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 3'd4)) :
                                                                           (z_meta[16:6] + (|z_meta[1:0] ? {cnt_y_write_r, cnt_z_r[0], 1'd0} + {cnt_x_write_r[3:2], 1'b0} + cnt_x_write_r[3:2] + 2'd2 : 
                                                                                                           {cnt_y_write_r, cnt_z_r[0], 2'd0} + {cnt_x_write_r[3:2], 2'd0} + {cnt_x_write_r[3:2], 1'b0} + 3'd4));
                                end
                            endcase
                        end
                    endcase
                end
            end
            m_axil_wdata[1:0] = z_meta[1:0];
        end
        else if (state_r == CALC || state_r == RESP_C || state_r == WAIT_C) begin
            m_axil_wdata[38] = 1'b1; // start calculation
            m_axil_wdata[37:0] = 38'd0; // not used
        end
    end

    always_ff @(posedge clk_ctrl_bus or negedge rst_n) begin
        if (!rst_n) begin
            state_r <= IDLE;
            cnt_x_read_r <= 1'b0;
            cnt_y_read_r <= 2'd0;
            cnt_k_r <= 5'd0;
            cnt_z_r <= 3'd0;
            cnt_x_write_r <= 4'd0;
            cnt_y_write_r <= 4'd0;
        end
        else begin
            state_r <= state_w;
            cnt_x_read_r <= cnt_x_read_w;
            cnt_y_read_r <= cnt_y_read_w;
            cnt_k_r <= cnt_k_w;
            cnt_z_r <= cnt_z_w;
            cnt_x_write_r <= cnt_x_write_w;
            cnt_y_write_r <= cnt_y_write_w;
        end
    end

endmodule