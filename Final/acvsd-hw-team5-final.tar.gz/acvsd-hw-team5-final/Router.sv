module Router #(
    parameter AXI_ID_W = 4, AXI_ADDR_W = 32, AXI_LEN_W = 8, AXI_SIZE_W = 3, 
              AXI_BURST_W = 2, AXI_DATA_W = 128, AXI_STRB_W = 16, AXI_RESP_W = 2
) (
    input  logic clk_data_bus,        
    input  logic rst_n,

    // -------------------------------------------------------------------------
    // AXI4-Full slave left — flat ports
    // -------------------------------------------------------------------------
    input  logic [   AXI_ID_W-1:0]  s_axi_left_awid,
    input  logic [ AXI_ADDR_W-1:0]  s_axi_left_awaddr,
    input  logic [  AXI_LEN_W-1:0]  s_axi_left_awlen,
    input  logic [ AXI_SIZE_W-1:0]  s_axi_left_awsize,
    input  logic [AXI_BURST_W-1:0]  s_axi_left_awburst,
    input  logic                    s_axi_left_awvalid,
    output logic                    s_axi_left_awready,
    input  logic [AXI_DATA_W-1:0]   s_axi_left_wdata,
    input  logic [AXI_STRB_W-1:0]   s_axi_left_wstrb,
    input  logic                    s_axi_left_wlast,
    input  logic                    s_axi_left_wvalid,
    output logic                    s_axi_left_wready,
    output logic [AXI_ID_W-1:0]     s_axi_left_bid,
    output logic [AXI_RESP_W-1:0]   s_axi_left_bresp,
    output logic                    s_axi_left_bvalid,
    input  logic                    s_axi_left_bready,
    input  logic [AXI_ID_W-1:0]     s_axi_left_arid,
    input  logic [AXI_ADDR_W-1:0]   s_axi_left_araddr,
    input  logic [AXI_LEN_W-1:0]    s_axi_left_arlen,
    input  logic [AXI_SIZE_W-1:0]   s_axi_left_arsize,
    input  logic [AXI_BURST_W-1:0]  s_axi_left_arburst,
    input  logic                    s_axi_left_arvalid,
    output logic                    s_axi_left_arready,
    output logic [AXI_ID_W-1:0]     s_axi_left_rid,
    output logic [AXI_DATA_W-1:0]   s_axi_left_rdata,
    output logic [AXI_RESP_W-1:0]   s_axi_left_rresp,
    output logic                    s_axi_left_rlast,
    output logic                    s_axi_left_rvalid,
    input  logic                    s_axi_left_rready,

    // -------------------------------------------------------------------------
    // AXI4-Full slave right — flat ports
    // -------------------------------------------------------------------------
    input  logic [AXI_ID_W-1:0]     s_axi_right_awid,
    input  logic [AXI_ADDR_W-1:0]   s_axi_right_awaddr,
    input  logic [AXI_LEN_W-1:0]    s_axi_right_awlen,
    input  logic [AXI_SIZE_W-1:0]   s_axi_right_awsize,
    input  logic [AXI_BURST_W-1:0]  s_axi_right_awburst,
    input  logic                    s_axi_right_awvalid,
    output logic                    s_axi_right_awready,
    input  logic [AXI_DATA_W-1:0]   s_axi_right_wdata,
    input  logic [AXI_STRB_W-1:0]   s_axi_right_wstrb,
    input  logic                    s_axi_right_wlast,
    input  logic                    s_axi_right_wvalid,
    output logic                    s_axi_right_wready,
    output logic [AXI_ID_W-1:0]     s_axi_right_bid,
    output logic [AXI_RESP_W-1:0]   s_axi_right_bresp,
    output logic                    s_axi_right_bvalid,
    input  logic                    s_axi_right_bready,
    input  logic [AXI_ID_W-1:0]     s_axi_right_arid,
    input  logic [AXI_ADDR_W-1:0]   s_axi_right_araddr,
    input  logic [AXI_LEN_W-1:0]    s_axi_right_arlen,
    input  logic [AXI_SIZE_W-1:0]   s_axi_right_arsize,
    input  logic [AXI_BURST_W-1:0]  s_axi_right_arburst,
    input  logic                    s_axi_right_arvalid,
    output logic                    s_axi_right_arready,
    output logic [AXI_ID_W-1:0]     s_axi_right_rid,
    output logic [AXI_DATA_W-1:0]   s_axi_right_rdata,
    output logic [AXI_RESP_W-1:0]   s_axi_right_rresp,
    output logic                    s_axi_right_rlast,
    output logic                    s_axi_right_rvalid,
    input  logic                    s_axi_right_rready,

    // -------------------------------------------------------------------------
    // AXI4-Full slave vertical — flat ports
    // -------------------------------------------------------------------------
    input  logic [AXI_ID_W-1:0]     s_axi_vertical_awid,
    input  logic [AXI_ADDR_W-1:0]   s_axi_vertical_awaddr,
    input  logic [AXI_LEN_W-1:0]    s_axi_vertical_awlen,
    input  logic [AXI_SIZE_W-1:0]   s_axi_vertical_awsize,
    input  logic [AXI_BURST_W-1:0]  s_axi_vertical_awburst,
    input  logic                    s_axi_vertical_awvalid,
    output logic                    s_axi_vertical_awready,
    input  logic [AXI_DATA_W-1:0]   s_axi_vertical_wdata,
    input  logic [AXI_STRB_W-1:0]   s_axi_vertical_wstrb,
    input  logic                    s_axi_vertical_wlast,
    input  logic                    s_axi_vertical_wvalid,
    output logic                    s_axi_vertical_wready,
    output logic [AXI_ID_W-1:0]     s_axi_vertical_bid,
    output logic [AXI_RESP_W-1:0]   s_axi_vertical_bresp,
    output logic                    s_axi_vertical_bvalid,
    input  logic                    s_axi_vertical_bready,
    input  logic [AXI_ID_W-1:0]     s_axi_vertical_arid,
    input  logic [AXI_ADDR_W-1:0]   s_axi_vertical_araddr,
    input  logic [AXI_LEN_W-1:0]    s_axi_vertical_arlen,
    input  logic [AXI_SIZE_W-1:0]   s_axi_vertical_arsize,
    input  logic [AXI_BURST_W-1:0]  s_axi_vertical_arburst,
    input  logic                    s_axi_vertical_arvalid,
    output logic                    s_axi_vertical_arready,
    output logic [AXI_ID_W-1:0]     s_axi_vertical_rid,
    output logic [AXI_DATA_W-1:0]   s_axi_vertical_rdata,
    output logic [AXI_RESP_W-1:0]   s_axi_vertical_rresp,
    output logic                    s_axi_vertical_rlast,
    output logic                    s_axi_vertical_rvalid,
    input  logic                    s_axi_vertical_rready,

    // -------------------------------------------------------------------------
    // AXI4-Full master left — flat ports
    // -------------------------------------------------------------------------
    output logic [AXI_ID_W-1:0]     m_axi_left_awid,
    output logic [AXI_ADDR_W-1:0]   m_axi_left_awaddr,
    output logic [AXI_LEN_W-1:0]    m_axi_left_awlen,
    output logic [AXI_SIZE_W-1:0]   m_axi_left_awsize,
    output logic [AXI_BURST_W-1:0]  m_axi_left_awburst,
    output logic                    m_axi_left_awvalid,
    input  logic                    m_axi_left_awready,
    output logic [AXI_DATA_W-1:0]   m_axi_left_wdata,
    output logic [AXI_STRB_W-1:0]   m_axi_left_wstrb,
    output logic                    m_axi_left_wlast,
    output logic                    m_axi_left_wvalid,
    input  logic                    m_axi_left_wready,
    input  logic [AXI_ID_W-1:0]     m_axi_left_bid,
    input  logic [AXI_RESP_W-1:0]   m_axi_left_bresp,
    input  logic                    m_axi_left_bvalid,
    output logic                    m_axi_left_bready,
    output logic [AXI_ID_W-1:0]     m_axi_left_arid,
    output logic [AXI_ADDR_W-1:0]   m_axi_left_araddr,
    output logic [AXI_LEN_W-1:0]    m_axi_left_arlen,
    output logic [AXI_SIZE_W-1:0]   m_axi_left_arsize,
    output logic [AXI_BURST_W-1:0]  m_axi_left_arburst,
    output logic                    m_axi_left_arvalid,
    input  logic                    m_axi_left_arready,
    input  logic [AXI_ID_W-1:0]     m_axi_left_rid,
    input  logic [AXI_DATA_W-1:0]   m_axi_left_rdata,
    input  logic [AXI_RESP_W-1:0]   m_axi_left_rresp,
    input  logic                    m_axi_left_rlast,
    input  logic                    m_axi_left_rvalid,
    output logic                    m_axi_left_rready,

    // -------------------------------------------------------------------------
    // AXI4-Full master right — flat ports
    // -------------------------------------------------------------------------
    output logic [AXI_ID_W-1:0]     m_axi_right_awid,
    output logic [AXI_ADDR_W-1:0]   m_axi_right_awaddr,
    output logic [AXI_LEN_W-1:0]    m_axi_right_awlen,
    output logic [AXI_SIZE_W-1:0]   m_axi_right_awsize,
    output logic [AXI_BURST_W-1:0]  m_axi_right_awburst,
    output logic                    m_axi_right_awvalid,
    input  logic                    m_axi_right_awready,
    output logic [AXI_DATA_W-1:0]   m_axi_right_wdata,
    output logic [AXI_STRB_W-1:0]   m_axi_right_wstrb,
    output logic                    m_axi_right_wlast,
    output logic                    m_axi_right_wvalid,
    input  logic                    m_axi_right_wready,
    input  logic [AXI_ID_W-1:0]     m_axi_right_bid,
    input  logic [AXI_RESP_W-1:0]   m_axi_right_bresp,
    input  logic                    m_axi_right_bvalid,
    output logic                    m_axi_right_bready,
    output logic [AXI_ID_W-1:0]     m_axi_right_arid,
    output logic [AXI_ADDR_W-1:0]   m_axi_right_araddr,
    output logic [AXI_LEN_W-1:0]    m_axi_right_arlen,
    output logic [AXI_SIZE_W-1:0]   m_axi_right_arsize,
    output logic [AXI_BURST_W-1:0]  m_axi_right_arburst,
    output logic                    m_axi_right_arvalid,
    input  logic                    m_axi_right_arready,
    input  logic [AXI_ID_W-1:0]     m_axi_right_rid,
    input  logic [AXI_DATA_W-1:0]   m_axi_right_rdata,
    input  logic [AXI_RESP_W-1:0]   m_axi_right_rresp,
    input  logic                    m_axi_right_rlast,
    input  logic                    m_axi_right_rvalid,
    output logic                    m_axi_right_rready,

    // -------------------------------------------------------------------------
    // AXI4-Full master vertical — flat ports
    // -------------------------------------------------------------------------
    output logic [AXI_ID_W-1:0]     m_axi_vertical_awid,
    output logic [AXI_ADDR_W-1:0]   m_axi_vertical_awaddr,
    output logic [AXI_LEN_W-1:0]    m_axi_vertical_awlen,
    output logic [AXI_SIZE_W-1:0]   m_axi_vertical_awsize,
    output logic [AXI_BURST_W-1:0]  m_axi_vertical_awburst,
    output logic                    m_axi_vertical_awvalid,
    input  logic                    m_axi_vertical_awready,
    output logic [AXI_DATA_W-1:0]   m_axi_vertical_wdata,
    output logic [AXI_STRB_W-1:0]   m_axi_vertical_wstrb,
    output logic                    m_axi_vertical_wlast,
    output logic                    m_axi_vertical_wvalid,
    input  logic                    m_axi_vertical_wready,
    input  logic [AXI_ID_W-1:0]     m_axi_vertical_bid,
    input  logic [AXI_RESP_W-1:0]   m_axi_vertical_bresp,
    input  logic                    m_axi_vertical_bvalid,
    output logic                    m_axi_vertical_bready,
    output logic [AXI_ID_W-1:0]     m_axi_vertical_arid,
    output logic [AXI_ADDR_W-1:0]   m_axi_vertical_araddr,
    output logic [AXI_LEN_W-1:0]    m_axi_vertical_arlen,
    output logic [AXI_SIZE_W-1:0]   m_axi_vertical_arsize,
    output logic [AXI_BURST_W-1:0]  m_axi_vertical_arburst,
    output logic                    m_axi_vertical_arvalid,
    input  logic                    m_axi_vertical_arready,
    input  logic [AXI_ID_W-1:0]     m_axi_vertical_rid,
    input  logic [AXI_DATA_W-1:0]   m_axi_vertical_rdata,
    input  logic [AXI_RESP_W-1:0]   m_axi_vertical_rresp,
    input  logic                    m_axi_vertical_rlast,
    input  logic                    m_axi_vertical_rvalid,
    output logic                    m_axi_vertical_rready,

    output logic                    interrupt_router,

    //MAC
    output logic [1:0]              matrix_type_mac,
    output logic [1:0]              dtype_mac,
    output logic [1:0]              col_x_mac,

    output logic                    X_read_start,
    output logic                    Y_read_start,
    output logic [127:0]            XY_data,
    output logic                    XY_valid,
    output logic                    XY_read_finish,

    output logic                    Z_calc_start,
    output logic                    Z_read_start,
    input  logic [255:0]            Z_data,
    input  logic                    Z_valid,
    input  logic                    Z_calc_finish,
    input  logic                    Z_read_finish,

    output  logic                   sram_X_en_router,      //use X as the buffer for Z from neighbor
    output  logic [  6:0]           A_X_router,
    output  logic [  1:0]           CEB_X_router,
    output  logic [  1:0]           WEB_X_router,
    output  logic [127:0]           D_X_router, 
    input   logic [127:0]           Q_X_router,

    output  logic                   sram_Z_en_router,       
    output  logic [  6:0]           A_Z_router,
    output  logic [  3:0]           CEB_Z_router,

    //CONFIG FIFO
    output logic                    pop_n_router,
    input  logic                    empty_router,
    input  logic [          38:0]   rdata_router
);
localparam S_IDLE           = 4'd0;
localparam S_CONFIG         = 4'd1;
localparam S_WAIT_CONFIG    = 4'd2; 
localparam S_AR_XY          = 4'd3;
localparam S_R_XY           = 4'd4; //read memory transfer to neighbor and/or self
localparam S_RECEIVE_XY     = 4'd5; //receive XY from neighbor
localparam S_CALC_Z         = 4'd6; //wait for Z calculation
localparam S_READ_WAIT_Z    = 4'd7; //doing the jobs of S_READ_Z and S_WAIT_Z simultaneously
localparam S_READ_Z         = 4'd8; //read Z from MAC, convert and send to neighbor
localparam S_WAIT_Z         = 4'd9; //wait Z from neighbor and save to SRAM
localparam S_AW_Z           = 4'd10; 
localparam S_W_Z            = 4'd11; //write data to memory from self (SRAM Z) or neighbor (stored in SRAM X)
localparam S_SRAM_DELAY     = 4'd12; //delay state to read data from SRAM, 2 cycles, first cycle: pull CEB low, second cycle: correct data on SRAM Q output
logic [3:0] state, state_next;
logic state_IDLE, state_CONFIG, state_WAIT_CONFIG, state_AR_XY, state_R_XY;
logic state_RECEIVE_XY, state_CALC_Z, state_READ_WAIT_Z, state_READ_Z, state_WAIT_Z;
logic state_AW_Z, state_W_Z, state_SRAM_DELAY;
assign state_IDLE           = (state == S_IDLE);
assign state_CONFIG         = (state == S_CONFIG);
assign state_WAIT_CONFIG    = (state == S_WAIT_CONFIG);
assign state_AR_XY          = (state == S_AR_XY);
assign state_R_XY           = (state == S_R_XY);
assign state_RECEIVE_XY     = (state == S_RECEIVE_XY);
assign state_CALC_Z         = (state == S_CALC_Z);
assign state_READ_WAIT_Z    = (state == S_READ_WAIT_Z);
assign state_READ_Z         = (state == S_READ_Z);
assign state_WAIT_Z         = (state == S_WAIT_Z);
assign state_AW_Z           = (state == S_AW_Z);
assign state_W_Z            = (state == S_W_Z);
assign state_SRAM_DELAY     = (state == S_SRAM_DELAY);

//AXI left master (read)
logic [ AXI_ADDR_W-1:0] left_araddr;
logic [  AXI_LEN_W-1:0] left_arlen;
logic                   left_arvalid;
logic                   left_rready;
//AXI left master (write)
logic [AXI_DATA_W-1:0]  left_awaddr;
logic [ AXI_LEN_W-1:0]  left_awlen;
logic [AXI_SIZE_W-1:0]  left_awsize;
logic                   left_awvalid;
logic [AXI_DATA_W-1:0]  left_wdata;
logic [AXI_STRB_W-1:0]  left_wstrb; 
logic                   left_wlast;
logic                   left_wvalid;

//AXI right master (read)
logic [ AXI_ADDR_W-1:0] right_araddr;
logic [  AXI_LEN_W-1:0] right_arlen;
logic                   right_arvalid;
logic                   right_rready;
//AXI right master (write)
logic [AXI_DATA_W-1:0]  right_awaddr;
logic [ AXI_LEN_W-1:0]  right_awlen;
logic [AXI_SIZE_W-1:0]  right_awsize;
logic                   right_awvalid;
logic [AXI_DATA_W-1:0]  right_wdata;
logic [AXI_STRB_W-1:0]  right_wstrb; 
logic                   right_wlast;
logic                   right_wvalid;

//AXI vertical master (write)
//logic [AXI_DATA_W-1:0]  vertical_awaddr;
logic [ AXI_LEN_W-1:0]  vertical_awlen;
logic [AXI_SIZE_W-1:0]  vertical_awsize;
logic                   vertical_awvalid;
logic [AXI_DATA_W-1:0]  vertical_wdata;
logic [AXI_STRB_W-1:0]  vertical_wstrb; 
logic                   vertical_wlast;
logic                   vertical_wvalid;

logic           calc_z;         
logic           pe_row;         //0, 1
logic [ 1:0]    pe_col;         //1, 2, 3
logic [ 1:0]    direction_en;   
logic [ 1:0]    from [0:1];     //0:left, 1:right, 2:vertical, 3:self
logic [ 1:0]    to   [0:1];     //0:left, 1:right, 2:vertical, 3:self
logic [ 1:0]    matrix_type;    //0:X, 1:Y, 2:Z
logic           n_row_div;      
logic [ 6:0]    n_row;          //1~127
logic [ 1:0]    n_col;          //0:256, 1:512, 2:768, 3:1024
logic [ 1:0]    dtype;          //0:BF16, 1:FP8-E4M3, 2:FP8-E5M2
logic [10:0]    addr_1kb; 

//floating point conversion
logic [ 7:0] FP32_exp   [0:7];
logic [22:0] FP32_frac  [0:7];
logic        FP32_sign  [0:7];
logic [ 7:0] FP32_NAN;  
logic [15:0] FP32_BF16 [0:7];
logic [ 7:0] FP32_FP8_E5M2 [0:7];
logic signed [8:0] FP8_E5M2_exp_calc [0:7];
logic [ 7:0] FP32_FP8_E4M3 [0:7];
logic signed [8:0] FP8_E4M3_exp_calc [0:7];
logic [127:0] FP_wdata; 

logic [ 6:0] write_z_counter;
logic [ 1:0] sram_counter;  //stay at S_SRAM_DELAY for 2 cycles

//MAC
assign matrix_type_mac = matrix_type;
assign dtype_mac = dtype;
assign col_x_mac = n_col;

logic pe_col_1, pe_col_2, pe_col_3;
assign pe_col_1 = (pe_col == 2'd1);
assign pe_col_2 = (pe_col == 2'd2);
assign pe_col_3 = (pe_col == 2'd3);
logic [1:0] from_left, from_right, from_vertical, from_self; 
logic [1:0] to_left, to_right, to_vertical, to_self;
assign from_left        = {(from[1] == 2'd0), (from[0] == 2'd0)};
assign from_right       = {(from[1] == 2'd1), (from[0] == 2'd1)};
assign from_vertical    = {(from[1] == 2'd2), (from[0] == 2'd2)};
assign from_self        = {(from[1] == 2'd3), (from[0] == 2'd3)};
assign to_left      = {(to[1] == 2'd0), (to[0] == 2'd0)};
assign to_right     = {(to[1] == 2'd1), (to[0] == 2'd1)};
assign to_vertical  = {(to[1] == 2'd2), (to[0] == 2'd2)};
assign to_self      = {(to[1] == 2'd3), (to[0] == 2'd3)};

//read memory and transfer
logic right_read_mem_to_left;
logic right_read_mem_to_vertical;                                            
logic right_read_mem_to_self;                                 
logic left_read_mem_to_right;                                       
logic left_read_mem_to_vertical;                                           
logic left_read_mem_to_self;
assign right_read_mem_to_left = (pe_col_3 & 
                                ((direction_en[0] & from_right[0] & to_left[0]) | 
                                 (direction_en[1] & from_right[1] & to_left[1])));
assign right_read_mem_to_vertical = (pe_col_3 & 
                                    ((direction_en[0] & from_right[0] & to_vertical[0]) | 
                                     (direction_en[1] & from_right[1] & to_vertical[1])));
assign right_read_mem_to_self = (pe_col_3 & 
                                ((direction_en[0] & from_right[0] & to_self[0]) | 
                                 (direction_en[1] & from_right[1] & to_self[1])));
assign left_read_mem_to_right = (pe_col_1 & 
                                ((direction_en[0] & from_left[0] & to_right[0]) | 
                                 (direction_en[1] & from_left[1] & to_right[1])));
assign left_read_mem_to_vertical = (pe_col_1 & 
                                   ((direction_en[0] & from_left[0] & to_vertical[0]) | 
                                    (direction_en[1] & from_left[1] & to_vertical[1])));
assign left_read_mem_to_self = (pe_col_1 & 
                               ((direction_en[0] & from_left[0] & to_self[0]) | 
                                (direction_en[1] & from_left[1] & to_self[1])));
logic read_mem, read_mem_to_self;
assign read_mem = (right_read_mem_to_left | right_read_mem_to_vertical | right_read_mem_to_self | 
                   left_read_mem_to_right | left_read_mem_to_vertical  | left_read_mem_to_self);
assign read_mem_to_self = (right_read_mem_to_self | left_read_mem_to_self);
//write data to memory
logic left_write_mem_from_self;
logic left_write_mem_from_right;
logic left_write_mem_from_vertical;
logic right_write_mem_from_self;
logic right_write_mem_from_left;
logic right_write_mem_from_vertical;
assign left_write_mem_from_self = (pe_col_1 & 
                                  ((direction_en[0] & from_self[0] & to_left[0]) | 
                                   (direction_en[1] & from_self[1] & to_left[1])));
assign left_write_mem_from_right = (pe_col_1 & 
                                   ((direction_en[0] & from_right[0] & to_left[0]) | 
                                    (direction_en[1] & from_right[1] & to_left[1])));
assign left_write_mem_from_vertical = (pe_col_1 & 
                                      ((direction_en[0] & from_vertical[0] & to_left[0]) | 
                                       (direction_en[1] & from_vertical[1] & to_left[1])));
assign right_write_mem_from_self = (pe_col_3 & 
                                   ((direction_en[0] & from_self[0] & to_right[0]) | 
                                    (direction_en[1] & from_self[1] & to_right[1])));
assign right_write_mem_from_left = (pe_col_3 & 
                                   ((direction_en[0] & from_left[0] & to_right[0]) | 
                                    (direction_en[1] & from_left[1] & to_right[1])));
assign right_write_mem_from_vertical = (pe_col_3 & 
                                       ((direction_en[0] & from_vertical[0] & to_right[0]) | 
                                        (direction_en[1] & from_vertical[1] & to_right[1])));
logic write_mem_from_self, write_mem_from_neighbor;
assign write_mem_from_self = (left_write_mem_from_self | right_write_mem_from_self);
assign write_mem_from_neighbor = (left_write_mem_from_right | left_write_mem_from_vertical | 
                                  right_write_mem_from_left | right_write_mem_from_vertical);
//write transfer (does not write to memory, or read from memory)
logic left_to_right;
logic left_to_vertical;
logic left_to_self;
logic right_to_left;
logic right_to_vertical;
logic right_to_self;
logic vertical_to_left;
logic vertical_to_right;
logic vertical_to_self;
logic self_to_left;
logic self_to_right;
logic self_to_vertical;
assign left_to_right = (pe_col_2 & 
                        ((direction_en[0] & from_left[0] & to_right[0]) | 
                         (direction_en[1] & from_left[1] & to_right[1])));
assign left_to_vertical = ((pe_col_2 | pe_col_3) & 
                           ((direction_en[0] & from_left[0] & to_vertical[0]) | 
                            (direction_en[1] & from_left[1] & to_vertical[1])));
assign left_to_self = ((pe_col_2 | pe_col_3) & 
                       ((direction_en[0] & from_left[0] & to_self[0]) | 
                        (direction_en[1] & from_left[1] & to_self[1])));
assign right_to_left = (pe_col_2 & 
                        ((direction_en[0] & from_right[0] & to_left[0]) | 
                         (direction_en[1] & from_right[1] & to_left[1])));
assign right_to_vertical = ((pe_col_1 | pe_col_2) & 
                            ((direction_en[0] & from_right[0] & to_vertical[0]) | 
                             (direction_en[1] & from_right[1] & to_vertical[1])));
assign right_to_self = ((pe_col_1 | pe_col_2) & 
                        ((direction_en[0] & from_right[0] & to_self[0]) | 
                         (direction_en[1] & from_right[1] & to_self[1])));
assign vertical_to_left = ((pe_col_2 | pe_col_3) & 
                           ((direction_en[0] & from_vertical[0] & to_left[0]) | 
                            (direction_en[1] & from_vertical[1] & to_left[1])));
assign vertical_to_right = ((pe_col_1 | pe_col_2) & 
                            ((direction_en[0] & from_vertical[0] & to_right[0]) | 
                             (direction_en[1] & from_vertical[1] & to_right[1])));
assign vertical_to_self = ((pe_col_1 | pe_col_2 | pe_col_3) & 
                           ((direction_en[0] & from_vertical[0] & to_self[0]) | 
                            (direction_en[1] & from_vertical[1] & to_self[1])));
assign self_to_left = ((pe_col_2 | pe_col_3) & 
                       ((direction_en[0] & from_self[0] & to_left[0]) | 
                        (direction_en[1] & from_self[1] & to_left[1])));
assign self_to_right = ((pe_col_1 | pe_col_2) & 
                        ((direction_en[0] & from_self[0] & to_right[0]) | 
                         (direction_en[1] & from_self[1] & to_right[1])));
assign self_to_vertical = ((pe_col_1 | pe_col_2 | pe_col_3) & 
                           ((direction_en[0] & from_self[0] & to_vertical[0]) | 
                            (direction_en[1] & from_self[1] & to_vertical[1])));
logic write_mem_transfer, receive_from_neighbor;
assign write_mem_transfer = (self_to_left | self_to_right | self_to_vertical);
assign receive_from_neighbor = (left_to_self | right_to_self | vertical_to_self); 
//config information
//============calc_z============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) calc_z <= 1'b0;
    else if(state_CONFIG) calc_z <= rdata_router[38];
end
//============pe_row============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) pe_row <= 1'b0;
    else if(state_CONFIG) pe_row <= rdata_router[38] ? pe_row : rdata_router[25];
end
//============pe_col============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) pe_col <= 2'd0;
    else if(state_CONFIG) pe_col <= rdata_router[38] ? pe_col : rdata_router[24:23];
end
//============direction_en============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) direction_en <= 2'b00;
    else if(state_CONFIG) direction_en <= rdata_router[38] ? 2'b00 : {rdata_router[17], rdata_router[22]};
end
//============from============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) begin
        from[0] <= 2'd0;
        from[1] <= 2'd0;
    end
    else if(state_CONFIG) begin
        from[0] <= rdata_router[38] ? from[0] : rdata_router[21:20];
        from[1] <= rdata_router[38] ? from[1] : rdata_router[16:15];
    end
end
//============to============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) begin
        to[0] <= 2'd0;
        to[1] <= 2'd0;
    end
    else if(state_CONFIG) begin
        to[0] <= rdata_router[38] ? to[0] : rdata_router[19:18];
        to[1] <= rdata_router[38] ? to[1] : rdata_router[14:13];
    end
end
//============matrix_type============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) matrix_type <= 2'd0;
    else if(state_CONFIG) matrix_type <= rdata_router[38] ? matrix_type : rdata_router[37:36];
end
//============n_row_div============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) n_row_div <= 1'b0;
    else if(state_CONFIG) n_row_div <= rdata_router[38] ? n_row_div : rdata_router[35];
end
//============n_row============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) n_row <= 7'd0;
    else if(state_CONFIG) n_row <= rdata_router[38] ? n_row : rdata_router[34:28];
end
//============n_col============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) n_col <= 2'd0;
    else if(state_CONFIG) n_col <= rdata_router[38] ? n_col : rdata_router[27:26];
end
//============dtype============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) dtype <= 2'd0;
    else if(state_CONFIG) dtype <= rdata_router[38] ? dtype : rdata_router[1:0];
end
//============addr_1kb============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) addr_1kb <= 11'd0;
    else if(state_CONFIG) addr_1kb <= rdata_router[38] ? addr_1kb : rdata_router[12:2];
end

//============FSM============
logic left_right_ar;
assign left_right_ar = ((m_axi_left_arready  & m_axi_left_arvalid) | 
                        (m_axi_right_arready & m_axi_right_arvalid));
logic left_right_r;
assign left_right_r = ((m_axi_left_rready  & m_axi_left_rvalid  & m_axi_left_rlast) | 
                       (m_axi_right_rready & m_axi_right_rvalid & m_axi_right_rlast));
logic slave_w_finish;
assign slave_w_finish = ((s_axi_left_wready     & s_axi_left_wvalid     & s_axi_left_wlast     & left_to_self    ) | 
                         (s_axi_right_wready    & s_axi_right_wvalid    & s_axi_right_wlast    & right_to_self   ) | 
                         (s_axi_vertical_wready & s_axi_vertical_wvalid & s_axi_vertical_wlast & vertical_to_self));
logic wait_z_finish;
assign wait_z_finish = ((s_axi_left_wready     & s_axi_left_wvalid     & s_axi_left_wlast     & 
                         right_write_mem_from_left) | 
                        (s_axi_right_wready    & s_axi_right_wvalid    & s_axi_right_wlast    & 
                         left_write_mem_from_right) | 
                        (s_axi_vertical_wready & s_axi_vertical_wvalid & s_axi_vertical_wlast & 
                         (left_write_mem_from_vertical | right_write_mem_from_vertical)));
logic left_write_mem, right_write_mem;
logic left_write_addr_finish, right_write_addr_finish;
logic left_mem_received, right_mem_received;
assign left_write_mem = (left_write_mem_from_right | left_write_mem_from_vertical | left_write_mem_from_self);
assign right_write_mem = (right_write_mem_from_left | right_write_mem_from_vertical | right_write_mem_from_self);
assign left_write_addr_finish = (m_axi_left_awvalid & m_axi_left_awready & left_write_mem);
assign right_write_addr_finish = (m_axi_right_awvalid & m_axi_right_awready & right_write_mem);
assign left_mem_received = (m_axi_left_wvalid  & m_axi_left_wready  & left_write_mem);
assign right_mem_received = (m_axi_right_wvalid & m_axi_right_wready & right_write_mem);
always@(*) begin
    case(state)
        S_IDLE:         state_next = (!empty_router) ? S_CONFIG : S_IDLE;
        S_CONFIG:       state_next = S_WAIT_CONFIG;
        S_WAIT_CONFIG:  state_next = calc_z ? S_CALC_Z : 
                                     read_mem ? S_AR_XY : 
                                     receive_from_neighbor ? S_RECEIVE_XY : 
                                     (write_mem_transfer & write_mem_from_neighbor) ? S_READ_WAIT_Z :
                                     write_mem_transfer ? S_READ_Z : 
                                     write_mem_from_neighbor ? S_WAIT_Z : 
                                     write_mem_from_self ? S_AW_Z : S_IDLE;
        S_AR_XY:        state_next = left_right_ar ? S_R_XY : S_AR_XY;
        S_R_XY:         state_next = left_right_r ? S_IDLE : S_R_XY;
        S_CALC_Z:       state_next = Z_calc_finish ? S_IDLE : S_CALC_Z;
        S_RECEIVE_XY:   state_next = slave_w_finish ? S_IDLE : S_RECEIVE_XY;
        S_READ_WAIT_Z:  state_next = ((Z_valid & Z_read_finish) & wait_z_finish) ? S_AW_Z : 
                                     (Z_valid & Z_read_finish) ? S_WAIT_Z : 
                                     wait_z_finish ? S_READ_Z : S_READ_WAIT_Z; 
        S_READ_Z:       state_next = (Z_valid & Z_read_finish) ? (write_mem_from_neighbor ? S_AW_Z : S_IDLE) : S_READ_Z;
        S_WAIT_Z:       state_next = wait_z_finish ? S_AW_Z : S_WAIT_Z;
        S_AW_Z:         state_next = (left_write_addr_finish | right_write_addr_finish) ? S_SRAM_DELAY : S_AW_Z;
        S_SRAM_DELAY:   state_next = ((sram_counter == 2'd2) | ((~|dtype) & (sram_counter == 2'd1))) ? S_W_Z : S_SRAM_DELAY;
        S_W_Z:          state_next = (left_mem_received | right_mem_received) ? 
                                     ((m_axi_left_wlast | m_axi_right_wlast) ? S_IDLE : S_SRAM_DELAY) : S_W_Z; 
        default:        state_next = state;
    endcase
end 
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) state <= S_IDLE;
    else state <= state_next;
end

//============pop_n_router============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) pop_n_router <= 1'b1;
    else pop_n_router <= (!(state_next == S_CONFIG));
end

//============interrupt_router============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) interrupt_router <= 1'b0;
    else if(state_WAIT_CONFIG | state_R_XY   | state_CALC_Z | 
            state_RECEIVE_XY  | state_READ_Z | state_W_Z)
        interrupt_router <= (state_next == S_IDLE);
    else interrupt_router <= 1'b0;
end

//============X_read_start============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) X_read_start <= 1'b0;
    else X_read_start <= ((matrix_type == 2'd0) & 
                          ((state_AR_XY & (state_next == S_R_XY) & read_mem_to_self) | 
                           (state_WAIT_CONFIG & (state_next == S_RECEIVE_XY))));
end
//============Y_read_start============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) Y_read_start <= 1'b0;
    else Y_read_start <= ((matrix_type == 2'd1) & 
                          ((state_AR_XY & (state_next == S_R_XY) & read_mem_to_self) | 
                           (state_WAIT_CONFIG & (state_next == S_RECEIVE_XY))));
end
//============XY_valid============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) XY_valid <= 1'b0;
    else if(state_R_XY) 
        XY_valid <= ((left_read_mem_to_self  & m_axi_left_rvalid  & m_axi_left_rready ) | 
                     (right_read_mem_to_self & m_axi_right_rvalid & m_axi_right_rready));
    else if(state_RECEIVE_XY) 
        XY_valid <= ((left_to_self     & s_axi_left_wvalid     & s_axi_left_wready    ) | 
                     (right_to_self    & s_axi_right_wvalid    & s_axi_right_wready   ) |
                     (vertical_to_self & s_axi_vertical_wvalid & s_axi_vertical_wready));
    else XY_valid <= 1'b0;
end
//============XY_data============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) XY_data <= 128'd0;
    else if(state_R_XY)
        XY_data <= (left_read_mem_to_self  & m_axi_left_rvalid  & m_axi_left_rready ) ? m_axi_left_rdata  :
                   (right_read_mem_to_self & m_axi_right_rvalid & m_axi_right_rready) ? m_axi_right_rdata : XY_data;
    else if(state_RECEIVE_XY)
        XY_data <= (left_to_self     & s_axi_left_wvalid     & s_axi_left_wready    ) ? s_axi_left_wdata  :
                   (right_to_self    & s_axi_right_wvalid    & s_axi_right_wready   ) ? s_axi_right_wdata :
                   (vertical_to_self & s_axi_vertical_wvalid & s_axi_vertical_wready) ? s_axi_vertical_wdata : XY_data;
end
//============XY_read_finish============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) XY_read_finish <= 1'b0;
    else if(state_R_XY) 
        XY_read_finish <= ((left_read_mem_to_self  & m_axi_left_rvalid  & m_axi_left_rready  & m_axi_left_rlast ) | 
                           (right_read_mem_to_self & m_axi_right_rvalid & m_axi_right_rready & m_axi_right_rlast));
    else if(state_RECEIVE_XY) 
        XY_read_finish <= ((left_to_self     & s_axi_left_wvalid     & s_axi_left_wready     & s_axi_left_wlast    ) | 
                           (right_to_self    & s_axi_right_wvalid    & s_axi_right_wready    & s_axi_right_wlast   ) |
                           (vertical_to_self & s_axi_vertical_wvalid & s_axi_vertical_wready & s_axi_vertical_wlast));
    else XY_read_finish <= 1'b0; 
end
//============Z_calc_start============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) Z_calc_start <= 1'b0;
    else Z_calc_start <= (state_WAIT_CONFIG & (state_next == S_CALC_Z));
end
//============Z_read_start============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) Z_read_start <= 1'b0;
    else Z_read_start <= (state_WAIT_CONFIG & 
                         ((state_next == S_READ_WAIT_Z) | (state_next == S_READ_Z)));
end

//SRAM X in MAC
logic z_from_left;
logic z_from_right;
logic z_from_vertical;
assign z_from_left = (s_axi_left_wvalid & s_axi_left_wready & right_write_mem_from_left);
assign z_from_right = (s_axi_right_wvalid & s_axi_right_wready & left_write_mem_from_right);
assign z_from_vertical = (s_axi_vertical_wvalid & s_axi_vertical_wready & 
                         (left_write_mem_from_vertical | right_write_mem_from_vertical));
//============sram_X_en_router============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) sram_X_en_router <= 1'b0;
    else sram_X_en_router <= (((state_next == S_READ_WAIT_Z) | (state_next == S_WAIT_Z    ) | 
                               (state_next == S_AW_Z       ) | (state_next == S_SRAM_DELAY) | 
                               (state_next == S_W_Z        ) | (state_READ_WAIT_Z & (state_next == S_READ_Z))) & 
                               write_mem_from_neighbor);
end
//============A_X_router============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) A_X_router <= 7'd0;
    else if(state_READ_WAIT_Z | state_WAIT_Z)
        A_X_router <= (~&CEB_X_router) ? A_X_router + 7'd1 : A_X_router;
    else if((state_SRAM_DELAY | state_W_Z) & write_mem_from_neighbor) 
        A_X_router <= (~&CEB_X_router) ? A_X_router + 7'd1 : A_X_router;
    else A_X_router <= 7'd0;
end
//============CEB_X_router============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) CEB_X_router <= 2'b11;
    else if(state_READ_WAIT_Z | state_WAIT_Z)
        CEB_X_router <= (z_from_left | z_from_right | z_from_vertical) ? ((~|dtype) ? 2'b00 : 2'b10) : 2'b11;
    else if((((state_AW_Z | state_W_Z) & (state_next == S_SRAM_DELAY)) | 
             (state_SRAM_DELAY & (~|sram_counter) & (|dtype))) & write_mem_from_neighbor)
        CEB_X_router <= (~|dtype) ? 2'b00 : 2'b10;
    else CEB_X_router <= 2'b11;
end
//============WEB_X_router============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) WEB_X_router <= 2'b11;
    else if(state_READ_WAIT_Z | state_WAIT_Z) 
        WEB_X_router <= (z_from_left | z_from_right | z_from_vertical) ? ((~|dtype) ? 2'b00 : 2'b10) : 2'b11;
    else WEB_X_router <= 2'b11;
end
//============D_X_router============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) D_X_router <= 128'd0;
    else if(state_READ_WAIT_Z | state_WAIT_Z)
        D_X_router <= z_from_left     ? s_axi_left_wdata     :
                      z_from_right    ? s_axi_right_wdata    :
                      z_from_vertical ? s_axi_vertical_wdata : D_X_router; 
end
//============sram_Z_en_router============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) sram_Z_en_router <= 1'b0;
    else sram_Z_en_router <= (((state_next == S_SRAM_DELAY) | (state_next == S_W_Z)) & 
                                write_mem_from_self);
end
//============A_Z_router============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) A_Z_router <= 7'b0;
    else if((state_SRAM_DELAY | state_W_Z) & write_mem_from_self) 
        A_Z_router <= (~&CEB_Z_router) ? A_Z_router + 7'd1 : A_Z_router;
    else A_Z_router <= 7'd0;
end
//============CEB_Z_router============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) CEB_Z_router <= 4'b1111;
    else if((((state_AW_Z | state_W_Z) & (state_next == S_SRAM_DELAY)) | 
             (state_SRAM_DELAY & (~|sram_counter) & (|dtype))) & write_mem_from_self)
        CEB_Z_router <= 4'b0000;
    else CEB_Z_router <= 4'b1111;
end
//============write_z_counter============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) write_z_counter <= 7'd0;
    else if(state_W_Z) 
        write_z_counter <= (left_mem_received | right_mem_received) ? 
                           (((|dtype) & (write_z_counter == 7'd63)) ? 7'd0 : write_z_counter + 7'd1) : write_z_counter;
end
//============sram_counter============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) sram_counter <= 2'd0;
    else if(state_SRAM_DELAY) sram_counter <= sram_counter + 2'd1;
    else sram_counter <= 2'd0;
end

//AXI left master
//============left_arid============  
assign m_axi_left_arid = 4'd0;
//============left_araddr============
assign m_axi_left_araddr = left_araddr;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) left_araddr <= 32'd0;
    else if(state_next == S_AR_XY) 
        left_araddr <= {11'd0, addr_1kb, 10'd0};
end
//============left_arlen============  
assign m_axi_left_arlen = left_arlen;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) left_arlen <= 8'd0;
    else if(state_next == S_AR_XY) 
        left_arlen <= (~|dtype) ? 8'd127 : 8'd63;
end
//============left_arsize============    
assign m_axi_left_arsize = 3'd4;
//============left_arburst============    
assign m_axi_left_arburst = 2'b01;
//============left_arvalid============    
assign m_axi_left_arvalid = left_arvalid;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) left_arvalid <= 1'b0;
    else if(state_next == S_AR_XY) 
        left_arvalid <= (left_read_mem_to_right | left_read_mem_to_vertical | left_read_mem_to_self);
    else left_arvalid <= 1'b0;
end
//============left_rready============    
assign m_axi_left_rready = left_rready;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) left_rready <= 1'b0;
    else if(state_next == S_R_XY)
        left_rready <= (left_read_mem_to_right | left_read_mem_to_vertical | left_read_mem_to_self);
end

//left write
//============left_awid============    
assign m_axi_left_awid = 4'b0000;
//============left_awaddr============   
assign m_axi_left_awaddr = left_awaddr;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) left_awaddr <= 32'd0;
    else if(((state_next == S_AW_Z) | (state_next == S_SRAM_DELAY) | (state_next == S_W_Z)) & 
            left_write_mem) begin
        left_awaddr <= {11'd0, addr_1kb, 10'd0};   
    end
    else left_awaddr <= 32'd0;
end
//============left_awlen============   
assign m_axi_left_awlen = left_awlen;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) left_awlen <= 8'd0;
    else if(state_WAIT_CONFIG & (state_next == S_AR_XY) & right_read_mem_to_left)
        left_awlen <= (~|dtype) ? 8'd127 : 8'd63;
    else if(state_WAIT_CONFIG & ((state_next == S_READ_WAIT_Z) | (state_next == S_READ_Z)) & self_to_left)
        left_awlen <= 8'd127;
    else if((state_next == S_AW_Z) & left_write_mem)
        left_awlen <= (~|dtype) ? 8'd127 : 8'd63;
    else left_awlen <= right_to_left    ? s_axi_right_awlen :
                       vertical_to_left ? s_axi_vertical_awlen : left_awlen; 
end
//============left_awsize============  
assign m_axi_left_awsize = left_awsize;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) left_awsize <= 3'd0;
    else if(state_WAIT_CONFIG & (state_next == S_AR_XY) & right_read_mem_to_left)
        left_awsize <= 3'd4;
    else if(state_WAIT_CONFIG & ((state_next == S_READ_WAIT_Z) | (state_next == S_READ_Z)) & self_to_left)
        left_awsize <= (~|dtype) ? 3'd4 : 3'd3;
    else if((state_next == S_AW_Z) & left_write_mem) 
        left_awsize <= 3'd4;
    else left_awsize <= right_to_left    ? s_axi_right_awsize    : 
                        vertical_to_left ? s_axi_vertical_awsize : left_awsize;
end
//============left_awburst============   
assign m_axi_left_awburst = 2'b01;
//============left_awvalid============   
assign m_axi_left_awvalid = left_awvalid;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) left_awvalid <= 1'b0;
    else if((state_WAIT_CONFIG & ( state_next == S_AR_XY                                  ) & right_read_mem_to_left ) | 
            (state_WAIT_CONFIG & ((state_next == S_READ_WAIT_Z) & (state_next == S_READ_Z)) & self_to_left           ) | 
            (                    ( state_next == S_AW_Z                                   ) & left_write_mem         )) begin
        left_awvalid <= 1'b1;
    end
    else left_awvalid <= right_to_left    ? s_axi_right_awvalid :
                         vertical_to_left ? s_axi_vertical_awvalid : 1'b0; 
end
//============left_wdata============   
assign m_axi_left_wdata = left_wdata;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) left_wdata <= 128'd0;
    else if(state_R_XY & right_read_mem_to_left)
        left_wdata <= (m_axi_right_rvalid & m_axi_right_rready) ? m_axi_right_rdata : left_wdata;
    else if((state_READ_WAIT_Z | state_READ_Z) & self_to_left & Z_valid)
        left_wdata <= FP_wdata;
    else if(state_SRAM_DELAY & (sram_counter == 2'd1) & left_write_mem)
        left_wdata <= left_write_mem_from_self ? FP_wdata : Q_X_router;
    else if(state_SRAM_DELAY & (sram_counter == 2'd2) & left_write_mem)
        left_wdata <= left_write_mem_from_self ? {FP_wdata[63:0], left_wdata[63:0]} : {Q_X_router[63:0], left_wdata[63:0]};
    else left_wdata <= right_to_left    ? s_axi_right_wdata : 
                       vertical_to_left ? s_axi_vertical_wdata : left_wdata; 
end
//============left_wstrb============  
assign m_axi_left_wstrb = left_wstrb;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) left_wstrb <= 16'd0;
    else if(state_R_XY & right_read_mem_to_left) 
        left_wstrb <= 16'hFFFF;
    else if((state_READ_WAIT_Z | state_READ_Z) & self_to_left)
        left_wstrb <= (~|dtype) ? 16'hFFFF : 16'h00FF;
    else if((state_next == S_W_Z) & left_write_mem)
        left_wstrb <= 16'hFFFF;
    else left_wstrb <= right_to_left    ? s_axi_right_wstrb :
                       vertical_to_left ? s_axi_vertical_wstrb : left_wstrb;
end
//============left_wlast============   
assign m_axi_left_wlast = left_wlast;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) left_wlast <= 1'b0;
    else if(state_R_XY & right_read_mem_to_left) 
        left_wlast <= (m_axi_right_rvalid & m_axi_right_rready & m_axi_right_rlast);
    else if((state_READ_WAIT_Z | state_READ_Z) & self_to_left)
        left_wlast <= (Z_valid & Z_read_finish);
    else if((state_next == S_W_Z) & left_write_mem) 
        left_wlast <= (((~|dtype) & (&write_z_counter)) | ((|dtype) & (&write_z_counter[5:0])));
    else left_wlast <= right_to_left    ? s_axi_right_wlast :
                       vertical_to_left ? s_axi_vertical_wlast : 1'b0;
    
end
//============left_wvalid============   
assign m_axi_left_wvalid = left_wvalid;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) left_wvalid <= 1'b0;
    else if(state_R_XY & right_read_mem_to_left)
        left_wvalid <= (m_axi_right_rvalid & m_axi_right_rready);
    else if((state_READ_WAIT_Z | state_READ_Z) & self_to_left)
        left_wvalid <= Z_valid;
    else if((state_next == S_W_Z) & left_write_mem)
        left_wvalid <= 1'b1;
    else left_wvalid <= right_to_left    ? s_axi_right_wvalid :
                        vertical_to_left ? s_axi_vertical_wvalid : 1'b0;
end
//============left_bready============   
assign m_axi_left_bready = 1'b1;

//AXI right master
//============right_arid============  
assign m_axi_right_arid = 4'd0;
//============right_araddr============
assign m_axi_right_araddr = right_araddr;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) right_araddr <= 32'd0;
    else if(state_next == S_AR_XY) 
        right_araddr <= {11'd0, addr_1kb, 10'd0};
end
//============right_arlen============  
assign m_axi_right_arlen = right_arlen;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) right_arlen <= 8'd0;
    else if(state_next == S_AR_XY) 
        right_arlen <= (~|dtype) ? 8'd127 : 8'd63;
end
//============right_arsize============    
assign m_axi_right_arsize = 3'd4;
//============right_arburst============    
assign m_axi_right_arburst = 2'b01;
//============right_arvalid============    
assign m_axi_right_arvalid = right_arvalid;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) right_arvalid <= 1'b0;
    else if(state_next == S_AR_XY)
        right_arvalid <= (right_read_mem_to_left | right_read_mem_to_vertical | right_read_mem_to_self);
    else right_arvalid <= 1'b0;
end
//============right_rready============    
assign m_axi_right_rready = right_rready;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) right_rready <= 1'b0;
    else if(state_next == S_R_XY)
        right_rready <= (right_read_mem_to_left | right_read_mem_to_vertical | right_read_mem_to_self);
end

//right write
//============right_awid============    
assign m_axi_right_awid = 4'b0000;
//============right_awaddr============   
assign m_axi_right_awaddr = right_awaddr;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) right_awaddr <= 32'd0;
    else if(((state_next == S_AW_Z) | (state_next == S_SRAM_DELAY) | (state_next == S_W_Z)) & 
              right_write_mem) begin
        right_awaddr <= {11'd0, addr_1kb, 10'd0};   
    end
    else right_awaddr <= 32'd0;
end
//============right_awlen============   
assign m_axi_right_awlen = right_awlen;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) right_awlen <= 8'd0;
    else if(state_WAIT_CONFIG & (state_next == S_AR_XY) & left_read_mem_to_right) 
        right_awlen <= (~|dtype) ? 8'd127 : 8'd63;
    else if(state_WAIT_CONFIG & ((state_next == S_READ_WAIT_Z) | (state_next == S_READ_Z)) & self_to_right)
        right_awlen <= 8'd127;
    else if((state_next == S_AW_Z) & right_write_mem)
        right_awlen <= (~|dtype) ? 8'd127 : 8'd63;
    else right_awlen <= left_to_right     ? s_axi_left_awlen :
                        vertical_to_right ? s_axi_vertical_awlen : right_awlen;
end
//============right_awsize============   
assign m_axi_right_awsize = right_awsize;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) right_awsize <= 3'd0;
    else if(state_WAIT_CONFIG & (state_next == S_AR_XY) & left_read_mem_to_right)
        right_awsize <= 3'd4;
    else if(state_WAIT_CONFIG & ((state_next == S_READ_WAIT_Z) | (state_next == S_READ_Z)) & self_to_right)
        right_awsize <= (~|dtype) ? 3'd4 : 3'd3;
    else if((state_next == S_AW_Z) & right_write_mem)
        right_awsize <= 3'd4;
    else right_awsize <= left_to_right ? s_axi_left_awsize :
                         vertical_to_right ? s_axi_vertical_awsize : right_awsize;
end 
//============right_awburst============   
assign m_axi_right_awburst = 2'b01;
//============right_awvalid============   
assign m_axi_right_awvalid = right_awvalid;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) right_awvalid <= 1'b0;
    else if((state_WAIT_CONFIG & ( state_next == S_AR_XY                                  ) & left_read_mem_to_right) | 
            (state_WAIT_CONFIG & ((state_next == S_READ_WAIT_Z) | (state_next == S_READ_Z)) & self_to_right         ) | 
            (                    ( state_next == S_AW_Z                                   ) & right_write_mem       )) begin
        right_awvalid <= 1'b1;
    end
    else right_awvalid <= left_to_right     ? s_axi_left_awvalid :
                          vertical_to_right ? s_axi_vertical_awvalid : 1'b0;
end
//============right_wdata============   
assign m_axi_right_wdata = right_wdata;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) right_wdata <= 128'd0;
    else if(state_R_XY & left_read_mem_to_right)
        right_wdata <= (m_axi_left_rvalid & m_axi_left_rready) ? m_axi_left_rdata : right_wdata;
    else if((state_READ_WAIT_Z | state_READ_Z) & self_to_right & Z_valid)
        right_wdata <= FP_wdata;
    else if(state_SRAM_DELAY & (sram_counter == 2'd1) & right_write_mem)
        right_wdata <= right_write_mem_from_self ? FP_wdata : Q_X_router;
    else if(state_SRAM_DELAY & (sram_counter == 2'd2) & right_write_mem) 
        right_wdata <= right_write_mem_from_self ? {FP_wdata[63:0], right_wdata[63:0]} : {Q_X_router[63:0], right_wdata[63:0]};
    else right_wdata <= left_to_right     ? s_axi_left_wdata :
                        vertical_to_right ? s_axi_vertical_wdata : right_wdata; 
end
//============right_wstrb============   
assign m_axi_right_wstrb = right_wstrb;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) right_wstrb <= 16'd0;
    else if(state_R_XY & left_read_mem_to_right)
        right_wstrb <= 16'hFFFF;
    else if((state_READ_WAIT_Z | state_READ_Z) & self_to_right)
        right_wstrb <= (~|dtype) ? 16'hFFFF : 16'h00FF;
    else if((state_next == S_W_Z) & right_write_mem)
        right_wstrb <= 16'hFFFF;
    else right_wstrb <= left_to_right     ? s_axi_left_wstrb :
                        vertical_to_right ? s_axi_vertical_wstrb : right_wstrb; 
end
//============right_wlast============   
assign m_axi_right_wlast = right_wlast;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) right_wlast <= 1'b0;
    else if(state_R_XY & left_read_mem_to_right)
        right_wlast <= (m_axi_left_rvalid & m_axi_left_rready & m_axi_left_rlast);
    else if((state_READ_WAIT_Z | state_READ_Z) & self_to_right)
        right_wlast <= (Z_valid & Z_read_finish);
    else if((state_next == S_W_Z) & right_write_mem)
        right_wlast <= (((~|dtype) & (&write_z_counter)) | ((|dtype) & (&write_z_counter[5:0])));
    else right_wlast <= left_to_right     ? s_axi_left_wlast :
                        vertical_to_right ? s_axi_vertical_wlast : 1'b0; 
end
//============right_wvalid============   
assign m_axi_right_wvalid = right_wvalid;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) right_wvalid <= 1'b0;
    else if(state_R_XY & left_read_mem_to_right) 
        right_wvalid <= (m_axi_left_rvalid & m_axi_left_rready);
    else if((state_READ_WAIT_Z | state_READ_Z) & self_to_right)
        right_wvalid <= Z_valid;
    else if((state_next == S_W_Z) & right_write_mem)
        right_wvalid <= 1'b1;
    else right_wvalid <= left_to_right     ? s_axi_left_wvalid :
                         vertical_to_right ? s_axi_vertical_wvalid : 1'b0; 
end
//============right_bready============   
assign m_axi_right_bready = 1'b1;

//AXI vertical master
//vertical read
assign m_axi_vertical_arid = 4'd0;
assign m_axi_vertical_araddr = 32'd0;
assign m_axi_vertical_arlen = 8'd0;
assign m_axi_vertical_arsize = 3'd0;
assign m_axi_vertical_arburst = 2'b00;
assign m_axi_vertical_arvalid = 1'b0;
assign m_axi_vertical_rready = 1'b0;

//vertical write
//============vertical_awid============    
assign m_axi_vertical_awid = 4'b0000;
//============vertical_awaddr============   
assign m_axi_vertical_awaddr = 32'd0;
//============vertical_awlen============   
assign m_axi_vertical_awlen = vertical_awlen;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) vertical_awlen <= 8'd0;
    else if(state_WAIT_CONFIG & (state_next == S_AR_XY) & 
           (left_read_mem_to_vertical | right_read_mem_to_vertical)) 
        vertical_awlen <= (~|dtype) ? 8'd127 : 8'd63;
    else if(state_WAIT_CONFIG & ((state_next == S_READ_WAIT_Z) | (state_next == S_READ_Z)) & self_to_vertical)
        vertical_awlen <= 8'd127;
    else vertical_awlen <= left_to_vertical  ? s_axi_left_awlen : 
                           right_to_vertical ? s_axi_right_awlen : vertical_awlen;
end
//============vertical_awsize============   
assign m_axi_vertical_awsize = vertical_awsize;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) vertical_awsize <= 3'd0;
    else if(state_WAIT_CONFIG & (state_next == S_AR_XY) & 
           (left_read_mem_to_vertical | right_read_mem_to_vertical))
        vertical_awsize <= 3'd4;
    else if(state_WAIT_CONFIG & ((state_next == S_READ_WAIT_Z) | (state_next == S_READ_Z)) & self_to_vertical)
        vertical_awsize <= (~|dtype) ? 3'd4 : 3'd3;
    else vertical_awsize <= left_to_vertical  ? s_axi_left_awsize : 
                            right_to_vertical ? s_axi_right_awsize : vertical_awsize;
end
//============vertical_awburst============   
assign m_axi_vertical_awburst = 2'b01;
//============vertical_awvalid============   
assign m_axi_vertical_awvalid = vertical_awvalid;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) vertical_awvalid <= 1'b0;
    else if((state_WAIT_CONFIG & (state_next == S_AR_XY) & 
                                 (left_read_mem_to_vertical | right_read_mem_to_vertical)) | 
            (state_WAIT_CONFIG & ((state_next == S_READ_WAIT_Z) | (state_next == S_READ_Z)) & self_to_vertical)) begin
        vertical_awvalid <= 1'b1;   
    end
    else vertical_awvalid <= left_to_vertical  ? s_axi_left_awvalid : 
                             right_to_vertical ? s_axi_right_awvalid : 1'b0;
end
//============vertical_wdata============   
assign m_axi_vertical_wdata = vertical_wdata;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) vertical_wdata <= 128'd0;
    else if(state_R_XY & (left_read_mem_to_vertical | right_read_mem_to_vertical)) 
        vertical_wdata <= (m_axi_left_rvalid  & m_axi_left_rready ) ? m_axi_left_rdata  :
                          (m_axi_right_rvalid & m_axi_right_rready) ? m_axi_right_rdata : vertical_wdata;
    else if((state_READ_WAIT_Z | state_READ_Z) & self_to_vertical & Z_valid) 
        vertical_wdata <= FP_wdata; 
    else vertical_wdata <= left_to_vertical  ? s_axi_left_wdata : 
                           right_to_vertical ? s_axi_right_wdata : vertical_wdata;
end
//============vertical_wstrb============   
assign m_axi_vertical_wstrb = vertical_wstrb;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) vertical_wstrb <= 16'd0;
    else if(state_R_XY & (left_read_mem_to_vertical | right_read_mem_to_vertical))
        vertical_wstrb <= 16'hFFFF;
    else if((state_READ_WAIT_Z | state_READ_Z) & self_to_vertical)
        vertical_wstrb <= (~|dtype) ? 16'hFFFF : 16'h00FF;
    else vertical_wstrb <= left_to_vertical  ? s_axi_left_wstrb : 
                           right_to_vertical ? s_axi_right_wstrb : vertical_wstrb;
end
//============vertical_wlast============   
assign m_axi_vertical_wlast = vertical_wlast;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) vertical_wlast <= 1'b0;
    else if(state_R_XY & (left_read_mem_to_vertical | right_read_mem_to_vertical))
        vertical_wlast <= ((m_axi_left_rvalid  & m_axi_left_rready  & m_axi_left_rlast ) | 
                           (m_axi_right_rvalid & m_axi_right_rready & m_axi_right_rlast));
    else if((state_READ_WAIT_Z | state_READ_Z) & self_to_vertical)
        vertical_wlast <= (Z_valid & Z_read_finish);
    else vertical_wlast <= left_to_vertical  ? s_axi_left_wlast : 
                           right_to_vertical ? s_axi_right_wlast : 1'b0;
end
//============vertical_wvalid============   
assign m_axi_vertical_wvalid = vertical_wvalid;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) vertical_wvalid <= 1'b0;
    else if(state_R_XY & (left_read_mem_to_vertical | right_read_mem_to_vertical))
        vertical_wvalid <= ((m_axi_left_rvalid  & m_axi_left_rready ) | 
                            (m_axi_right_rvalid & m_axi_right_rready));
    else if((state_READ_WAIT_Z | state_READ_Z) & self_to_vertical)
        vertical_wvalid <= Z_valid;
    else vertical_wvalid <= left_to_vertical  ? s_axi_left_wvalid : 
                            right_to_vertical ? s_axi_right_wvalid : 1'b0;
end
//============vertical_bready============   
assign m_axi_vertical_bready = 1'b1;

//AXI left slave 
//read
assign s_axi_left_arready = 1'b0;
assign s_axi_left_rid = 4'b0000;
assign s_axi_left_rdata = 128'd0;
assign s_axi_left_rresp = 2'b00;
assign s_axi_left_rlast = 1'b0;
assign s_axi_left_rvalid = 1'b0;
//write
assign s_axi_left_awready = 1'b1;
assign s_axi_left_wready = 1'b1;
assign s_axi_left_bid = 4'b0000;
assign s_axi_left_bresp = 2'b00;
logic left_bvalid;
assign s_axi_left_bvalid = left_bvalid;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) left_bvalid <= 1'b0;
    else left_bvalid <= s_axi_left_wlast;
end

//AXI right slave
//read
assign s_axi_right_arready = 1'b0;
assign s_axi_right_rid = 4'b0000;
assign s_axi_right_rdata = 128'd0;
assign s_axi_right_rresp = 2'b00;
assign s_axi_right_rlast = 1'b0;
assign s_axi_right_rvalid = 1'b0;
//write
assign s_axi_right_awready = 1'b1;
assign s_axi_right_wready = 1'b1;
assign s_axi_right_bid = 4'b0000;
assign s_axi_right_bresp = 2'b00;
logic right_bvalid;
assign s_axi_right_bvalid = right_bvalid;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) right_bvalid <= 1'b0;
    else right_bvalid <= s_axi_right_wlast;
end 

//AXI vertical slave 
//read
assign s_axi_vertical_arready = 1'b0;
assign s_axi_vertical_rid = 4'b0000;
assign s_axi_vertical_rdata = 128'd0;
assign s_axi_vertical_rresp = 2'b00;
assign s_axi_vertical_rlast = 1'b0;
assign s_axi_vertical_rvalid = 1'b0;
//write
assign s_axi_vertical_awready = 1'b1;
assign s_axi_vertical_wready = 1'b1;
assign s_axi_vertical_bid = 4'b0000;
assign s_axi_vertical_bresp = 2'b00;
logic vertical_bvalid;
assign s_axi_vertical_bvalid = vertical_bvalid;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) vertical_bvalid <= 1'b0;
    else vertical_bvalid <= s_axi_vertical_wlast;
end
//============FP32============   
integer i0;
always @(*) begin
    for(i0=0 ; i0<8 ; i0=i0+1) begin
        FP32_sign[i0] = Z_data[(i0*32+31)];
        FP32_exp [i0] = Z_data[(i0*32+23)+:8];
        FP32_frac[i0] = Z_data[(i0*32)+:23];
        FP32_NAN [i0] = ((&FP32_exp[i0]) & (|FP32_frac[i0]));
    end
end
//============FP32->BF16-E8M7============   
integer i1;
logic [15:0] BF16_pre_rnd [0:7];
logic [15:0] BF16_rnd     [0:7];
logic        BF16_sticky  [0:7];
logic        BF16_round   [0:7];

always @(*) begin
    for(i1=0 ; i1<8 ; i1=i1+1) begin
        BF16_pre_rnd[i1] = {FP32_sign[i1], FP32_exp[i1], FP32_frac[i1][22:16]};
        
        BF16_sticky[i1]  = |FP32_frac[i1][14:0];
        BF16_round[i1]   = FP32_frac[i1][15] & (BF16_sticky[i1] | FP32_frac[i1][16]);
        BF16_rnd[i1]     = BF16_pre_rnd[i1] + {15'd0, BF16_round[i1]};
        
        FP32_BF16[i1] = FP32_NAN[i1] ? {FP32_sign[i1], 8'hFF, 7'b100_0000} : BF16_rnd[i1];
    end
end

//============FP32->FP8-E5M2============   
integer i2;
logic [7:0] E5M2_pre_rnd [0:7];
logic [7:0] E5M2_rnd     [0:7];
logic       E5M2_sticky  [0:7];
logic       E5M2_round   [0:7];

always @(*) begin
    for(i2=0 ; i2<8 ; i2=i2+1) begin
        FP8_E5M2_exp_calc[i2] = $signed({1'b0, FP32_exp[i2]}) - 9'sd112;
        
        E5M2_pre_rnd[i2] = {FP32_sign[i2], FP8_E5M2_exp_calc[i2][4:0], FP32_frac[i2][22:21]};
        
        E5M2_sticky[i2]  = |FP32_frac[i2][19:0];
        E5M2_round[i2]   = FP32_frac[i2][20] & (E5M2_sticky[i2] | FP32_frac[i2][21]);
        
        E5M2_rnd[i2]     = E5M2_pre_rnd[i2] + {7'd0, E5M2_round[i2]};
        
        FP32_FP8_E5M2[i2] = FP32_NAN[i2] ? {FP32_sign[i2], 5'b1_1111, 2'b10} : 
                            (~|FP32_exp[i2]) ? {FP32_sign[i2], 7'd0} :
                            (FP8_E5M2_exp_calc[i2] <= 9'sd0) ? {FP32_sign[i2], 7'd0} : 
                            (FP8_E5M2_exp_calc[i2] >= 9'sd31) ? {FP32_sign[i2], 5'b1_1111, 2'b00} : E5M2_rnd[i2];
    end
end

//============FP32->FP8-E4M3============   
integer i3;
logic [7:0] E4M3_pre_rnd [0:7];
logic [7:0] E4M3_rnd     [0:7];
logic       E4M3_sticky  [0:7];
logic       E4M3_round   [0:7];

always @(*) begin
    for(i3=0 ; i3<8 ; i3=i3+1) begin
        FP8_E4M3_exp_calc[i3] = $signed({1'b0, FP32_exp[i3]}) - 9'sd120;
        
        E4M3_pre_rnd[i3] = {FP32_sign[i3], FP8_E4M3_exp_calc[i3][3:0], FP32_frac[i3][22:20]};
        
        E4M3_sticky[i3]  = |FP32_frac[i3][18:0];
        E4M3_round[i3]   = FP32_frac[i3][19] & (E4M3_sticky[i3] | FP32_frac[i3][20]);
        
        E4M3_rnd[i3]     = E4M3_pre_rnd[i3] + {7'd0, E4M3_round[i3]};
        
        FP32_FP8_E4M3[i3] = FP32_NAN[i3] ? {FP32_sign[i3], 4'b1111, 3'b111} :
                            (~|FP32_exp[i3]) ? {FP32_sign[i3], 7'd0} :
                            (FP8_E4M3_exp_calc[i3] <= 9'sd0) ? {FP32_sign[i3], 7'd0} : 
                            (FP8_E4M3_exp_calc[i3] > 9'sd15) ? {FP32_sign[i3], 4'b1111, 3'b110} : 
                            (E4M3_rnd[i3][6:0] == 7'b111_1111) ? {FP32_sign[i3], 4'b1111, 3'b110} : E4M3_rnd[i3]; 
    end 
end
//============FP_wdata============   
always @(*) begin
    FP_wdata = (dtype == 2'd0) ? {FP32_BF16[7], FP32_BF16[6], FP32_BF16[5], FP32_BF16[4], FP32_BF16[3], FP32_BF16[2], FP32_BF16[1], FP32_BF16[0]} : 
               (dtype == 2'd1) ? {64'd0, FP32_FP8_E4M3[7], FP32_FP8_E4M3[6], FP32_FP8_E4M3[5], FP32_FP8_E4M3[4], FP32_FP8_E4M3[3], FP32_FP8_E4M3[2], FP32_FP8_E4M3[1], FP32_FP8_E4M3[0]} : 
                                 {64'd0, FP32_FP8_E5M2[7], FP32_FP8_E5M2[6], FP32_FP8_E5M2[5], FP32_FP8_E5M2[4], FP32_FP8_E5M2[3], FP32_FP8_E5M2[2], FP32_FP8_E5M2[1], FP32_FP8_E5M2[0]};
end
endmodule