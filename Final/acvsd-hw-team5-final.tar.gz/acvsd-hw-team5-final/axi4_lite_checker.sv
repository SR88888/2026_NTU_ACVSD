`timescale 1ns/1ps

module axi4_lite_checker (
    input  logic ACLK,
    input  logic ARESETn,
    axi4_lite_if.monitor axil
);

    // TODO
    property Valid_signals_cannot_drop_unless_accepted(valid, ready);
        @(posedge ACLK) disable iff (!ARESETn)
        (valid && !ready) |=> valid;
    endproperty

    assert property (Valid_signals_cannot_drop_unless_accepted(axil.awvalid, axil.awready))
        else $error("AWVALID cannot drop until AWREADY is asserted");
    assert property (Valid_signals_cannot_drop_unless_accepted(axil.wvalid, axil.wready))
        else $error("WVALID cannot drop until WREADY is asserted");
    assert property (Valid_signals_cannot_drop_unless_accepted(axil.bvalid, axil.bready))
        else $error("BVALID cannot drop until BREADY is asserted");
    assert property (Valid_signals_cannot_drop_unless_accepted(axil.arvalid, axil.arready))
        else $error("ARVALID cannot drop until ARREADY is asserted");
    assert property (Valid_signals_cannot_drop_unless_accepted(axil.rvalid, axil.rready))
        else $error("RVALID cannot drop until RREADY is asserted");

    property Data_cannot_be_changed_until_handshake(data, valid, ready);
        @(posedge ACLK) disable iff (!ARESETn)
        (valid && !ready) |=> $stable(data);
    endproperty

    assert property (Data_cannot_be_changed_until_handshake(axil.awaddr, axil.awvalid, axil.awready))
        else $error("Address channel signals cannot change until handshake is complete");
    assert property (Data_cannot_be_changed_until_handshake(axil.wdata, axil.wvalid, axil.wready))
        else $error("Write data and strobe cannot change until handshake is complete");
    assert property (Data_cannot_be_changed_until_handshake(axil.bresp, axil.bvalid, axil.bready))
        else $error("Write response signals cannot change until handshake is complete");
    assert property (Data_cannot_be_changed_until_handshake(axil.araddr, axil.arvalid, axil.arready))
        else $error("Address channel signals cannot change until handshake is complete");
    assert property (Data_cannot_be_changed_until_handshake({axil.rdata, axil.rresp}, axil.rvalid, axil.rready))
        else $error("Read data and response signals cannot change until handshake is complete");

    logic aw_done, w_done, ar_done;
    always_ff @(posedge ACLK or negedge ARESETn) begin
        if (!ARESETn) begin
            aw_done <= 0;
            w_done  <= 0;
            ar_done <= 0;
        end
        else begin
            if (axil.awvalid && axil.awready) aw_done <= 1'b1;
            if (axil.wvalid && axil.wready)   w_done <= 1'b1;
            if (axil.bvalid && axil.bready) begin
                aw_done <= 1'b0;
                w_done  <= 1'b0;
            end

            if (axil.arvalid && axil.arready) ar_done <= 1'b1;
            if (axil.rvalid && axil.rready)   ar_done <= 1'b0;
        end
    end

    property Order_of_transaction_should_be_correct(done, valid);
        @(posedge ACLK) disable iff (!ARESETn)
        valid |-> done;
    endproperty

    assert property (Order_of_transaction_should_be_correct((aw_done && w_done), axil.bvalid))
        else $error("Write response received without valid address and data handshake");
    assert property (Order_of_transaction_should_be_correct(ar_done, axil.rvalid))
        else $error("Read data received without valid address handshake");

endmodule
