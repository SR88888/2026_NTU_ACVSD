`timescale 1ns/1ps
import axi_pkg::*;

module pe (
    input  logic clk_data_bus,
    input  logic clk_ctrl_bus,
    input  logic clk_pe,
    input  logic rst_n,

    // -------------------------------------------------------------------------
    // AXI4-Lite slave (from controller) — flat ports
    // -------------------------------------------------------------------------
    input  logic [AXIL_ADDR_W-1:0]  s_axil_awaddr,
    input  logic                    s_axil_awvalid,
    output logic                    s_axil_awready,
    input  logic [AXIL_DATA_W-1:0]  s_axil_wdata,
    input  logic                    s_axil_wvalid,
    output logic                    s_axil_wready,
    output logic [AXIL_RESP_W-1:0]  s_axil_bresp,
    output logic                    s_axil_bvalid,
    input  logic                    s_axil_bready,
    input  logic [AXIL_ADDR_W-1:0]  s_axil_araddr,
    input  logic                    s_axil_arvalid,
    output logic                    s_axil_arready,
    output logic [AXIL_DATA_W-1:0]  s_axil_rdata,
    output logic [AXIL_RESP_W-1:0]  s_axil_rresp,
    output logic                    s_axil_rvalid,
    input  logic                    s_axil_rready,

    // -------------------------------------------------------------------------
    // AXI4-Full slave left — flat ports
    // -------------------------------------------------------------------------
    input  logic [AXI_ID_W-1:0]     s_axi_left_awid,
    input  logic [AXI_ADDR_W-1:0]   s_axi_left_awaddr,
    input  logic [AXI_LEN_W-1:0]    s_axi_left_awlen,
    input  logic [AXI_SIZE_W-1:0]   s_axi_left_awsize,
    input  logic [AXI_BURST_W-1:0]  s_axi_left_awburst,
    input  logic                    s_axi_left_awvalid,
    output logic                    s_axi_left_awready,
    input  logic [AXI_DATA_W-1:0]   s_axi_left_wdata,
    input  logic [AXI_STRB_W-1:0]   s_axi_left_wstrb,
    input  logic                    s_axi_left_wlast,
    input  logic                    s_axi_left_wvalid,
    output logic                    s_axi_left_wready,
    output logic [AXI_ID_W-1:0]     s_axi_left_bid,
    output logic [AXI_RESP_W-1:0]   s_axi_left_bresp,
    output logic                    s_axi_left_bvalid,
    input  logic                    s_axi_left_bready,
    input  logic [AXI_ID_W-1:0]     s_axi_left_arid,
    input  logic [AXI_ADDR_W-1:0]   s_axi_left_araddr,
    input  logic [AXI_LEN_W-1:0]    s_axi_left_arlen,
    input  logic [AXI_SIZE_W-1:0]   s_axi_left_arsize,
    input  logic [AXI_BURST_W-1:0]  s_axi_left_arburst,
    input  logic                    s_axi_left_arvalid,
    output logic                    s_axi_left_arready,
    output logic [AXI_ID_W-1:0]     s_axi_left_rid,
    output logic [AXI_DATA_W-1:0]   s_axi_left_rdata,
    output logic [AXI_RESP_W-1:0]   s_axi_left_rresp,
    output logic                    s_axi_left_rlast,
    output logic                    s_axi_left_rvalid,
    input  logic                    s_axi_left_rready,

    // -------------------------------------------------------------------------
    // AXI4-Full slave right — flat ports
    // -------------------------------------------------------------------------
    input  logic [AXI_ID_W-1:0]     s_axi_right_awid,
    input  logic [AXI_ADDR_W-1:0]   s_axi_right_awaddr,
    input  logic [AXI_LEN_W-1:0]    s_axi_right_awlen,
    input  logic [AXI_SIZE_W-1:0]   s_axi_right_awsize,
    input  logic [AXI_BURST_W-1:0]  s_axi_right_awburst,
    input  logic                    s_axi_right_awvalid,
    output logic                    s_axi_right_awready,
    input  logic [AXI_DATA_W-1:0]   s_axi_right_wdata,
    input  logic [AXI_STRB_W-1:0]   s_axi_right_wstrb,
    input  logic                    s_axi_right_wlast,
    input  logic                    s_axi_right_wvalid,
    output logic                    s_axi_right_wready,
    output logic [AXI_ID_W-1:0]     s_axi_right_bid,
    output logic [AXI_RESP_W-1:0]   s_axi_right_bresp,
    output logic                    s_axi_right_bvalid,
    input  logic                    s_axi_right_bready,
    input  logic [AXI_ID_W-1:0]     s_axi_right_arid,
    input  logic [AXI_ADDR_W-1:0]   s_axi_right_araddr,
    input  logic [AXI_LEN_W-1:0]    s_axi_right_arlen,
    input  logic [AXI_SIZE_W-1:0]   s_axi_right_arsize,
    input  logic [AXI_BURST_W-1:0]  s_axi_right_arburst,
    input  logic                    s_axi_right_arvalid,
    output logic                    s_axi_right_arready,
    output logic [AXI_ID_W-1:0]     s_axi_right_rid,
    output logic [AXI_DATA_W-1:0]   s_axi_right_rdata,
    output logic [AXI_RESP_W-1:0]   s_axi_right_rresp,
    output logic                    s_axi_right_rlast,
    output logic                    s_axi_right_rvalid,
    input  logic                    s_axi_right_rready,

    // -------------------------------------------------------------------------
    // AXI4-Full slave vertical — flat ports
    // -------------------------------------------------------------------------
    input  logic [AXI_ID_W-1:0]     s_axi_vertical_awid,
    input  logic [AXI_ADDR_W-1:0]   s_axi_vertical_awaddr,
    input  logic [AXI_LEN_W-1:0]    s_axi_vertical_awlen,
    input  logic [AXI_SIZE_W-1:0]   s_axi_vertical_awsize,
    input  logic [AXI_BURST_W-1:0]  s_axi_vertical_awburst,
    input  logic                    s_axi_vertical_awvalid,
    output logic                    s_axi_vertical_awready,
    input  logic [AXI_DATA_W-1:0]   s_axi_vertical_wdata,
    input  logic [AXI_STRB_W-1:0]   s_axi_vertical_wstrb,
    input  logic                    s_axi_vertical_wlast,
    input  logic                    s_axi_vertical_wvalid,
    output logic                    s_axi_vertical_wready,
    output logic [AXI_ID_W-1:0]     s_axi_vertical_bid,
    output logic [AXI_RESP_W-1:0]   s_axi_vertical_bresp,
    output logic                    s_axi_vertical_bvalid,
    input  logic                    s_axi_vertical_bready,
    input  logic [AXI_ID_W-1:0]     s_axi_vertical_arid,
    input  logic [AXI_ADDR_W-1:0]   s_axi_vertical_araddr,
    input  logic [AXI_LEN_W-1:0]    s_axi_vertical_arlen,
    input  logic [AXI_SIZE_W-1:0]   s_axi_vertical_arsize,
    input  logic [AXI_BURST_W-1:0]  s_axi_vertical_arburst,
    input  logic                    s_axi_vertical_arvalid,
    output logic                    s_axi_vertical_arready,
    output logic [AXI_ID_W-1:0]     s_axi_vertical_rid,
    output logic [AXI_DATA_W-1:0]   s_axi_vertical_rdata,
    output logic [AXI_RESP_W-1:0]   s_axi_vertical_rresp,
    output logic                    s_axi_vertical_rlast,
    output logic                    s_axi_vertical_rvalid,
    input  logic                    s_axi_vertical_rready,

    // -------------------------------------------------------------------------
    // AXI4-Full master left — flat ports
    // -------------------------------------------------------------------------
    output logic [AXI_ID_W-1:0]     m_axi_left_awid,
    output logic [AXI_ADDR_W-1:0]   m_axi_left_awaddr,
    output logic [AXI_LEN_W-1:0]    m_axi_left_awlen,
    output logic [AXI_SIZE_W-1:0]   m_axi_left_awsize,
    output logic [AXI_BURST_W-1:0]  m_axi_left_awburst,
    output logic                    m_axi_left_awvalid,
    input  logic                    m_axi_left_awready,
    output logic [AXI_DATA_W-1:0]   m_axi_left_wdata,
    output logic [AXI_STRB_W-1:0]   m_axi_left_wstrb,
    output logic                    m_axi_left_wlast,
    output logic                    m_axi_left_wvalid,
    input  logic                    m_axi_left_wready,
    input  logic [AXI_ID_W-1:0]     m_axi_left_bid,
    input  logic [AXI_RESP_W-1:0]   m_axi_left_bresp,
    input  logic                    m_axi_left_bvalid,
    output logic                    m_axi_left_bready,
    output logic [AXI_ID_W-1:0]     m_axi_left_arid,
    output logic [AXI_ADDR_W-1:0]   m_axi_left_araddr,
    output logic [AXI_LEN_W-1:0]    m_axi_left_arlen,
    output logic [AXI_SIZE_W-1:0]   m_axi_left_arsize,
    output logic [AXI_BURST_W-1:0]  m_axi_left_arburst,
    output logic                    m_axi_left_arvalid,
    input  logic                    m_axi_left_arready,
    input  logic [AXI_ID_W-1:0]     m_axi_left_rid,
    input  logic [AXI_DATA_W-1:0]   m_axi_left_rdata,
    input  logic [AXI_RESP_W-1:0]   m_axi_left_rresp,
    input  logic                    m_axi_left_rlast,
    input  logic                    m_axi_left_rvalid,
    output logic                    m_axi_left_rready,

    // -------------------------------------------------------------------------
    // AXI4-Full master right — flat ports
    // -------------------------------------------------------------------------
    output logic [AXI_ID_W-1:0]     m_axi_right_awid,
    output logic [AXI_ADDR_W-1:0]   m_axi_right_awaddr,
    output logic [AXI_LEN_W-1:0]    m_axi_right_awlen,
    output logic [AXI_SIZE_W-1:0]   m_axi_right_awsize,
    output logic [AXI_BURST_W-1:0]  m_axi_right_awburst,
    output logic                    m_axi_right_awvalid,
    input  logic                    m_axi_right_awready,
    output logic [AXI_DATA_W-1:0]   m_axi_right_wdata,
    output logic [AXI_STRB_W-1:0]   m_axi_right_wstrb,
    output logic                    m_axi_right_wlast,
    output logic                    m_axi_right_wvalid,
    input  logic                    m_axi_right_wready,
    input  logic [AXI_ID_W-1:0]     m_axi_right_bid,
    input  logic [AXI_RESP_W-1:0]   m_axi_right_bresp,
    input  logic                    m_axi_right_bvalid,
    output logic                    m_axi_right_bready,
    output logic [AXI_ID_W-1:0]     m_axi_right_arid,
    output logic [AXI_ADDR_W-1:0]   m_axi_right_araddr,
    output logic [AXI_LEN_W-1:0]    m_axi_right_arlen,
    output logic [AXI_SIZE_W-1:0]   m_axi_right_arsize,
    output logic [AXI_BURST_W-1:0]  m_axi_right_arburst,
    output logic                    m_axi_right_arvalid,
    input  logic                    m_axi_right_arready,
    input  logic [AXI_ID_W-1:0]     m_axi_right_rid,
    input  logic [AXI_DATA_W-1:0]   m_axi_right_rdata,
    input  logic [AXI_RESP_W-1:0]   m_axi_right_rresp,
    input  logic                    m_axi_right_rlast,
    input  logic                    m_axi_right_rvalid,
    output logic                    m_axi_right_rready,

    // -------------------------------------------------------------------------
    // AXI4-Full master vertical — flat ports
    // -------------------------------------------------------------------------
    output logic [AXI_ID_W-1:0]     m_axi_vertical_awid,
    output logic [AXI_ADDR_W-1:0]   m_axi_vertical_awaddr,
    output logic [AXI_LEN_W-1:0]    m_axi_vertical_awlen,
    output logic [AXI_SIZE_W-1:0]   m_axi_vertical_awsize,
    output logic [AXI_BURST_W-1:0]  m_axi_vertical_awburst,
    output logic                    m_axi_vertical_awvalid,
    input  logic                    m_axi_vertical_awready,
    output logic [AXI_DATA_W-1:0]   m_axi_vertical_wdata,
    output logic [AXI_STRB_W-1:0]   m_axi_vertical_wstrb,
    output logic                    m_axi_vertical_wlast,
    output logic                    m_axi_vertical_wvalid,
    input  logic                    m_axi_vertical_wready,
    input  logic [AXI_ID_W-1:0]     m_axi_vertical_bid,
    input  logic [AXI_RESP_W-1:0]   m_axi_vertical_bresp,
    input  logic                    m_axi_vertical_bvalid,
    output logic                    m_axi_vertical_bready,
    output logic [AXI_ID_W-1:0]     m_axi_vertical_arid,
    output logic [AXI_ADDR_W-1:0]   m_axi_vertical_araddr,
    output logic [AXI_LEN_W-1:0]    m_axi_vertical_arlen,
    output logic [AXI_SIZE_W-1:0]   m_axi_vertical_arsize,
    output logic [AXI_BURST_W-1:0]  m_axi_vertical_arburst,
    output logic                    m_axi_vertical_arvalid,
    input  logic                    m_axi_vertical_arready,
    input  logic [AXI_ID_W-1:0]     m_axi_vertical_rid,
    input  logic [AXI_DATA_W-1:0]   m_axi_vertical_rdata,
    input  logic [AXI_RESP_W-1:0]   m_axi_vertical_rresp,
    input  logic                    m_axi_vertical_rlast,
    input  logic                    m_axi_vertical_rvalid,
    output logic                    m_axi_vertical_rready,

    output logic interrupt_out
);
logic           push_n_config;
logic [ 38:0]   pdata_config;

logic           interrupt_router;

logic [  1:0]   matrix_type_mac;
logic [  1:0]   dtype_mac;
logic [  1:0]   col_x_mac;

logic           X_read_start;
logic           Y_read_start;
logic [127:0]   XY_data;
logic           XY_valid;
logic           XY_read_finish;

logic           Z_calc_start;
logic           Z_read_start;
logic [255:0]   Z_data;
logic           Z_valid;
logic           Z_calc_finish;
logic           Z_read_finish;

logic           sram_X_en_router;      
logic [  6:0]   A_X_router;
logic [  1:0]   CEB_X_router;
logic [  1:0]   WEB_X_router;
logic [127:0]   D_X_router;
logic [127:0]   Q_X_router;

logic           sram_Z_en_router;   
logic [  6:0]   A_Z_router;
logic [  3:0]   CEB_Z_router;

logic           pop_n_router;
logic           empty_router;
logic [ 38:0]   rdata_router;
pe_config #(
    .AXIL_ADDR_W(10), .AXIL_DATA_W(128),  .AXIL_RESP_W(2)
) pe_config_0 (
    .clk_ctrl_bus(clk_ctrl_bus),
    .rst_n(rst_n),
    // -------------------------------------------------------------------------
    // AXI4-Lite slave (from controller) — flat ports
    // -------------------------------------------------------------------------
    .s_axil_awaddr(s_axil_awaddr),
    .s_axil_awvalid(s_axil_awvalid),
    .s_axil_awready(s_axil_awready),
    
    .s_axil_wdata(s_axil_wdata),
    .s_axil_wvalid(s_axil_wvalid),
    .s_axil_wready(s_axil_wready),

    .s_axil_bresp(s_axil_bresp),
    .s_axil_bvalid(s_axil_bvalid),
    .s_axil_bready(s_axil_bready),

    .s_axil_araddr(s_axil_araddr),
    .s_axil_arvalid(s_axil_arvalid),
    .s_axil_arready(s_axil_arready),

    .s_axil_rdata(s_axil_rdata),
    .s_axil_rresp(s_axil_rresp),
    .s_axil_rvalid(s_axil_rvalid),
    .s_axil_rready(s_axil_rready),

    .push_n_config(push_n_config),
    .pdata_config(pdata_config)
);
Router #(
    .AXI_ID_W(4), .AXI_ADDR_W(32), .AXI_LEN_W(8), .AXI_SIZE_W(3), 
    .AXI_BURST_W(2), .AXI_DATA_W(128), .AXI_STRB_W(16), .AXI_RESP_W(2)
) Router_0 (
    .clk_data_bus(clk_data_bus),     
    .rst_n(rst_n),

    // -------------------------------------------------------------------------
    // AXI4-Full slave left — flat ports
    // -------------------------------------------------------------------------
    .s_axi_left_awid(s_axi_left_awid),
    .s_axi_left_awaddr(s_axi_left_awaddr),
    .s_axi_left_awlen(s_axi_left_awlen),
    .s_axi_left_awsize(s_axi_left_awsize),
    .s_axi_left_awburst(s_axi_left_awburst),
    .s_axi_left_awvalid(s_axi_left_awvalid),
    .s_axi_left_awready(s_axi_left_awready),
    .s_axi_left_wdata(s_axi_left_wdata),
    .s_axi_left_wstrb(s_axi_left_wstrb),
    .s_axi_left_wlast(s_axi_left_wlast),
    .s_axi_left_wvalid(s_axi_left_wvalid),
    .s_axi_left_wready(s_axi_left_wready),
    .s_axi_left_bid(s_axi_left_bid),
    .s_axi_left_bresp(s_axi_left_bresp),
    .s_axi_left_bvalid(s_axi_left_bvalid),
    .s_axi_left_bready(s_axi_left_bready),
    .s_axi_left_arid(s_axi_left_arid),
    .s_axi_left_araddr(s_axi_left_araddr),
    .s_axi_left_arlen(s_axi_left_arlen),
    .s_axi_left_arsize(s_axi_left_arsize),
    .s_axi_left_arburst(s_axi_left_arburst),
    .s_axi_left_arvalid(s_axi_left_arvalid),
    .s_axi_left_arready(s_axi_left_arready),
    .s_axi_left_rid(s_axi_left_rid),
    .s_axi_left_rdata(s_axi_left_rdata),
    .s_axi_left_rresp(s_axi_left_rresp),
    .s_axi_left_rlast(s_axi_left_rlast),
    .s_axi_left_rvalid(s_axi_left_rvalid),
    .s_axi_left_rready(s_axi_left_rready),

    // -------------------------------------------------------------------------
    // AXI4-Full slave right — flat ports
    // -------------------------------------------------------------------------
    .s_axi_right_awid(s_axi_right_awid),
    .s_axi_right_awaddr(s_axi_right_awaddr),
    .s_axi_right_awlen(s_axi_right_awlen),
    .s_axi_right_awsize(s_axi_right_awsize),
    .s_axi_right_awburst(s_axi_right_awburst),
    .s_axi_right_awvalid(s_axi_right_awvalid),
    .s_axi_right_awready(s_axi_right_awready),
    .s_axi_right_wdata(s_axi_right_wdata),
    .s_axi_right_wstrb(s_axi_right_wstrb),
    .s_axi_right_wlast(s_axi_right_wlast),
    .s_axi_right_wvalid(s_axi_right_wvalid),
    .s_axi_right_wready(s_axi_right_wready),
    .s_axi_right_bid(s_axi_right_bid),
    .s_axi_right_bresp(s_axi_right_bresp),
    .s_axi_right_bvalid(s_axi_right_bvalid),
    .s_axi_right_bready(s_axi_right_bready),
    .s_axi_right_arid(s_axi_right_arid),
    .s_axi_right_araddr(s_axi_right_araddr),
    .s_axi_right_arlen(s_axi_right_arlen),
    .s_axi_right_arsize(s_axi_right_arsize),
    .s_axi_right_arburst(s_axi_right_arburst),
    .s_axi_right_arvalid(s_axi_right_arvalid),
    .s_axi_right_arready(s_axi_right_arready),
    .s_axi_right_rid(s_axi_right_rid),
    .s_axi_right_rdata(s_axi_right_rdata),
    .s_axi_right_rresp(s_axi_right_rresp),
    .s_axi_right_rlast(s_axi_right_rlast),
    .s_axi_right_rvalid(s_axi_right_rvalid),
    .s_axi_right_rready(s_axi_right_rready),

    // -------------------------------------------------------------------------
    // AXI4-Full slave vertical — flat ports
    // -------------------------------------------------------------------------
    .s_axi_vertical_awid(s_axi_vertical_awid),
    .s_axi_vertical_awaddr(s_axi_vertical_awaddr),
    .s_axi_vertical_awlen(s_axi_vertical_awlen),
    .s_axi_vertical_awsize(s_axi_vertical_awsize),
    .s_axi_vertical_awburst(s_axi_vertical_awburst),
    .s_axi_vertical_awvalid(s_axi_vertical_awvalid),
    .s_axi_vertical_awready(s_axi_vertical_awready),
    .s_axi_vertical_wdata(s_axi_vertical_wdata),
    .s_axi_vertical_wstrb(s_axi_vertical_wstrb),
    .s_axi_vertical_wlast(s_axi_vertical_wlast),
    .s_axi_vertical_wvalid(s_axi_vertical_wvalid),
    .s_axi_vertical_wready(s_axi_vertical_wready),
    .s_axi_vertical_bid(s_axi_vertical_bid),
    .s_axi_vertical_bresp(s_axi_vertical_bresp),
    .s_axi_vertical_bvalid(s_axi_vertical_bvalid),
    .s_axi_vertical_bready(s_axi_vertical_bready),
    .s_axi_vertical_arid(s_axi_vertical_arid),
    .s_axi_vertical_araddr(s_axi_vertical_araddr),
    .s_axi_vertical_arlen(s_axi_vertical_arlen),
    .s_axi_vertical_arsize(s_axi_vertical_arsize),
    .s_axi_vertical_arburst(s_axi_vertical_arburst),
    .s_axi_vertical_arvalid(s_axi_vertical_arvalid),
    .s_axi_vertical_arready(s_axi_vertical_arready),
    .s_axi_vertical_rid(s_axi_vertical_rid),
    .s_axi_vertical_rdata(s_axi_vertical_rdata),
    .s_axi_vertical_rresp(s_axi_vertical_rresp),
    .s_axi_vertical_rlast(s_axi_vertical_rlast),
    .s_axi_vertical_rvalid(s_axi_vertical_rvalid),
    .s_axi_vertical_rready(s_axi_vertical_rready),

    // -------------------------------------------------------------------------
    // AXI4-Full master left — flat ports
    // -------------------------------------------------------------------------
    .m_axi_left_awid(m_axi_left_awid),
    .m_axi_left_awaddr(m_axi_left_awaddr),
    .m_axi_left_awlen(m_axi_left_awlen),
    .m_axi_left_awsize(m_axi_left_awsize),
    .m_axi_left_awburst(m_axi_left_awburst),
    .m_axi_left_awvalid(m_axi_left_awvalid),
    .m_axi_left_awready(m_axi_left_awready),
    .m_axi_left_wdata(m_axi_left_wdata),
    .m_axi_left_wstrb(m_axi_left_wstrb),
    .m_axi_left_wlast(m_axi_left_wlast),
    .m_axi_left_wvalid(m_axi_left_wvalid),
    .m_axi_left_wready(m_axi_left_wready),
    .m_axi_left_bid(m_axi_left_bid),
    .m_axi_left_bresp(m_axi_left_bresp),
    .m_axi_left_bvalid(m_axi_left_bvalid),
    .m_axi_left_bready(m_axi_left_bready),
    .m_axi_left_arid(m_axi_left_arid),
    .m_axi_left_araddr(m_axi_left_araddr),
    .m_axi_left_arlen(m_axi_left_arlen),
    .m_axi_left_arsize(m_axi_left_arsize),
    .m_axi_left_arburst(m_axi_left_arburst),
    .m_axi_left_arvalid(m_axi_left_arvalid),
    .m_axi_left_arready(m_axi_left_arready),
    .m_axi_left_rid(m_axi_left_rid),
    .m_axi_left_rdata(m_axi_left_rdata),
    .m_axi_left_rresp(m_axi_left_rresp),
    .m_axi_left_rlast(m_axi_left_rlast),
    .m_axi_left_rvalid(m_axi_left_rvalid),
    .m_axi_left_rready(m_axi_left_rready),

    // -------------------------------------------------------------------------
    // AXI4-Full master right — flat ports
    // -------------------------------------------------------------------------
    .m_axi_right_awid(m_axi_right_awid),
    .m_axi_right_awaddr(m_axi_right_awaddr),
    .m_axi_right_awlen(m_axi_right_awlen),
    .m_axi_right_awsize(m_axi_right_awsize),
    .m_axi_right_awburst(m_axi_right_awburst),
    .m_axi_right_awvalid(m_axi_right_awvalid),
    .m_axi_right_awready(m_axi_right_awready),
    .m_axi_right_wdata(m_axi_right_wdata),
    .m_axi_right_wstrb(m_axi_right_wstrb),
    .m_axi_right_wlast(m_axi_right_wlast),
    .m_axi_right_wvalid(m_axi_right_wvalid),
    .m_axi_right_wready(m_axi_right_wready),
    .m_axi_right_bid(m_axi_right_bid),
    .m_axi_right_bresp(m_axi_right_bresp),
    .m_axi_right_bvalid(m_axi_right_bvalid),
    .m_axi_right_bready(m_axi_right_bready),
    .m_axi_right_arid(m_axi_right_arid),
    .m_axi_right_araddr(m_axi_right_araddr),
    .m_axi_right_arlen(m_axi_right_arlen),
    .m_axi_right_arsize(m_axi_right_arsize),
    .m_axi_right_arburst(m_axi_right_arburst),
    .m_axi_right_arvalid(m_axi_right_arvalid),
    .m_axi_right_arready(m_axi_right_arready),
    .m_axi_right_rid(m_axi_right_rid),
    .m_axi_right_rdata(m_axi_right_rdata),
    .m_axi_right_rresp(m_axi_right_rresp),
    .m_axi_right_rlast(m_axi_right_rlast),
    .m_axi_right_rvalid(m_axi_right_rvalid),
    .m_axi_right_rready(m_axi_right_rready),

    // -------------------------------------------------------------------------
    // AXI4-Full master vertical — flat ports
    // -------------------------------------------------------------------------
    .m_axi_vertical_awid(m_axi_vertical_awid),
    .m_axi_vertical_awaddr(m_axi_vertical_awaddr),
    .m_axi_vertical_awlen(m_axi_vertical_awlen),
    .m_axi_vertical_awsize(m_axi_vertical_awsize),
    .m_axi_vertical_awburst(m_axi_vertical_awburst),
    .m_axi_vertical_awvalid(m_axi_vertical_awvalid),
    .m_axi_vertical_awready(m_axi_vertical_awready),
    .m_axi_vertical_wdata(m_axi_vertical_wdata),
    .m_axi_vertical_wstrb(m_axi_vertical_wstrb),
    .m_axi_vertical_wlast(m_axi_vertical_wlast),
    .m_axi_vertical_wvalid(m_axi_vertical_wvalid),
    .m_axi_vertical_wready(m_axi_vertical_wready),
    .m_axi_vertical_bid(m_axi_vertical_bid),
    .m_axi_vertical_bresp(m_axi_vertical_bresp),
    .m_axi_vertical_bvalid(m_axi_vertical_bvalid),
    .m_axi_vertical_bready(m_axi_vertical_bready),
    .m_axi_vertical_arid(m_axi_vertical_arid),
    .m_axi_vertical_araddr(m_axi_vertical_araddr),
    .m_axi_vertical_arlen(m_axi_vertical_arlen),
    .m_axi_vertical_arsize(m_axi_vertical_arsize),
    .m_axi_vertical_arburst(m_axi_vertical_arburst),
    .m_axi_vertical_arvalid(m_axi_vertical_arvalid),
    .m_axi_vertical_arready(m_axi_vertical_arready),
    .m_axi_vertical_rid(m_axi_vertical_rid),
    .m_axi_vertical_rdata(m_axi_vertical_rdata),
    .m_axi_vertical_rresp(m_axi_vertical_rresp),
    .m_axi_vertical_rlast(m_axi_vertical_rlast),
    .m_axi_vertical_rvalid(m_axi_vertical_rvalid),
    .m_axi_vertical_rready(m_axi_vertical_rready),

    .interrupt_router(interrupt_router),

    //MAC
    .matrix_type_mac(matrix_type_mac),
    .dtype_mac(dtype_mac),
    .col_x_mac(col_x_mac),

    .X_read_start(X_read_start),
    .Y_read_start(Y_read_start),
    .XY_data(XY_data),
    .XY_valid(XY_valid),
    .XY_read_finish(XY_read_finish),

    .Z_calc_start(Z_calc_start),
    .Z_read_start(Z_read_start),
    .Z_data(Z_data),
    .Z_valid(Z_valid),
    .Z_calc_finish(Z_calc_finish),
    .Z_read_finish(Z_read_finish),

    .sram_X_en_router(sram_X_en_router),     
    .A_X_router(A_X_router),
    .CEB_X_router(CEB_X_router),
    .WEB_X_router(WEB_X_router),
    .D_X_router(D_X_router), 
    .Q_X_router(Q_X_router),

    .sram_Z_en_router(sram_Z_en_router),       
    .A_Z_router(A_Z_router),
    .CEB_Z_router(CEB_Z_router),

    //CONFIG FIFO
    .pop_n_router(pop_n_router),
    .empty_router(empty_router),
    .rdata_router(rdata_router)
);

MAC MAC_0(
    .clk_data_bus(clk_data_bus),
    .rst_n(rst_n),
    //CONFIG information
    .matrix_type_mac(matrix_type_mac), 
    .dtype_mac(dtype_mac),  
    .col_x_mac(col_x_mac), 

    //XY data
    .X_read_start(X_read_start),
    .Y_read_start(Y_read_start),
    .XY_data(XY_data),
    .XY_valid(XY_valid),
    .XY_read_finish(XY_read_finish),

    //Z data
    .Z_calc_start(Z_calc_start),
    .Z_read_start(Z_read_start),
    .Z_data(Z_data),
    .Z_valid(Z_valid),
    .Z_read_finish(Z_read_finish),
    .Z_calc_finish(Z_calc_finish),

    .sram_X_en_router(sram_X_en_router), 
    .A_X_router(A_X_router),
    .CEB_X_router(CEB_X_router),
    .WEB_X_router(WEB_X_router),
    .D_X_router(D_X_router), 
    .Q_X_router(Q_X_router),

    .sram_Z_en_router(sram_Z_en_router),       
    .A_Z_router(A_Z_router),
    .CEB_Z_router(CEB_Z_router)
);

DW_fifo_2c_df #(
    .width(39),         
    .ram_depth(4),    
    .mem_mode(3),
    .f_sync_type(2),
    .r_sync_type(2),
    .clk_ratio(4),
    .rst_mode(0),
    .err_mode(0),
    .tst_mode(0),
    .verif_en(1),
    .clr_dual_domain(1),
    .arch_type(0)       
) fifo_config (
    .clk_s(clk_ctrl_bus),       // Source Domain Clock (input)
    .rst_s_n(rst_n),            // Source Domain Asynchronous Reset (active low) (input)
    .init_s_n(1'b1),            // Source Domain Synchronous Reset (active low) (input)
    .clr_s(1'b0),               // Source Domain Clear for coordinated reset (active high pulse) (input)
    .ae_level_s(),              // Source Domain RAM almost empty threshold setting (input)
    .af_level_s(),              // Source Domain RAM almost full threshold setting (input)
    .push_s_n(push_n_config),   // Source Domain push request (active low) (input)
    .data_s(pdata_config),      // Source Domain push data (input)

    .clr_sync_s(),          // Source Domain synchronized clear (active high pulse) (output)
    .clr_in_prog_s(),       // Source Domain orchestrate clearing in progress (unregistered) (output)
    .clr_cmplt_s(),         // Source Domain orchestrated clearing complete (active high pulse) (output)
    .fifo_word_cnt_s(),     // Source Domain FIFO word count (includes cache) (output)
    .word_cnt_s(),          // Source Domain RAM only word count (output)
    .fifo_empty_s(),        // Source Domain FIFO Empty Flag (output)
    .empty_s(),             // Source Domain RAM Empty Flag (output)
    .almost_empty_s(),      // Source Domain RAM Almost Empty Flag (output)
    .half_full_s(),         // Source Domain RAM Half Full Flag (output)
    .almost_full_s(),       // Source Domain RAM Almost Full Flag (output)
    .full_s(),	            // Source Domain RAM Full Flag (output)
    .error_s(),             // Source Domain Error Flag (output)

    .clk_d(clk_data_bus),   // Destination Domain Clock (input)
    .rst_d_n(rst_n),        // Destination Domain Asynchronous Reset (active low) (input)
    .init_d_n(1'b1),        // Destination Domain Synchronous Reset (active low) (input)
    .clr_d(1'b0),           // Destination Domain Clear to initiate orchestrated reset (active high pulse) (input)
    .ae_level_d(),          // Destination Domain FIFO almost empty threshold setting (input)
    .af_level_d(),          // Destination Domain FIFO almost full threshold setting (input)
    .pop_d_n(pop_n_router), // Destination Domain pop request (active low) (input)

    .clr_sync_d(),              // Destination Domain synchronized orchestrated clear (active high pulse) (output)
    .clr_in_prog_d(),           // Destination Domain orchestrate clearing in progress (unregistered) (output)
    .clr_cmplt_d(),             // Destination Domain orchestrated clearing complete (active high pulse) (output)
    .data_d(rdata_router),      // Destination Domain pop data (output)
    .word_cnt_d(),              // Destination Domain FIFO word count (includes cache) (output)
    .empty_d(empty_router),     // Destination Domain Empty Flag (output)
    .almost_empty_d(),          // Destination Domain Almost Empty Flag (output)
    .half_full_d(),             // Destination Domain Half Full Flag (output)
    .almost_full_d(),           // Destination Domain Almost Full Flag (output)
    .full_d(),                  // Destination Domain Full Flag (output)
    .error_d(),                 // Destination Domain Error Flag (output)

    .test()                     // Test input (input)
);
DW_pulse_sync #(
    .reg_event(1),
    .f_sync_type(2),
    .tst_mode(0),
    .verif_en(1),
    .pulse_mode(0)
) pulse_sync (
    .clk_s(clk_data_bus), 
	.rst_s_n(rst_n), 
	.init_s_n(1'b1), 
	.event_s(interrupt_router), 
	.clk_d(clk_ctrl_bus), 
    .rst_d_n(rst_n), 
	.init_d_n(1'b1),
	.event_d(interrupt_out),
	.test()
);
endmodule
