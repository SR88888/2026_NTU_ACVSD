module MAC(
    input  logic clk_data_bus,
    input  logic rst_n,
    //CONFIG information
    input  logic [  1:0]    matrix_type_mac, //0:x, 1:y, 2:z
    input  logic [  1:0]    dtype_mac,  
    input  logic [  1:0]    col_x_mac,  //0:256, 1:512, 2:768, 3:1024

    //XY data
    input  logic            X_read_start,
    input  logic            Y_read_start,
    input  logic [127:0]    XY_data,
    input  logic            XY_valid,
    input  logic            XY_read_finish,

    //Z data
    input  logic            Z_calc_start,
    input  logic            Z_read_start,
    output logic [255:0]    Z_data,
    output logic            Z_valid,
    output logic            Z_read_finish,
    output logic            Z_calc_finish,

    input  logic            sram_X_en_router,      //use X as the buffer for Z from neighbor
    input  logic [  6:0]    A_X_router,
    input  logic [  1:0]    CEB_X_router,
    input  logic [  1:0]    WEB_X_router,
    input  logic [127:0]    D_X_router, 
    output logic [127:0]    Q_X_router,

    input  logic            sram_Z_en_router,       
    input  logic [  6:0]    A_Z_router,
    input  logic [  3:0]    CEB_Z_router
);
localparam S_IDLE       = 3'd0;
localparam S_READ_X     = 3'd1;
localparam S_READ_Y     = 3'd2;
localparam S_DELAY_CALC = 3'd3;
localparam S_CALC_Z     = 3'd4;
localparam S_DELAY_OUT_Z= 3'd5;
localparam S_OUT_Z      = 3'd6;
logic [2:0] state, state_next;
logic state_IDLE, state_READ_X, state_READ_Y, state_DELAY_CALC, state_CALC_Z, state_DELAY_OUT_Z, state_OUT_Z;
assign state_IDLE       = (state == S_IDLE);
assign state_READ_X     = (state == S_READ_X);
assign state_READ_Y     = (state == S_READ_Y);
assign state_DELAY_CALC = (state == S_DELAY_CALC);
assign state_CALC_Z     = (state == S_CALC_Z);
assign state_DELAY_OUT_Z= (state == S_DELAY_OUT_Z);
assign state_OUT_Z      = (state == S_OUT_Z);

logic [ 1:0] col_num_x;     //0:256, 1:512, 2:768, 3:1024
logic [ 4:0] col_x_counter; 

logic [ 9:0] read_z_counter;
logic [ 9:0] write_z_counter;

logic [ 6:0] A_X;
logic [ 1:0] CEB_X;
logic [ 1:0] WEB_X;
logic [63:0] D_X [0:1];
logic [63:0] Q_X [0:1];

logic [ 6:0] A_Y;
logic [ 1:0] CEB_Y;
logic [ 1:0] WEB_Y;
logic [63:0] D_Y [0:1];
logic [63:0] Q_Y [0:1];

logic [ 6:0] A_Z;
logic [ 3:0] CEB_Z;
logic [ 3:0] WEB_Z;
logic [63:0] D_Z [0:3];
logic [63:0] Q_Z [0:3];
logic [63:0] BWEB_Z [0:3];

assign Z_data = {Q_Z[3], Q_Z[2], Q_Z[1], Q_Z[0]};
assign Q_X_router = {Q_X[1], Q_X[0]};

//pipeline stage 1
logic [15:0] E4M3_BF16_X [0:15];
logic [15:0] E4M3_BF16_Y [0:15];
logic [15:0] E5M2_BF16_X [0:15];
logic [15:0] E5M2_BF16_Y [0:15];
logic [15:0] mul_X [0:15];
logic [15:0] mul_Y [0:15];
logic [15:0] mul_result     [0:15];
logic [31:0] add_L1_result  [0: 7];
logic [15:0] mul_DG;
logic [ 7:0] add_L1_DG;
logic [ 2:0] calc_sequence_01;
//pipeline stage 1/2
logic [31:0] add_result_12   [0:7];
logic [ 2:0] calc_sequence_12;
//pipeline stage 2
logic [31:0] add_L2_result [0:3];
logic [31:0] add_L3_result [0:1];
logic [ 3:0] add_L2_DG;     
logic [ 1:0] add_L3_DG;
//pipeline stage 2/3
logic [31:0] add_result_23   [0:1];
logic [ 2:0] calc_sequence_23;
//pipeline stage 3
logic [31:0] add_L4_result;
logic [31:0] add_ACC_result;
logic        add_L4_DG;
logic        add_ACC_DG;
logic [31:0] ACC;
//============FSM============
logic S_CALC_Z_finish;
assign S_CALC_Z_finish = ((&write_z_counter) & 
                        (((~|dtype_mac) & (calc_sequence_23 == 3'd4)) | 
                         (( |dtype_mac) & (calc_sequence_23 == 3'd2))));
always @(*) begin
    case(state)
        S_IDLE:         state_next = X_read_start ? S_READ_X : 
                                     Y_read_start ? S_READ_Y : 
                                     Z_calc_start ? S_DELAY_CALC  : 
                                     Z_read_start ? S_DELAY_OUT_Z : S_IDLE;
        S_READ_X:       state_next = XY_read_finish ? S_IDLE : S_READ_X; 
        S_READ_Y:       state_next = XY_read_finish ? S_IDLE : S_READ_Y;
        S_DELAY_CALC:   state_next = S_CALC_Z;
        S_CALC_Z:       state_next = S_CALC_Z_finish ? S_IDLE : S_CALC_Z;
        S_DELAY_OUT_Z:  state_next = S_OUT_Z;
        S_OUT_Z:        state_next = (&read_z_counter[9:3]) ? S_IDLE : S_OUT_Z;
        default:        state_next = state;
    endcase
end
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) state <= S_IDLE;
    else state <= state_next;
end

//============col_num_x============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) col_num_x <= 2'd0;
    else if(~|matrix_type_mac) col_num_x <= col_x_mac;
end
//============col_x_counter============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) col_x_counter <= 5'd0;
    else if(state_CALC_Z & (state_next == S_IDLE)) begin
        case(col_num_x)
            2'd0:   col_x_counter <= (col_x_counter == 5'd7 ) ? 5'd0 : col_x_counter + 5'd1;
            2'd1:   col_x_counter <= (col_x_counter == 5'd15) ? 5'd0 : col_x_counter + 5'd1;
            2'd2:   col_x_counter <= (col_x_counter == 5'd23) ? 5'd0 : col_x_counter + 5'd1;
            2'd3:   col_x_counter <= (col_x_counter == 5'd31) ? 5'd0 : col_x_counter + 5'd1;
        endcase
    end
end
//============Z_calc_finish============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) Z_calc_finish <= 1'b0;
    else Z_calc_finish <= (state_CALC_Z & (state_next == S_IDLE));
end

//SRAM_X
//============A_X============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n)
        A_X <= 7'd0;
    else if(state_READ_X)
        A_X <= (~|CEB_X) ? A_X + 7'd1 : A_X;
    else if(state_DELAY_CALC | state_CALC_Z) begin
        if(~|dtype_mac) begin
            if(&A_Y)
                A_X <= A_X + 7'd1;
            else
                A_X <= (&A_X[1:0]) ? {A_X[6:2], 2'd0} : A_X + 7'd1;
        end
        else begin
            if(&A_Y[5:0])
                A_X <= A_X + 7'd1;
            else 
                A_X <= A_X[0] ? {A_X[6:1], 1'b0} : {A_X[6:1], 1'b1};
        end
    end
    else A_X <= 7'd0;
end
//============CEB_X============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) CEB_X <= 2'b11;
    else if(state_READ_X)
        CEB_X <= XY_valid ? 2'b00 : 2'b11;
    else if((state_next == S_DELAY_CALC) | (state_next == S_CALC_Z))
        CEB_X <= 2'b00;
    else CEB_X <= 2'b11;
end
//============WEB_X============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) WEB_X <= 2'b11;
    else if(state_READ_X) begin
        WEB_X <= XY_valid ? 2'b00 : 2'b11;
    end
    else WEB_X <= 2'b11;
end
//============D_X============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) begin
        D_X[0] <= 64'd0;
        D_X[1] <= 64'd0;
    end
    else if(state_READ_X) begin
        D_X[0] <= XY_data[ 63: 0];
        D_X[1] <= XY_data[127:64];
    end
end

//SRAM_Y 
//============A_Y============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) 
        A_Y <= 7'd0;
    else if(state_READ_Y) 
        A_Y <= (~|CEB_Y) ? A_Y + 7'd1 : A_Y;
    else if(state_DELAY_CALC | state_CALC_Z) begin
        if(~|dtype_mac) 
            A_Y <= A_Y + 7'd1;
        else 
            A_Y <= (A_Y == 7'd63) ? 7'd0 : A_Y + 7'd1;
    end
    else A_Y <= 7'd0;
end
//============CEB_Y============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) CEB_Y <= 2'b11;
    else if(state_READ_Y) 
        CEB_Y <= XY_valid ? 2'b00 : 2'b11;
    else if((state_next == S_DELAY_CALC) | (state_next == S_CALC_Z)) 
        CEB_Y <= 2'b00;
    else CEB_Y <= 2'b11;
end
//============WEB_Y============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) WEB_Y <= 2'b11;
    else if(state_READ_Y)
        WEB_Y <= XY_valid ? 2'b00 : 2'b11;
    else WEB_Y <= 2'b11;
end
//============D_Y============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) begin
        D_Y[0] <= 64'd0;
        D_Y[1] <= 64'd0;
    end
    else if(state_READ_Y) begin
        D_Y[0] <= XY_valid ? XY_data[ 63: 0] : D_Y[0];
        D_Y[1] <= XY_valid ? XY_data[127:64] : D_Y[1];
    end
end

//SRAM_Z
//============A_Z============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) 
        A_Z <= 7'd0;
    else if(state_CALC_Z &  //write
            (((~|dtype_mac) & (calc_sequence_23 == 3'd4)) | 
             (( |dtype_mac) & (calc_sequence_23 == 3'd2)))) begin
        A_Z <= write_z_counter[9:3];
    end
    else if(state_CALC_Z & (calc_sequence_01 == 3'd1))  //read
        A_Z <= read_z_counter[9:3];
    else if(state_next == S_DELAY_OUT_Z) 
        A_Z <= 7'd0;
    else if(state_next == S_OUT_Z)
        A_Z <= A_Z + 7'd1;
end
//============CEB_Z============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) CEB_Z <= 4'b1111;
    else if(state_CALC_Z & 
            (((~|dtype_mac) & (calc_sequence_23 == 3'd4)) | //write
             (( |dtype_mac) & (calc_sequence_23 == 3'd2)))) begin
        if((write_z_counter[2:0] == 3'd0) | (write_z_counter[2:0] == 3'd1))
            CEB_Z[0] <= 1'b0;
        else CEB_Z[0] <= 1'b1;
        if((write_z_counter[2:0] == 3'd2) | (write_z_counter[2:0] == 3'd3))
            CEB_Z[1] <= 1'b0;
        else CEB_Z[1] <= 1'b1;
        if((write_z_counter[2:0] == 3'd4) | (write_z_counter[2:0] == 3'd5))
            CEB_Z[2] <= 1'b0;
        else CEB_Z[2] <= 1'b1;
        if((write_z_counter[2:0] == 3'd6) | (write_z_counter[2:0] == 3'd7))
            CEB_Z[3] <= 1'b0;
        else CEB_Z[3] <= 1'b1;
    end
    else if(state_CALC_Z & (calc_sequence_01 == 3'd1)) begin    //read
        if((read_z_counter[2:0] == 3'd0) | (read_z_counter[2:0] == 3'd1))
            CEB_Z[0] <= 1'b0;
        else CEB_Z[0] <= 1'b1;
        if((read_z_counter[2:0] == 3'd2) | (read_z_counter[2:0] == 3'd3))
            CEB_Z[1] <= 1'b0;
        else CEB_Z[1] <= 1'b1;
        if((read_z_counter[2:0] == 3'd4) | (read_z_counter[2:0] == 3'd5))
            CEB_Z[2] <= 1'b0;
        else CEB_Z[2] <= 1'b1;
        if((read_z_counter[2:0] == 3'd6) | (read_z_counter[2:0] == 3'd7))
            CEB_Z[3] <= 1'b0;
        else CEB_Z[3] <= 1'b1;
    end
    else if((state_next == S_DELAY_OUT_Z) | (state_next == S_OUT_Z))
        CEB_Z <= 4'b0000;
    else CEB_Z <= 4'b1111;
end
//============WEB_Z============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) WEB_Z <= 4'b1111;
    else if(state_CALC_Z & 
            (((~|dtype_mac) & (calc_sequence_23 == 3'd4)) | 
             (( |dtype_mac) & (calc_sequence_23 == 3'd2)))) begin
        if((write_z_counter[2:0] == 3'd0) | (write_z_counter[2:0] == 3'd1))
            WEB_Z[0] <= 1'b0;
        else WEB_Z[0] <= 1'b1;
        if((write_z_counter[2:0] == 3'd2) | (write_z_counter[2:0] == 3'd3))
            WEB_Z[1] <= 1'b0;
        else WEB_Z[1] <= 1'b1;
        if((write_z_counter[2:0] == 3'd4) | (write_z_counter[2:0] == 3'd5))
            WEB_Z[2] <= 1'b0;
        else WEB_Z[2] <= 1'b1;
        if((write_z_counter[2:0] == 3'd6) | (write_z_counter[2:0] == 3'd7))
            WEB_Z[3] <= 1'b0;
        else WEB_Z[3] <= 1'b1;
    end
    else WEB_Z <= 4'b1111;
end
//============D_Z============
integer i13;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n)
        for(i13=0 ; i13<4 ; i13=i13+1) 
            D_Z[i13] <= 64'd0;
    else if(state_CALC_Z & 
            (((~|dtype_mac) & (calc_sequence_23 == 3'd4)) | 
             (( |dtype_mac) & (calc_sequence_23 == 3'd2)))) begin
        for(i13=0 ; i13<4 ; i13=i13+1) 
            D_Z[i13] <= {add_ACC_result, add_ACC_result};
    end
end
//============BWEB_Z============
integer i14;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) 
        for(i14=0 ; i14<4 ; i14=i14+1) 
            BWEB_Z[i14] <= 64'hFFFF_FFFF_FFFF_FFFF;
    else if(state_CALC_Z & 
            (((~|dtype_mac) & (calc_sequence_23 == 3'd4)) | 
             (( |dtype_mac) & (calc_sequence_23 == 3'd2)))) begin
        if(write_z_counter[2:0] == 3'd0) 
            BWEB_Z[0] <= 64'hFFFF_FFFF_0000_0000;
        else if(write_z_counter[2:0] == 3'd1) 
            BWEB_Z[0] <= 64'h0000_0000_FFFF_FFFF;
        else BWEB_Z[0] <= 64'hFFFF_FFFF_FFFF_FFFF;
        if(write_z_counter[2:0] == 3'd2) 
            BWEB_Z[1] <= 64'hFFFF_FFFF_0000_0000;
        else if(write_z_counter[2:0] == 3'd3) 
            BWEB_Z[1] <= 64'h0000_0000_FFFF_FFFF;
        else BWEB_Z[1] <= 64'hFFFF_FFFF_FFFF_FFFF;
        if(write_z_counter[2:0] == 3'd4) 
            BWEB_Z[2] <= 64'hFFFF_FFFF_0000_0000;
        else if(write_z_counter[2:0] == 3'd5) 
            BWEB_Z[2] <= 64'h0000_0000_FFFF_FFFF;
        else BWEB_Z[2] <= 64'hFFFF_FFFF_FFFF_FFFF;
        if(write_z_counter[2:0] == 3'd6) 
            BWEB_Z[3] <= 64'hFFFF_FFFF_0000_0000;
        else if(write_z_counter[2:0] == 3'd7) 
            BWEB_Z[3] <= 64'h0000_0000_FFFF_FFFF;
        else BWEB_Z[3] <= 64'hFFFF_FFFF_FFFF_FFFF;
    end
    else 
        for(i14=0 ; i14<4 ; i14=i14+1) 
            BWEB_Z[i14] <= 64'hFFFF_FFFF_FFFF_FFFF;
end
//============read_z_counter============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) read_z_counter <= 10'd0;
    else if(state_CALC_Z)
        read_z_counter <= (calc_sequence_01 == 3'd1) ? read_z_counter + 10'd1 : read_z_counter;
    else if(state_OUT_Z) 
        read_z_counter <= read_z_counter + 10'd8;
    else read_z_counter <= 10'd0;
end
//============write_z_counter============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) write_z_counter <= 10'd0;
    else if(state_CALC_Z) begin
        if(((~|dtype_mac) & (calc_sequence_23 == 3'd4)) | (( |dtype_mac) & (calc_sequence_23 == 3'd2)))
            write_z_counter <= write_z_counter + 10'd1;   
        else write_z_counter <= write_z_counter;
    end
    else write_z_counter <= 10'd0;
end
//============Z_valid============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) Z_valid <= 1'b0;
    else Z_valid <= (state_next == S_OUT_Z);
end
//============Z_read_finish============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) Z_read_finish <= 1'b0;
    else Z_read_finish <= (state_OUT_Z & (read_z_counter[9:3] == 7'd126));
end

//============SRAM_X============
logic [ 6:0] A_X_SEL;
logic [ 1:0] CEB_X_SEL;
logic [ 1:0] WEB_X_SEL;
logic [63:0] D_X_SEL [0:1]; 
assign A_X_SEL = sram_X_en_router ? A_X_router : A_X;
assign CEB_X_SEL = sram_X_en_router ? CEB_X_router : CEB_X;
assign WEB_X_SEL = sram_X_en_router ? WEB_X_router : WEB_X;
assign D_X_SEL[0] = sram_X_en_router ? D_X_router[ 63: 0] : D_X[0];
assign D_X_SEL[1] = sram_X_en_router ? D_X_router[127:64] : D_X[1];
genvar sram_xi;
generate
    for(sram_xi=0 ; sram_xi<2 ; sram_xi=sram_xi+1) begin : gen_SRAM_X
        TS1N16ADFPCLLLVTA128X64M4SWSHOD SRAM_X(
            .A(A_X_SEL),   .CEB(CEB_X_SEL[sram_xi]), .CLK(clk_data_bus), .WEB(WEB_X_SEL[sram_xi]),
            .D(D_X_SEL[sram_xi]),   .Q(Q_X[sram_xi]),
            .BWEB(64'd0),    .RTSEL(2'b01),   .WTSEL(2'b01),
            .SLP(1'b0), .DSLP(1'b0),    .SD(1'b0),
            .PUDELAY()
        );
    end
endgenerate
//============SRAM_Y============
genvar sram_yi;
generate 
    for(sram_yi=0 ; sram_yi<2 ; sram_yi=sram_yi+1) begin : gen_SRAM_Y
        TS1N16ADFPCLLLVTA128X64M4SWSHOD SRAM_Y(
            .A(A_Y),   .CEB(CEB_Y[sram_yi]), .CLK(clk_data_bus), .WEB(WEB_Y[sram_yi]),
            .D(D_Y[sram_yi]),   .Q(Q_Y[sram_yi]),
            .BWEB(64'd0),    .RTSEL(2'b01),   .WTSEL(2'b01),
            .SLP(1'b0), .DSLP(1'b0),    .SD(1'b0),
            .PUDELAY()
        );
    end
endgenerate
//============SRAM_Z============
logic [6:0] A_Z_SEL;
logic [3:0] CEB_Z_SEL;
assign A_Z_SEL = sram_Z_en_router ? A_Z_router : A_Z;
assign CEB_Z_SEL = sram_Z_en_router ? CEB_Z_router : CEB_Z; 
genvar sram_zi;
generate
    for(sram_zi=0 ; sram_zi<4 ; sram_zi=sram_zi+1) begin : gen_SRAM_Z
        TS1N16ADFPCLLLVTA128X64M4SWSHOD SRAM_Z(
            .A(A_Z_SEL),   .CEB(CEB_Z_SEL[sram_zi]), .CLK(clk_data_bus), .WEB(WEB_Z[sram_zi]),
            .D(D_Z[sram_zi]),   .Q(Q_Z[sram_zi]),   .BWEB(BWEB_Z[sram_zi]),    
            .RTSEL(2'b01),   .WTSEL(2'b01),
            .SLP(1'b0), .DSLP(1'b0),    .SD(1'b0),
            .PUDELAY()
        );
    end
endgenerate
//============pipeline stage 1============
//============FP8-E4M3->BF16-E8M7============
integer i0, i1;
always @(*) begin
    for(i0=0 ; i0<8 ; i0=i0+1) begin
        if(~|Q_X[0][(i0*8+3)+:4])   // subnormal/zero
            E4M3_BF16_X[i0] = 16'd0;
        else if((&Q_X[0][(i0*8+3)+:4]) && (&Q_X[0][(i0*8)+:3])) begin 
            E4M3_BF16_X[i0][ 6:0] = 7'b111_0000; // Quiet NaN
            E4M3_BF16_X[i0][14:7] = 8'd255;
            E4M3_BF16_X[i0][15]   = Q_X[0][i0*8+7];
        end 
        else begin
            E4M3_BF16_X[i0][ 6:0] = {Q_X[0][(i0*8)+:3], 4'd0};
            E4M3_BF16_X[i0][14:7] = {4'd0, Q_X[0][(i0*8+3)+:4]} + 8'd120;
            E4M3_BF16_X[i0][15]   = Q_X[0][i0*8+7];
        end

        if(~|Q_Y[0][(i0*8+3)+:4]) 
            E4M3_BF16_Y[i0] = 16'd0;
        else if((&Q_Y[0][(i0*8+3)+:4]) && (&Q_Y[0][(i0*8)+:3])) begin 
            E4M3_BF16_Y[i0][ 6:0] = 7'b111_0000;
            E4M3_BF16_Y[i0][14:7] = 8'd255;
            E4M3_BF16_Y[i0][15]   = Q_Y[0][i0*8+7];
        end
        else begin
            E4M3_BF16_Y[i0][ 6:0] = {Q_Y[0][(i0*8)+:3], 4'd0};
            E4M3_BF16_Y[i0][14:7] = {4'd0, Q_Y[0][(i0*8+3)+:4]} + 8'd120;
            E4M3_BF16_Y[i0][15]   = Q_Y[0][i0*8+7];
        end 
    end

    for(i1=0 ; i1<8 ; i1=i1+1) begin
        if(~|Q_X[1][(i1*8+3)+:4]) 
            E4M3_BF16_X[i1+8] = 16'd0;
        else if((&Q_X[1][(i1*8+3)+:4]) && (&Q_X[1][(i1*8)+:3])) begin 
            E4M3_BF16_X[i1+8][ 6:0] = 7'b111_0000;
            E4M3_BF16_X[i1+8][14:7] = 8'd255;
            E4M3_BF16_X[i1+8][15]   = Q_X[1][i1*8+7];
        end
        else begin
            E4M3_BF16_X[i1+8][ 6:0] = {Q_X[1][(i1*8)+:3], 4'd0};
            E4M3_BF16_X[i1+8][14:7] = {4'd0, Q_X[1][(i1*8+3)+:4]} + 8'd120;
            E4M3_BF16_X[i1+8][15]   = Q_X[1][i1*8+7];
        end

        if(~|Q_Y[1][(i1*8+3)+:4]) 
            E4M3_BF16_Y[i1+8] = 16'd0;
        else if((&Q_Y[1][(i1*8+3)+:4]) && (&Q_Y[1][(i1*8)+:3])) begin 
            E4M3_BF16_Y[i1+8][ 6:0] = 7'b111_0000;
            E4M3_BF16_Y[i1+8][14:7] = 8'd255;
            E4M3_BF16_Y[i1+8][15]   = Q_Y[1][i1*8+7];
        end
        else begin
            E4M3_BF16_Y[i1+8][ 6:0] = {Q_Y[1][(i1*8)+:3], 4'd0};
            E4M3_BF16_Y[i1+8][14:7] = {4'd0, Q_Y[1][(i1*8+3)+:4]} + 8'd120;
            E4M3_BF16_Y[i1+8][15]   = Q_Y[1][i1*8+7];
        end
    end
end
//============FP8-E5M2->BF16-E8M7============
integer i2, i3;
always @(*) begin
    for(i2=0 ; i2<8 ; i2=i2+1) begin 
        if(~|Q_X[0][(i2*8+2)+:5])   // subnormal/zero
            E5M2_BF16_X[i2] = 16'd0;
        else if(&Q_X[0][(i2*8+2)+:5]) begin // infinity/NAN
            E5M2_BF16_X[i2][ 6:0] = (|Q_X[0][(i2*8)+:2]) ? {1'b1, Q_X[0][(i2*8)+:2], 4'd0} : 7'd0;
            E5M2_BF16_X[i2][14:7] = 8'd255;
            E5M2_BF16_X[i2][15]   = Q_X[0][i2*8+7];
        end
        else begin
            E5M2_BF16_X[i2][ 6:0] = {Q_X[0][(i2*8)+:2], 5'd0};
            E5M2_BF16_X[i2][14:7] = {3'd0, Q_X[0][(i2*8+2)+:5]} + 8'd112;
            E5M2_BF16_X[i2][15]   = Q_X[0][i2*8+7];
        end

        if(~|Q_Y[0][(i2*8+2)+:5]) 
            E5M2_BF16_Y[i2] = 16'd0;
        else if(&Q_Y[0][(i2*8+2)+:5]) begin 
            E5M2_BF16_Y[i2][ 6:0] = (|Q_Y[0][(i2*8)+:2]) ? {1'b1, Q_Y[0][(i2*8)+:2], 4'd0} : 7'd0;
            E5M2_BF16_Y[i2][14:7] = 8'd255;
            E5M2_BF16_Y[i2][15]   = Q_Y[0][i2*8+7];
        end
        else begin
            E5M2_BF16_Y[i2][ 6:0] = {Q_Y[0][(i2*8)+:2], 5'd0};
            E5M2_BF16_Y[i2][14:7] = {3'd0, Q_Y[0][(i2*8+2)+:5]} + 8'd112;
            E5M2_BF16_Y[i2][15]   = Q_Y[0][i2*8+7];
        end
    end

    for(i3=0 ; i3<8 ; i3=i3+1) begin
        if(~|Q_X[1][(i3*8+2)+:5]) 
            E5M2_BF16_X[i3+8] = 16'd0;
        else if(&Q_X[1][(i3*8+2)+:5]) begin 
            E5M2_BF16_X[i3+8][ 6:0] = (|Q_X[1][(i3*8)+:2]) ? {1'b1, Q_X[1][(i3*8)+:2], 4'd0} : 7'd0;
            E5M2_BF16_X[i3+8][14:7] = 8'd255;
            E5M2_BF16_X[i3+8][15]   = Q_X[1][i3*8+7];
        end
        else begin
            E5M2_BF16_X[i3+8][ 6:0] = {Q_X[1][(i3*8)+:2], 5'd0};
            E5M2_BF16_X[i3+8][14:7] = {3'd0, Q_X[1][(i3*8+2)+:5]} + 8'd112;
            E5M2_BF16_X[i3+8][15]   = Q_X[1][i3*8+7];
        end

        if(~|Q_Y[1][(i3*8+2)+:5]) 
            E5M2_BF16_Y[i3+8] = 16'd0;
        else if (&Q_Y[1][(i3*8+2)+:5]) begin 
            E5M2_BF16_Y[i3+8][ 6:0] = (|Q_Y[1][(i3*8)+:2]) ? {1'b1, Q_Y[1][(i3*8)+:2], 4'd0} : 7'd0;
            E5M2_BF16_Y[i3+8][14:7] = 8'd255;
            E5M2_BF16_Y[i3+8][15]   = Q_Y[1][i3*8+7];
        end
        else begin
            E5M2_BF16_Y[i3+8][ 6:0] = {Q_Y[1][(i3*8)+:2], 5'd0};
            E5M2_BF16_Y[i3+8][14:7] = {3'd0, Q_Y[1][(i3*8+2)+:5]} + 8'd112;
            E5M2_BF16_Y[i3+8][15]   = Q_Y[1][i3*8+7];
        end
    end
end
//============multiplicand============
integer i4, i10, i11;
always @(*) begin
    if(~|dtype_mac) begin
        for(i4=0 ; i4<4 ; i4=i4+1) begin
            mul_X[i4] = Q_X[0][(i4*16)+:16];
            mul_Y[i4] = Q_Y[0][(i4*16)+:16];
        end
        for(i10=0 ; i10<4 ; i10=i10+1) begin
            mul_X[i10+4] = Q_X[1][(i10*16)+:16];
            mul_Y[i10+4] = Q_Y[1][(i10*16)+:16];
        end
        for(i11=8 ; i11<16 ; i11=i11+1) begin
            mul_X[i11] = 16'd0;
            mul_Y[i11] = 16'd0;
        end
    end
    else if(dtype_mac == 2'd1) begin    //FP8-E4M3
        for(i4=0 ; i4<16 ; i4=i4+1) begin
            mul_X[i4] = E4M3_BF16_X[i4];
            mul_Y[i4] = E4M3_BF16_Y[i4];
        end
    end
    else begin  //FP8-E5M2
        for(i4=0 ; i4<16 ; i4=i4+1) begin
            mul_X[i4] = E5M2_BF16_X[i4];
            mul_Y[i4] = E5M2_BF16_Y[i4];
        end
    end
end
genvar mul_i;
generate 
    for(mul_i=0 ; mul_i<16 ; mul_i=mul_i+1) begin : gen_MUL
        DW_fp_mult_DG #(
            .sig_width(7),
            .exp_width(8),
            .ieee_compliance(1)
        ) fp_mult (
            .a(mul_X[mul_i]),   .b(mul_Y[mul_i]),   .rnd(3'b000),
            .DG_ctrl(mul_DG[mul_i]),
            .z(mul_result[mul_i]),
            .status()
        );
    end
endgenerate 
genvar add_L1_i;
generate 
    for(add_L1_i=0 ; add_L1_i<8 ; add_L1_i=add_L1_i+1) begin : gen_ADD_L1
        DW_fp_add_DG #(
            .sig_width(23), 
            .exp_width(8),
            .ieee_compliance(1)
        ) fp_add_L1 (
            .a({mul_result[add_L1_i*2], 16'd0}), .b({mul_result[add_L1_i*2+1], 16'd0}), .rnd(3'b000),
            .DG_ctrl(add_L1_DG[add_L1_i]), .z(add_L1_result[add_L1_i]), .status()
        );
    end
endgenerate 
//============calc_sequence_01============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) calc_sequence_01 <= 3'd0;
    else if(state_DELAY_CALC) 
        calc_sequence_01 <= 3'd1;
    else if(state_CALC_Z) begin
        if(~|dtype_mac) 
            calc_sequence_01 <= (calc_sequence_01 == 3'd4) ? 3'd1 : calc_sequence_01 + 3'd1;
        else calc_sequence_01 <= (calc_sequence_01 == 3'd2) ? 3'd1 : calc_sequence_01 + 3'd1;
    end
    else calc_sequence_01 <= 3'd0;
end
//============pipeline register 1/2============
integer i9;
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) 
        for(i9=0 ; i9<8 ; i9=i9+1) 
            add_result_12[i9] <= 32'd0;
    else if(state_CALC_Z) 
        for(i9=0 ; i9<8 ; i9=i9+1) 
            add_result_12[i9] <= add_L1_result[i9];
end
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) calc_sequence_12 <= 3'd0;
    else if(state_CALC_Z) calc_sequence_12 <= calc_sequence_01;
    else calc_sequence_12 <= 3'd0;
end
//============pipeline stage 2============
genvar add_L2_i;
generate 
    for(add_L2_i=0 ; add_L2_i<4 ; add_L2_i=add_L2_i+1) begin : gen_ADD_L2
        DW_fp_add_DG #(
            .sig_width(23), 
            .exp_width(8),
            .ieee_compliance(1)
        ) fp_add_L2 (
            .a(add_result_12[add_L2_i*2]), .b(add_result_12[add_L2_i*2+1]), .rnd(3'b000),
            .DG_ctrl(add_L2_DG[add_L2_i]), .z(add_L2_result[add_L2_i]), .status()
        );
    end
endgenerate
genvar add_L3_i;
generate 
    for(add_L3_i=0 ; add_L3_i<2 ; add_L3_i=add_L3_i+1) begin : gen_ADD_L3
        DW_fp_add_DG #(
            .sig_width(23), 
            .exp_width(8),
            .ieee_compliance(1)
        ) fp_add_L3 (
            .a(add_L2_result[add_L3_i*2]), .b(add_L2_result[add_L3_i*2+1]), .rnd(3'b000),
            .DG_ctrl(add_L3_DG[add_L3_i]), .z(add_L3_result[add_L3_i]), .status()
        );
    end
endgenerate
//============pipeline stage 2/3============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) calc_sequence_23 <= 3'd0;
    else if(state_CALC_Z) calc_sequence_23 <= calc_sequence_12;
    else calc_sequence_23 <= 3'd0;
end
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) begin
        add_result_23[0] <= 32'd0;
        add_result_23[1] <= 32'd0;
    end
    else if(state_CALC_Z) begin
        add_result_23[0] <= add_L3_result[0];
        add_result_23[1] <= add_L3_result[1];
    end
end
//============pipeline stage 3============
DW_fp_add_DG #(        
        .sig_width(23), 
        .exp_width(8),
        .ieee_compliance(1)
    ) fp_add_L4 (
        .a(add_result_23[0]), .b(add_result_23[1]), .rnd(3'b000),
        .DG_ctrl(add_L4_DG), .z(add_L4_result), .status()
);
logic [31:0] add_ACC_a;
logic [31:0] add_ACC_b;
logic [ 9:0] read_z_counter_prev;
assign read_z_counter_prev = read_z_counter - 10'd1;
assign add_ACC_a = (~|dtype_mac) ? add_result_23[0] : add_L4_result;
always @(*) begin
    if(calc_sequence_23 == 3'd1) begin
        if(~|col_x_counter) 
            add_ACC_b = 32'd0;
        else begin
            case(read_z_counter_prev[2:0])
                3'd0:   add_ACC_b = Q_Z[0][31: 0];
                3'd1:   add_ACC_b = Q_Z[0][63:32];
                3'd2:   add_ACC_b = Q_Z[1][31: 0];
                3'd3:   add_ACC_b = Q_Z[1][63:32];
                3'd4:   add_ACC_b = Q_Z[2][31: 0];
                3'd5:   add_ACC_b = Q_Z[2][63:32];
                3'd6:   add_ACC_b = Q_Z[3][31: 0];
                3'd7:   add_ACC_b = Q_Z[3][63:32];
            endcase
        end
    end
    else add_ACC_b = ACC;
end
DW_fp_add_DG #(        
        .sig_width(23), 
        .exp_width(8),
        .ieee_compliance(1)
    ) fp_add_ACC (
        .a(add_ACC_a), .b(add_ACC_b), .rnd(3'b000),
        .DG_ctrl(add_ACC_DG), .z(add_ACC_result), .status()
);
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) ACC <= 32'd0;
    else if(state_CALC_Z) 
        ACC <= add_ACC_result;
end
//============DATA_GATING============
always_ff @(posedge clk_data_bus or negedge rst_n) begin
    if(!rst_n) begin
        mul_DG <= 16'd0;
        add_L1_DG <= 8'd0;
        add_L2_DG <= 4'd0;
        add_L3_DG <= 2'd0;
        add_L4_DG <= 1'b0;
        add_ACC_DG <= 1'b0;
    end
    else if(state_DELAY_CALC) begin
        if(~|dtype_mac) begin
            mul_DG <= 16'h00FF;
            add_L1_DG <= 8'h0F;
            add_L2_DG <= 4'b0011;
            add_L3_DG <= 2'b01;
            add_L4_DG <= 1'b0;
            add_ACC_DG <= 1'b1;
        end
        else begin
            mul_DG <= 16'hFFFF;
            add_L1_DG <= 8'hFF;
            add_L2_DG <= 4'b1111;
            add_L3_DG <= 2'b11;
            add_L4_DG <= 1'b1;
            add_ACC_DG <= 1'b1;
        end
    end
    else if(state_IDLE) begin
        mul_DG <= 16'd0;
        add_L1_DG <= 8'd0;
        add_L2_DG <= 4'd0;
        add_L3_DG <= 2'd0;
        add_L4_DG <= 1'b0;
        add_ACC_DG <= 1'b0;
    end
end
endmodule