import axi_pkg::*;

module axi4_full_checker (
    input  logic ACLK,
    input  logic ARESETn,
    axi4_full_if.monitor axif
);

    // TODO
    property Valid_signals_cannot_drop_unless_accepted(valid, ready);
        @(posedge ACLK) disable iff (!ARESETn)
        (valid && !ready) |=> valid;
    endproperty

    assert property (Valid_signals_cannot_drop_unless_accepted(axif.awvalid, axif.awready))
        else $error("AWVALID cannot drop until AWREADY is asserted");
    assert property (Valid_signals_cannot_drop_unless_accepted(axif.wvalid, axif.wready))
        else $error("WVALID cannot drop until WREADY is asserted");
    assert property (Valid_signals_cannot_drop_unless_accepted(axif.bvalid, axif.bready))
        else $error("BVALID cannot drop until BREADY is asserted");
    assert property (Valid_signals_cannot_drop_unless_accepted(axif.arvalid, axif.arready))
        else $error("ARVALID cannot drop until ARREADY is asserted");
    assert property (Valid_signals_cannot_drop_unless_accepted(axif.rvalid, axif.rready))
        else $error("RVALID cannot drop until RREADY is asserted");

    property Data_cannot_be_changed_until_handshake(data, valid, ready);
        @(posedge ACLK) disable iff (!ARESETn)
        (valid && !ready) |=> $stable(data);
    endproperty

    assert property (Data_cannot_be_changed_until_handshake({axif.awid, axif.awaddr, axif.awlen, axif.awsize, axif.awburst}, axif.awvalid, axif.awready))
        else $error("Address channel signals cannot change until handshake is complete");
    assert property (Data_cannot_be_changed_until_handshake({axif.wdata, axif.wstrb}, axif.wvalid, axif.wready))
        else $error("Write data and strobe cannot change until handshake is complete");
    assert property (Data_cannot_be_changed_until_handshake({axif.bid, axif.bresp}, axif.bvalid, axif.bready))
        else $error("Write response signals cannot change until handshake is complete");
    assert property (Data_cannot_be_changed_until_handshake({axif.arid, axif.araddr, axif.arlen, axif.arsize, axif.arburst}, axif.arvalid, axif.arready))
        else $error("Address channel signals cannot change until handshake is complete");
    assert property (Data_cannot_be_changed_until_handshake({axif.rid, axif.rdata, axif.rresp}, axif.rvalid, axif.rready))
        else $error("Read data and response signals cannot change until handshake is complete");

    property Size_of_bus_should_be_eq_or_lt_128(data_bus);
        @(posedge ACLK) disable iff (!ARESETn)
        $bits(data_bus) <= 128;
    endproperty

    assert property (Size_of_bus_should_be_eq_or_lt_128(axif.wdata))
        else $error("Data bus width should be less than or equal to 128 bits");
    assert property (Size_of_bus_should_be_eq_or_lt_128(axif.rdata))
        else $error("Data bus width should be less than or equal to 128 bits");

    logic [AXI_LEN_W-1:0] AWLEN;
    logic                 WR_IN_PROGRESS;
    always_ff @(posedge ACLK or negedge ARESETn) begin
        if (!ARESETn) begin
            AWLEN <= 0;
            WR_IN_PROGRESS <= 0;
        end
        else begin
            if (axif.awvalid && axif.awready) begin
                AWLEN <= axif.awlen;
                WR_IN_PROGRESS <= 1'b1;
            end
            else if (axif.wvalid && axif.wready) begin
                if (AWLEN == 0) WR_IN_PROGRESS <= 1'b0;
                else AWLEN <= AWLEN - 1;
            end
        end
    end

    property WLAST_should_be_asserted_at_the_last_data(valid, awlen, wr_in_progress, last);
        @(posedge ACLK) disable iff (!ARESETn)
        (valid && wr_in_progress && (awlen == 0)) |-> last;
    endproperty

    assert property (WLAST_should_be_asserted_at_the_last_data(axif.wvalid, AWLEN, WR_IN_PROGRESS, axif.wlast))
        else $error("WLAST should be asserted when the last beat of a burst is being transferred");

    logic aw_done, w_done, ar_done;
    always_ff @(posedge ACLK or negedge ARESETn) begin
        if (!ARESETn) begin
            aw_done <= 0;
            w_done  <= 0;
            ar_done <= 0;
        end
        else begin
            if (axif.awvalid && axif.awready) aw_done <= 1'b1;
            if (axif.wvalid && axif.wready)   w_done <= 1'b1;
            if (axif.bvalid && axif.bready) begin
                aw_done <= 1'b0;
                w_done  <= 1'b0;
            end

            if (axif.arvalid && axif.arready)             ar_done <= 1'b1;
            if (axif.rvalid && axif.rready && axif.rlast) ar_done <= 1'b0;
        end
    end

    property Order_of_transaction_should_be_correct(done, valid);
        @(posedge ACLK) disable iff (!ARESETn)
        valid |-> done;
    endproperty

    assert property (Order_of_transaction_should_be_correct((aw_done && w_done), axif.bvalid))
        else $error("Write response received without valid address and data handshake");
    assert property (Order_of_transaction_should_be_correct(ar_done, axif.rvalid))
        else $error("Read data received without valid address handshake");

endmodule
