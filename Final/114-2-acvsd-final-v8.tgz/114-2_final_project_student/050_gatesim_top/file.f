// ---- include dirs ----------------------------------------------------------
+incdir+../001_interface
+incdir+../000_tb
+incdir+../010_rtl_top
+incdir+../011_rtl_pe

// ---- shared packages / interfaces (MUST come first) ------------------------
../001_interface/axi_pkg.sv
../001_interface/cmd_pkg.sv
../001_interface/axi_if.sv
../001_interface/axi4_full_checker.sv
../001_interface/axi4_lite_checker.sv

// ---- testbench behavioral models -------------------------------------------
../000_tb/dram.enc.sv
../000_tb/mcu.enc.sv
../000_tb/testbed.sv

// ---- DUT: synthesised gate-level netlists ----------------------------------
../040_syn_top/netlist/top_syn.v
../041_syn_pe/netlist/pe_syn.v