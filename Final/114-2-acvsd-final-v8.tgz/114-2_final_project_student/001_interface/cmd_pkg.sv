`timescale 1ns/1ps
// ============================================================================
// cmd_pkg.sv
//
// Enum + packed struct typedefs for the 128-bit GEMM/STALL command word.
//
// Command layout (bit-index reference — numeric = bit index, MSB on top):
//
//   [127:96] = Z_META   (32-bit)
//   [ 95:64] = Y_META   (32-bit)
//   [ 63:32] = X_META   (32-bit)
//   [ 31: 8] = reserved (24-bit)
//   [  7: 0] = OPCODE   (8-bit)
//
// META layout (32-bit):
//
//   [   31]  nrow_div_256    — if 1, actual rows = nrow_code * 256
//                              else actual rows = nrow_code
//   [30:24]  nrow_code       — 7-bit row count code
//   [23:17]  ncol_code       — 7-bit col count code; actual cols = ncol * 256
//   [16: 6]  addr_1kb        — 11-bit base address in KB units
//   [ 5: 2]  bank_mask       — {D, C, B, A} active bank bitmap
//   [ 1: 0]  dtype           — 0=BF16, 1=FP8-E4M3, 2=FP8-E5M2
//
// Packed-struct layout in SystemVerilog mirrors the same bit ordering:
// the FIRST field declared maps to the HIGHEST bits.  So reading
//   cmd_t c; assign c = raw_cmd;
// lets the waveform/debugger display every sub-field by name with its
// actual value, no manual slicing required.
// ============================================================================
`ifndef CMD_PKG_SV
`define CMD_PKG_SV

package cmd_pkg;

    // -------------------------------------------------------------------------
    // Opcode enum (bits [7:0] of the 128-bit command)
    // -------------------------------------------------------------------------
    typedef enum logic [7:0] {
        OP_STALL = 8'h00,
        OP_GEMM  = 8'h01
    } opcode_e;

    // -------------------------------------------------------------------------
    // Data-type enum (bits [1:0] of each META field)
    // -------------------------------------------------------------------------
    typedef enum logic [1:0] {
        DTYPE_BF16    = 2'd0,
        DTYPE_FP8E4M3 = 2'd1,
        DTYPE_FP8E5M2 = 2'd2,
        DTYPE_RSVD    = 2'd3
    } dtype_e;

    // -------------------------------------------------------------------------
    // Bank-mask enum (bits [5:2] of META) — {D, C, B, A}
    // Listed values cover every combination that appears in the test CSV.
    // Unlisted values are still legal (4-bit any-mask); enums are for
    // waveform-label convenience only, not value restriction.
    // -------------------------------------------------------------------------
    typedef enum logic [3:0] {
        BANK_NONE = 4'b0000,
        BANK_A    = 4'b0001,
        BANK_B    = 4'b0010,
        BANK_C    = 4'b0100,
        BANK_D    = 4'b1000,
        BANK_AB   = 4'b0011,
        BANK_AC   = 4'b0101,
        BANK_BD   = 4'b1010,
        BANK_CD   = 4'b1100,
        BANK_ABCD = 4'b1111
    } bank_mask_e;

    // -------------------------------------------------------------------------
    // META field (32 bits).  MSB-first packed declaration order:
    //   nrow_div_256 -> bit 31
    //   nrow_code    -> bits [30:24]
    //   ncol_code    -> bits [23:17]
    //   addr_1kb     -> bits [16:6]
    //   bank_mask    -> bits [5:2]
    //   dtype        -> bits [1:0]
    // -------------------------------------------------------------------------
    typedef struct packed {
        logic        nrow_div_256;   // [31]
        logic [6:0]  nrow_code;      // [30:24]
        logic [6:0]  ncol_code;      // [23:17]
        logic [10:0] addr_1kb;       // [16:6]
        bank_mask_e  bank_mask;      // [5:2]
        dtype_e      dtype;          // [1:0]
    } meta_t;

    // -------------------------------------------------------------------------
    // Full 128-bit command.  MSB-first packed declaration order:
    //   z_meta   -> [127:96]
    //   y_meta   -> [95:64]
    //   x_meta   -> [63:32]
    //   reserved -> [31:8]
    //   opcode   -> [7:0]
    // -------------------------------------------------------------------------
    typedef struct packed {
        meta_t        z_meta;        // [127:96]
        meta_t        y_meta;        // [95:64]
        meta_t        x_meta;        // [63:32]
        logic [23:0]  reserved;      // [31:8]
        opcode_e      opcode;        // [7:0]
    } cmd_t;

    // -------------------------------------------------------------------------
    // Small helpers so the same arithmetic isn't rewritten in every module
    // -------------------------------------------------------------------------
    // Bytes per element for a given dtype (BF16=2, FP8=1).
    function automatic int unsigned dtype_bytes(dtype_e dt);
        case (dt)
            DTYPE_BF16: dtype_bytes = 2;
            default:    dtype_bytes = 1;   // FP8-E4M3 / FP8-E5M2
        endcase
    endfunction

    // Tile size in bytes for a 32x32 tile of the given dtype.
    function automatic int unsigned tile_bytes(dtype_e dt);
        tile_bytes = 32 * 32 * dtype_bytes(dt);
    endfunction

    // Actual matrix rows encoded by (nrow_div_256, nrow_code).
    function automatic int unsigned meta_rows(meta_t m);
        meta_rows = m.nrow_div_256 ? (int'(m.nrow_code) * 256)
                                   :  int'(m.nrow_code);
    endfunction

    // Actual matrix cols encoded by ncol_code (always ncol_code * 256).
    function automatic int unsigned meta_cols(meta_t m);
        meta_cols = int'(m.ncol_code) * 256;
    endfunction

    // Byte address of a META's base region (addr_1kb * 1024).
    function automatic int unsigned meta_addr_bytes(meta_t m);
        meta_addr_bytes = int'(m.addr_1kb) * 1024;
    endfunction

    // Count the active banks in a bank_mask.
    function automatic int unsigned count_banks(bank_mask_e bm);
        count_banks = int'(bm[0]) + int'(bm[1]) + int'(bm[2]) + int'(bm[3]);
    endfunction

endpackage

`endif // CMD_PKG_SV
