`timescale 1ns/1ps
`ifndef AXI_PKG_SV
`define AXI_PKG_SV

// =============================================================================
// AXI4-Full Standard Macros
// =============================================================================
`define AXI_ADDRW 32
`define AXI_DATAW 128
`define AXI_IDW 4
`define AXI_LENW 8
`define AXI_SIZEW 3
`define AXI_BURSTW 2
`define AXI_RESPW 2
`define AXI_STRBW (`AXI_DATAW/8)

// Aliases for compatibility
`define AXI_ADDR_W     `AXI_ADDRW
`define AXI_DATA_W     `AXI_DATAW
`define AXI_ID_W       `AXI_IDW
`define AXI_LEN_W      `AXI_LENW
`define AXI_SIZE_W     `AXI_SIZEW
`define AXI_BURST_W    `AXI_BURSTW
`define AXI_RESP_W     `AXI_RESPW
`define AXI_STRB_W     `AXI_STRBW

// =============================================================================
// AXI4-Lite Standard Macros
// =============================================================================
`define AXIL_ADDRW     10
`define AXIL_DATAW     128
`define AXIL_RESPW     2

// Aliases
`define AXIL_ADDR_W    `AXIL_ADDRW
`define AXIL_DATA_W    `AXIL_DATAW
`define AXIL_RESP_W    `AXIL_RESPW

// =============================================================================
// Project-Specific Macros
// =============================================================================
`define PE_COUNT       6
`define PE_CMD_W       128
`define PE_OPCODE_W    8

// =============================================================================
// SystemVerilog Package for Shared Parameters
// =============================================================================
package axi_pkg;
    // AXI4-Lite Control Bus
    localparam int AXIL_ADDR_W = `AXIL_ADDRW;
    localparam int AXIL_DATA_W = `AXIL_DATAW;
    localparam int AXIL_RESP_W = `AXIL_RESPW;

    // AXI4-Full Data Bus
    localparam int AXI_ADDR_W  = `AXI_ADDRW;
    localparam int AXI_DATA_W  = `AXI_DATAW;
    localparam int AXI_ID_W    = `AXI_IDW;
    localparam int AXI_LEN_W   = `AXI_LENW;
    localparam int AXI_SIZE_W  = `AXI_SIZEW;
    localparam int AXI_BURST_W = `AXI_BURSTW;
    localparam int AXI_RESP_W  = `AXI_RESPW;
    localparam int AXI_STRB_W  = `AXI_STRBW;

    // Project Constants
    localparam int PE_COUNT    = `PE_COUNT;
    localparam int PE_CMD_W    = `PE_CMD_W;
endpackage

`endif
