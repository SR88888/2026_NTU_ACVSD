`timescale 1ns/1ps

module axi4_lite_checker (
    axi4_lite_if.monitor axil
);

    // TODO

endmodule
