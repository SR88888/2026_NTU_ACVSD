import axi_pkg::*;

module axi4_full_checker (
    axi4_full_if.monitor axif
);

    // TODO

endmodule
