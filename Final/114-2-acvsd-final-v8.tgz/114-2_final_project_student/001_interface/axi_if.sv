`timescale 1ns/1ps
`ifndef AXI_IF_SV
`define AXI_IF_SV

import axi_pkg::*;

interface axi4_lite_if;
    logic [AXIL_ADDR_W-1:0] awaddr;
    logic                   awvalid;
    logic                   awready;
    logic [AXIL_DATA_W-1:0] wdata;
    logic                   wvalid;
    logic                   wready;
    logic [AXIL_RESP_W-1:0] bresp;
    logic                   bvalid;
    logic                   bready;
    logic [AXIL_ADDR_W-1:0] araddr;
    logic                   arvalid;
    logic                   arready;
    logic [AXIL_DATA_W-1:0] rdata;
    logic [AXIL_RESP_W-1:0] rresp;
    logic                   rvalid;
    logic                   rready;

    modport master(
        output awaddr, awvalid, wdata, wvalid, bready, araddr, arvalid, rready,
        input  awready, wready, bresp, bvalid, arready, rdata, rresp, rvalid
    );

    modport slave(
        input  awaddr, awvalid, wdata, wvalid, bready, araddr, arvalid, rready,
        output awready, wready, bresp, bvalid, arready, rdata, rresp, rvalid
    );

    modport monitor(
        input  awaddr, awvalid, awready, wdata, wvalid, wready, bresp, bvalid, bready,
        input  araddr, arvalid, arready, rdata, rresp, rvalid, rready
    );
endinterface

interface axi4_full_if;
    logic [AXI_ID_W-1:0]      awid;
    logic [AXI_ADDR_W-1:0]    awaddr;
    logic [AXI_LEN_W-1:0]     awlen;
    logic [AXI_SIZE_W-1:0]    awsize;
    logic [AXI_BURST_W-1:0]   awburst;
    logic                     awvalid;
    logic                     awready;
    logic [AXI_DATA_W-1:0]    wdata;
    logic [AXI_STRB_W-1:0]    wstrb;
    logic                     wlast;
    logic                     wvalid;
    logic                     wready;
    logic [AXI_ID_W-1:0]      bid;
    logic [AXI_RESP_W-1:0]    bresp;
    logic                     bvalid;
    logic                     bready;
    logic [AXI_ID_W-1:0]      arid;
    logic [AXI_ADDR_W-1:0]    araddr;
    logic [AXI_LEN_W-1:0]     arlen;
    logic [AXI_SIZE_W-1:0]    arsize;
    logic [AXI_BURST_W-1:0]   arburst;
    logic                     arvalid;
    logic                     arready;
    logic [AXI_ID_W-1:0]      rid;
    logic [AXI_DATA_W-1:0]    rdata;
    logic [AXI_RESP_W-1:0]    rresp;
    logic                     rlast;
    logic                     rvalid;
    logic                     rready;

    modport master(
        output awid, awaddr, awlen, awsize, awburst, awvalid, wdata, wstrb, wlast, wvalid, bready, arid, araddr, arlen, arsize, arburst, arvalid, rready,
        input  awready, wready, bid, bresp, bvalid, arready, rid, rdata, rresp, rlast, rvalid
    );

    modport slave(
        input  awid, awaddr, awlen, awsize, awburst, awvalid, wdata, wstrb, wlast, wvalid, bready, arid, araddr, arlen, arsize, arburst, arvalid, rready,
        output awready, wready, bid, bresp, bvalid, arready, rid, rdata, rresp, rlast, rvalid
    );

    modport monitor(
        input  awid, awaddr, awlen, awsize, awburst, awvalid, awready,
        input  wdata, wstrb, wlast, wvalid, wready,
        input  bid, bresp, bvalid, bready,
        input  arid, araddr, arlen, arsize, arburst, arvalid, arready,
        input  rid, rdata, rresp, rlast, rvalid, rready
    );

    modport write_monitor(
        input awid, awaddr, awlen, awsize, awburst, awvalid, awready,
        input wdata, wstrb, wlast, wvalid, wready,
        input bid, bresp, bvalid, bready
    );

    modport read_monitor(
        input arid, araddr, arlen, arsize, arburst, arvalid, arready,
        input rid, rdata, rresp, rlast, rvalid, rready
    );
endinterface

`endif
