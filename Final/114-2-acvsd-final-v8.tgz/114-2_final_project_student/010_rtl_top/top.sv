import axi_pkg::*;

//===========================================================================
// only connect the controller and the 6 PEs 
// DONT TOUCH
//===========================================================================

module top (
    input  logic clk_data_bus, 
    input  logic clk_ctrl_bus, 
    input  logic clk_pe,       
    input  logic rst_n,

    // AXI4-Lite Slave from MCU
    input  logic [AXIL_ADDR_W-1:0]  s_axil_awaddr,
    input  logic                    s_axil_awvalid,
    output logic                    s_axil_awready,
    input  logic [AXIL_DATA_W-1:0]  s_axil_wdata,
    input  logic                    s_axil_wvalid,
    output logic                    s_axil_wready,
    output logic [AXIL_RESP_W-1:0]  s_axil_bresp,
    output logic                    s_axil_bvalid,
    input  logic                    s_axil_bready,
    input  logic [AXIL_ADDR_W-1:0]  s_axil_araddr,
    input  logic                    s_axil_arvalid,
    output logic                    s_axil_arready,
    output logic [AXIL_DATA_W-1:0]  s_axil_rdata,
    output logic [AXIL_RESP_W-1:0]  s_axil_rresp,
    output logic                    s_axil_rvalid,
    input  logic                    s_axil_rready,

    // 4 DRAM interfaces (flat) — AXI4-Full master
    output logic [AXI_ID_W-1:0]     m_dram_0_awid,
    output logic [AXI_ADDR_W-1:0]   m_dram_0_awaddr,
    output logic [AXI_LEN_W-1:0]    m_dram_0_awlen,
    output logic [AXI_SIZE_W-1:0]   m_dram_0_awsize,
    output logic [AXI_BURST_W-1:0]  m_dram_0_awburst,
    output logic                    m_dram_0_awvalid,
    input  logic                    m_dram_0_awready,
    output logic [AXI_DATA_W-1:0]   m_dram_0_wdata,
    output logic [AXI_STRB_W-1:0]   m_dram_0_wstrb,
    output logic                    m_dram_0_wlast,
    output logic                    m_dram_0_wvalid,
    input  logic                    m_dram_0_wready,
    input  logic [AXI_ID_W-1:0]     m_dram_0_bid,
    input  logic [AXI_RESP_W-1:0]   m_dram_0_bresp,
    input  logic                    m_dram_0_bvalid,
    output logic                    m_dram_0_bready,
    output logic [AXI_ID_W-1:0]     m_dram_0_arid,
    output logic [AXI_ADDR_W-1:0]   m_dram_0_araddr,
    output logic [AXI_LEN_W-1:0]    m_dram_0_arlen,
    output logic [AXI_SIZE_W-1:0]   m_dram_0_arsize,
    output logic [AXI_BURST_W-1:0]  m_dram_0_arburst,
    output logic                    m_dram_0_arvalid,
    input  logic                    m_dram_0_arready,
    input  logic [AXI_ID_W-1:0]     m_dram_0_rid,
    input  logic [AXI_DATA_W-1:0]   m_dram_0_rdata,
    input  logic [AXI_RESP_W-1:0]   m_dram_0_rresp,
    input  logic                    m_dram_0_rlast,
    input  logic                    m_dram_0_rvalid,
    output logic                    m_dram_0_rready,

    output logic [AXI_ID_W-1:0]     m_dram_1_awid,
    output logic [AXI_ADDR_W-1:0]   m_dram_1_awaddr,
    output logic [AXI_LEN_W-1:0]    m_dram_1_awlen,
    output logic [AXI_SIZE_W-1:0]   m_dram_1_awsize,
    output logic [AXI_BURST_W-1:0]  m_dram_1_awburst,
    output logic                    m_dram_1_awvalid,
    input  logic                    m_dram_1_awready,
    output logic [AXI_DATA_W-1:0]   m_dram_1_wdata,
    output logic [AXI_STRB_W-1:0]   m_dram_1_wstrb,
    output logic                    m_dram_1_wlast,
    output logic                    m_dram_1_wvalid,
    input  logic                    m_dram_1_wready,
    input  logic [AXI_ID_W-1:0]     m_dram_1_bid,
    input  logic [AXI_RESP_W-1:0]   m_dram_1_bresp,
    input  logic                    m_dram_1_bvalid,
    output logic                    m_dram_1_bready,
    output logic [AXI_ID_W-1:0]     m_dram_1_arid,
    output logic [AXI_ADDR_W-1:0]   m_dram_1_araddr,
    output logic [AXI_LEN_W-1:0]    m_dram_1_arlen,
    output logic [AXI_SIZE_W-1:0]   m_dram_1_arsize,
    output logic [AXI_BURST_W-1:0]  m_dram_1_arburst,
    output logic                    m_dram_1_arvalid,
    input  logic                    m_dram_1_arready,
    input  logic [AXI_ID_W-1:0]     m_dram_1_rid,
    input  logic [AXI_DATA_W-1:0]   m_dram_1_rdata,
    input  logic [AXI_RESP_W-1:0]   m_dram_1_rresp,
    input  logic                    m_dram_1_rlast,
    input  logic                    m_dram_1_rvalid,
    output logic                    m_dram_1_rready,

    output logic [AXI_ID_W-1:0]     m_dram_2_awid,
    output logic [AXI_ADDR_W-1:0]   m_dram_2_awaddr,
    output logic [AXI_LEN_W-1:0]    m_dram_2_awlen,
    output logic [AXI_SIZE_W-1:0]   m_dram_2_awsize,
    output logic [AXI_BURST_W-1:0]  m_dram_2_awburst,
    output logic                    m_dram_2_awvalid,
    input  logic                    m_dram_2_awready,
    output logic [AXI_DATA_W-1:0]   m_dram_2_wdata,
    output logic [AXI_STRB_W-1:0]   m_dram_2_wstrb,
    output logic                    m_dram_2_wlast,
    output logic                    m_dram_2_wvalid,
    input  logic                    m_dram_2_wready,
    input  logic [AXI_ID_W-1:0]     m_dram_2_bid,
    input  logic [AXI_RESP_W-1:0]   m_dram_2_bresp,
    input  logic                    m_dram_2_bvalid,
    output logic                    m_dram_2_bready,
    output logic [AXI_ID_W-1:0]     m_dram_2_arid,
    output logic [AXI_ADDR_W-1:0]   m_dram_2_araddr,
    output logic [AXI_LEN_W-1:0]    m_dram_2_arlen,
    output logic [AXI_SIZE_W-1:0]   m_dram_2_arsize,
    output logic [AXI_BURST_W-1:0]  m_dram_2_arburst,
    output logic                    m_dram_2_arvalid,
    input  logic                    m_dram_2_arready,
    input  logic [AXI_ID_W-1:0]     m_dram_2_rid,
    input  logic [AXI_DATA_W-1:0]   m_dram_2_rdata,
    input  logic [AXI_RESP_W-1:0]   m_dram_2_rresp,
    input  logic                    m_dram_2_rlast,
    input  logic                    m_dram_2_rvalid,
    output logic                    m_dram_2_rready,

    output logic [AXI_ID_W-1:0]     m_dram_3_awid,
    output logic [AXI_ADDR_W-1:0]   m_dram_3_awaddr,
    output logic [AXI_LEN_W-1:0]    m_dram_3_awlen,
    output logic [AXI_SIZE_W-1:0]   m_dram_3_awsize,
    output logic [AXI_BURST_W-1:0]  m_dram_3_awburst,
    output logic                    m_dram_3_awvalid,
    input  logic                    m_dram_3_awready,
    output logic [AXI_DATA_W-1:0]   m_dram_3_wdata,
    output logic [AXI_STRB_W-1:0]   m_dram_3_wstrb,
    output logic                    m_dram_3_wlast,
    output logic                    m_dram_3_wvalid,
    input  logic                    m_dram_3_wready,
    input  logic [AXI_ID_W-1:0]     m_dram_3_bid,
    input  logic [AXI_RESP_W-1:0]   m_dram_3_bresp,
    input  logic                    m_dram_3_bvalid,
    output logic                    m_dram_3_bready,
    output logic [AXI_ID_W-1:0]     m_dram_3_arid,
    output logic [AXI_ADDR_W-1:0]   m_dram_3_araddr,
    output logic [AXI_LEN_W-1:0]    m_dram_3_arlen,
    output logic [AXI_SIZE_W-1:0]   m_dram_3_arsize,
    output logic [AXI_BURST_W-1:0]  m_dram_3_arburst,
    output logic                    m_dram_3_arvalid,
    input  logic                    m_dram_3_arready,
    input  logic [AXI_ID_W-1:0]     m_dram_3_rid,
    input  logic [AXI_DATA_W-1:0]   m_dram_3_rdata,
    input  logic [AXI_RESP_W-1:0]   m_dram_3_rresp,
    input  logic                    m_dram_3_rlast,
    input  logic                    m_dram_3_rvalid,
    output logic                    m_dram_3_rready
);
    // ============================================
    // Internal Signals & Interfaces
    // ============================================

    logic [PE_COUNT-1:0] interrupt_pe;

    // AXI4-Lite Interfaces (Controller -> 6 PEs)
    axi4_lite_if axil_pe_0_1();
    axi4_lite_if axil_pe_0_2();
    axi4_lite_if axil_pe_0_3();
    axi4_lite_if axil_pe_1_1();
    axi4_lite_if axil_pe_1_2();
    axi4_lite_if axil_pe_1_3();

    // AXI4-Full Interfaces (PE Mesh)
    axi4_full_if axif_pe_0_1_to_0_2();
    axi4_full_if axif_pe_0_2_to_0_3();
    axi4_full_if axif_pe_1_1_to_1_2();
    axi4_full_if axif_pe_1_2_to_1_3();

    axi4_full_if axif_pe_0_3_to_0_2();
    axi4_full_if axif_pe_0_2_to_0_1();
    axi4_full_if axif_pe_1_3_to_1_2();
    axi4_full_if axif_pe_1_2_to_1_1();

    axi4_full_if axif_pe_0_1_to_1_1();
    axi4_full_if axif_pe_0_2_to_1_2();
    axi4_full_if axif_pe_0_3_to_1_3();

    axi4_full_if axif_pe_1_1_to_0_1();
    axi4_full_if axif_pe_1_2_to_0_2();
    axi4_full_if axif_pe_1_3_to_0_3();

    axi4_full_if null_axif_0();
    axi4_full_if null_axif_1();
    axi4_full_if null_axif_2();
    axi4_full_if null_axif_3();

    axi4_full_tieoff u_tieoff_0(.axif(null_axif_0));
    axi4_full_tieoff u_tieoff_1(.axif(null_axif_1));
    axi4_full_tieoff u_tieoff_2(.axif(null_axif_2));
    axi4_full_tieoff u_tieoff_3(.axif(null_axif_3));

    // DRAM shim interfaces — bridge flat top ports to CONNECT_AXI macro
    axi4_full_if dram_shim_0();
    axi4_full_if dram_shim_1();
    axi4_full_if dram_shim_2();
    axi4_full_if dram_shim_3();

    // ============================================
    // DRAM shim bridges: flat ports <-> interfaces
    // ============================================

    // dram_shim_0
    assign m_dram_0_awid    = dram_shim_0.awid;
    assign m_dram_0_awaddr  = dram_shim_0.awaddr;
    assign m_dram_0_awlen   = dram_shim_0.awlen;
    assign m_dram_0_awsize  = dram_shim_0.awsize;
    assign m_dram_0_awburst = dram_shim_0.awburst;
    assign m_dram_0_awvalid = dram_shim_0.awvalid;
    assign m_dram_0_wdata   = dram_shim_0.wdata;
    assign m_dram_0_wstrb   = dram_shim_0.wstrb;
    assign m_dram_0_wlast   = dram_shim_0.wlast;
    assign m_dram_0_wvalid  = dram_shim_0.wvalid;
    assign m_dram_0_bready  = dram_shim_0.bready;
    assign m_dram_0_arid    = dram_shim_0.arid;
    assign m_dram_0_araddr  = dram_shim_0.araddr;
    assign m_dram_0_arlen   = dram_shim_0.arlen;
    assign m_dram_0_arsize  = dram_shim_0.arsize;
    assign m_dram_0_arburst = dram_shim_0.arburst;
    assign m_dram_0_arvalid = dram_shim_0.arvalid;
    assign m_dram_0_rready  = dram_shim_0.rready;
    assign dram_shim_0.awready = m_dram_0_awready;
    assign dram_shim_0.wready  = m_dram_0_wready;
    assign dram_shim_0.bid     = m_dram_0_bid;
    assign dram_shim_0.bresp   = m_dram_0_bresp;
    assign dram_shim_0.bvalid  = m_dram_0_bvalid;
    assign dram_shim_0.arready = m_dram_0_arready;
    assign dram_shim_0.rid     = m_dram_0_rid;
    assign dram_shim_0.rdata   = m_dram_0_rdata;
    assign dram_shim_0.rresp   = m_dram_0_rresp;
    assign dram_shim_0.rlast   = m_dram_0_rlast;
    assign dram_shim_0.rvalid  = m_dram_0_rvalid;

    // dram_shim_1
    assign m_dram_1_awid    = dram_shim_1.awid;
    assign m_dram_1_awaddr  = dram_shim_1.awaddr;
    assign m_dram_1_awlen   = dram_shim_1.awlen;
    assign m_dram_1_awsize  = dram_shim_1.awsize;
    assign m_dram_1_awburst = dram_shim_1.awburst;
    assign m_dram_1_awvalid = dram_shim_1.awvalid;
    assign m_dram_1_wdata   = dram_shim_1.wdata;
    assign m_dram_1_wstrb   = dram_shim_1.wstrb;
    assign m_dram_1_wlast   = dram_shim_1.wlast;
    assign m_dram_1_wvalid  = dram_shim_1.wvalid;
    assign m_dram_1_bready  = dram_shim_1.bready;
    assign m_dram_1_arid    = dram_shim_1.arid;
    assign m_dram_1_araddr  = dram_shim_1.araddr;
    assign m_dram_1_arlen   = dram_shim_1.arlen;
    assign m_dram_1_arsize  = dram_shim_1.arsize;
    assign m_dram_1_arburst = dram_shim_1.arburst;
    assign m_dram_1_arvalid = dram_shim_1.arvalid;
    assign m_dram_1_rready  = dram_shim_1.rready;
    assign dram_shim_1.awready = m_dram_1_awready;
    assign dram_shim_1.wready  = m_dram_1_wready;
    assign dram_shim_1.bid     = m_dram_1_bid;
    assign dram_shim_1.bresp   = m_dram_1_bresp;
    assign dram_shim_1.bvalid  = m_dram_1_bvalid;
    assign dram_shim_1.arready = m_dram_1_arready;
    assign dram_shim_1.rid     = m_dram_1_rid;
    assign dram_shim_1.rdata   = m_dram_1_rdata;
    assign dram_shim_1.rresp   = m_dram_1_rresp;
    assign dram_shim_1.rlast   = m_dram_1_rlast;
    assign dram_shim_1.rvalid  = m_dram_1_rvalid;

    // dram_shim_2
    assign m_dram_2_awid    = dram_shim_2.awid;
    assign m_dram_2_awaddr  = dram_shim_2.awaddr;
    assign m_dram_2_awlen   = dram_shim_2.awlen;
    assign m_dram_2_awsize  = dram_shim_2.awsize;
    assign m_dram_2_awburst = dram_shim_2.awburst;
    assign m_dram_2_awvalid = dram_shim_2.awvalid;
    assign m_dram_2_wdata   = dram_shim_2.wdata;
    assign m_dram_2_wstrb   = dram_shim_2.wstrb;
    assign m_dram_2_wlast   = dram_shim_2.wlast;
    assign m_dram_2_wvalid  = dram_shim_2.wvalid;
    assign m_dram_2_bready  = dram_shim_2.bready;
    assign m_dram_2_arid    = dram_shim_2.arid;
    assign m_dram_2_araddr  = dram_shim_2.araddr;
    assign m_dram_2_arlen   = dram_shim_2.arlen;
    assign m_dram_2_arsize  = dram_shim_2.arsize;
    assign m_dram_2_arburst = dram_shim_2.arburst;
    assign m_dram_2_arvalid = dram_shim_2.arvalid;
    assign m_dram_2_rready  = dram_shim_2.rready;
    assign dram_shim_2.awready = m_dram_2_awready;
    assign dram_shim_2.wready  = m_dram_2_wready;
    assign dram_shim_2.bid     = m_dram_2_bid;
    assign dram_shim_2.bresp   = m_dram_2_bresp;
    assign dram_shim_2.bvalid  = m_dram_2_bvalid;
    assign dram_shim_2.arready = m_dram_2_arready;
    assign dram_shim_2.rid     = m_dram_2_rid;
    assign dram_shim_2.rdata   = m_dram_2_rdata;
    assign dram_shim_2.rresp   = m_dram_2_rresp;
    assign dram_shim_2.rlast   = m_dram_2_rlast;
    assign dram_shim_2.rvalid  = m_dram_2_rvalid;

    // dram_shim_3
    assign m_dram_3_awid    = dram_shim_3.awid;
    assign m_dram_3_awaddr  = dram_shim_3.awaddr;
    assign m_dram_3_awlen   = dram_shim_3.awlen;
    assign m_dram_3_awsize  = dram_shim_3.awsize;
    assign m_dram_3_awburst = dram_shim_3.awburst;
    assign m_dram_3_awvalid = dram_shim_3.awvalid;
    assign m_dram_3_wdata   = dram_shim_3.wdata;
    assign m_dram_3_wstrb   = dram_shim_3.wstrb;
    assign m_dram_3_wlast   = dram_shim_3.wlast;
    assign m_dram_3_wvalid  = dram_shim_3.wvalid;
    assign m_dram_3_bready  = dram_shim_3.bready;
    assign m_dram_3_arid    = dram_shim_3.arid;
    assign m_dram_3_araddr  = dram_shim_3.araddr;
    assign m_dram_3_arlen   = dram_shim_3.arlen;
    assign m_dram_3_arsize  = dram_shim_3.arsize;
    assign m_dram_3_arburst = dram_shim_3.arburst;
    assign m_dram_3_arvalid = dram_shim_3.arvalid;
    assign m_dram_3_rready  = dram_shim_3.rready;
    assign dram_shim_3.awready = m_dram_3_awready;
    assign dram_shim_3.wready  = m_dram_3_wready;
    assign dram_shim_3.bid     = m_dram_3_bid;
    assign dram_shim_3.bresp   = m_dram_3_bresp;
    assign dram_shim_3.bvalid  = m_dram_3_bvalid;
    assign dram_shim_3.arready = m_dram_3_arready;
    assign dram_shim_3.rid     = m_dram_3_rid;
    assign dram_shim_3.rdata   = m_dram_3_rdata;
    assign dram_shim_3.rresp   = m_dram_3_rresp;
    assign dram_shim_3.rlast   = m_dram_3_rlast;
    assign dram_shim_3.rvalid  = m_dram_3_rvalid;

    // Controller Instantiation
    controller u_ctrl (
        .clk_ctrl_bus        (clk_ctrl_bus),
        .rst_n               (rst_n),
        // s_axil (flat top ports pass-through)
        .s_axil_awaddr       (s_axil_awaddr),
        .s_axil_awvalid      (s_axil_awvalid),
        .s_axil_awready      (s_axil_awready),
        .s_axil_wdata        (s_axil_wdata),
        .s_axil_wvalid       (s_axil_wvalid),
        .s_axil_wready       (s_axil_wready),
        .s_axil_bresp        (s_axil_bresp),
        .s_axil_bvalid       (s_axil_bvalid),
        .s_axil_bready       (s_axil_bready),
        .s_axil_araddr       (s_axil_araddr),
        .s_axil_arvalid      (s_axil_arvalid),
        .s_axil_arready      (s_axil_arready),
        .s_axil_rdata        (s_axil_rdata),
        .s_axil_rresp        (s_axil_rresp),
        .s_axil_rvalid       (s_axil_rvalid),
        .s_axil_rready       (s_axil_rready),
        // m_axil_0_1 -> axil_pe_0_1 interface members
        .m_axil_0_1_awaddr   (axil_pe_0_1.awaddr),
        .m_axil_0_1_awvalid  (axil_pe_0_1.awvalid),
        .m_axil_0_1_awready  (axil_pe_0_1.awready),
        .m_axil_0_1_wdata    (axil_pe_0_1.wdata),
        .m_axil_0_1_wvalid   (axil_pe_0_1.wvalid),
        .m_axil_0_1_wready   (axil_pe_0_1.wready),
        .m_axil_0_1_bready   (axil_pe_0_1.bready),
        .m_axil_0_1_bresp    (axil_pe_0_1.bresp),
        .m_axil_0_1_bvalid   (axil_pe_0_1.bvalid),
        .m_axil_0_1_araddr   (axil_pe_0_1.araddr),
        .m_axil_0_1_arvalid  (axil_pe_0_1.arvalid),
        .m_axil_0_1_arready  (axil_pe_0_1.arready),
        .m_axil_0_1_rready   (axil_pe_0_1.rready),
        .m_axil_0_1_rdata    (axil_pe_0_1.rdata),
        .m_axil_0_1_rresp    (axil_pe_0_1.rresp),
        .m_axil_0_1_rvalid   (axil_pe_0_1.rvalid),
        // m_axil_0_2 -> axil_pe_0_2
        .m_axil_0_2_awaddr   (axil_pe_0_2.awaddr),
        .m_axil_0_2_awvalid  (axil_pe_0_2.awvalid),
        .m_axil_0_2_awready  (axil_pe_0_2.awready),
        .m_axil_0_2_wdata    (axil_pe_0_2.wdata),
        .m_axil_0_2_wvalid   (axil_pe_0_2.wvalid),
        .m_axil_0_2_wready   (axil_pe_0_2.wready),
        .m_axil_0_2_bready   (axil_pe_0_2.bready),
        .m_axil_0_2_bresp    (axil_pe_0_2.bresp),
        .m_axil_0_2_bvalid   (axil_pe_0_2.bvalid),
        .m_axil_0_2_araddr   (axil_pe_0_2.araddr),
        .m_axil_0_2_arvalid  (axil_pe_0_2.arvalid),
        .m_axil_0_2_arready  (axil_pe_0_2.arready),
        .m_axil_0_2_rready   (axil_pe_0_2.rready),
        .m_axil_0_2_rdata    (axil_pe_0_2.rdata),
        .m_axil_0_2_rresp    (axil_pe_0_2.rresp),
        .m_axil_0_2_rvalid   (axil_pe_0_2.rvalid),
        // m_axil_0_3 -> axil_pe_0_3
        .m_axil_0_3_awaddr   (axil_pe_0_3.awaddr),
        .m_axil_0_3_awvalid  (axil_pe_0_3.awvalid),
        .m_axil_0_3_awready  (axil_pe_0_3.awready),
        .m_axil_0_3_wdata    (axil_pe_0_3.wdata),
        .m_axil_0_3_wvalid   (axil_pe_0_3.wvalid),
        .m_axil_0_3_wready   (axil_pe_0_3.wready),
        .m_axil_0_3_bready   (axil_pe_0_3.bready),
        .m_axil_0_3_bresp    (axil_pe_0_3.bresp),
        .m_axil_0_3_bvalid   (axil_pe_0_3.bvalid),
        .m_axil_0_3_araddr   (axil_pe_0_3.araddr),
        .m_axil_0_3_arvalid  (axil_pe_0_3.arvalid),
        .m_axil_0_3_arready  (axil_pe_0_3.arready),
        .m_axil_0_3_rready   (axil_pe_0_3.rready),
        .m_axil_0_3_rdata    (axil_pe_0_3.rdata),
        .m_axil_0_3_rresp    (axil_pe_0_3.rresp),
        .m_axil_0_3_rvalid   (axil_pe_0_3.rvalid),
        // m_axil_1_1 -> axil_pe_1_1
        .m_axil_1_1_awaddr   (axil_pe_1_1.awaddr),
        .m_axil_1_1_awvalid  (axil_pe_1_1.awvalid),
        .m_axil_1_1_awready  (axil_pe_1_1.awready),
        .m_axil_1_1_wdata    (axil_pe_1_1.wdata),
        .m_axil_1_1_wvalid   (axil_pe_1_1.wvalid),
        .m_axil_1_1_wready   (axil_pe_1_1.wready),
        .m_axil_1_1_bready   (axil_pe_1_1.bready),
        .m_axil_1_1_bresp    (axil_pe_1_1.bresp),
        .m_axil_1_1_bvalid   (axil_pe_1_1.bvalid),
        .m_axil_1_1_araddr   (axil_pe_1_1.araddr),
        .m_axil_1_1_arvalid  (axil_pe_1_1.arvalid),
        .m_axil_1_1_arready  (axil_pe_1_1.arready),
        .m_axil_1_1_rready   (axil_pe_1_1.rready),
        .m_axil_1_1_rdata    (axil_pe_1_1.rdata),
        .m_axil_1_1_rresp    (axil_pe_1_1.rresp),
        .m_axil_1_1_rvalid   (axil_pe_1_1.rvalid),
        // m_axil_1_2 -> axil_pe_1_2
        .m_axil_1_2_awaddr   (axil_pe_1_2.awaddr),
        .m_axil_1_2_awvalid  (axil_pe_1_2.awvalid),
        .m_axil_1_2_awready  (axil_pe_1_2.awready),
        .m_axil_1_2_wdata    (axil_pe_1_2.wdata),
        .m_axil_1_2_wvalid   (axil_pe_1_2.wvalid),
        .m_axil_1_2_wready   (axil_pe_1_2.wready),
        .m_axil_1_2_bready   (axil_pe_1_2.bready),
        .m_axil_1_2_bresp    (axil_pe_1_2.bresp),
        .m_axil_1_2_bvalid   (axil_pe_1_2.bvalid),
        .m_axil_1_2_araddr   (axil_pe_1_2.araddr),
        .m_axil_1_2_arvalid  (axil_pe_1_2.arvalid),
        .m_axil_1_2_arready  (axil_pe_1_2.arready),
        .m_axil_1_2_rready   (axil_pe_1_2.rready),
        .m_axil_1_2_rdata    (axil_pe_1_2.rdata),
        .m_axil_1_2_rresp    (axil_pe_1_2.rresp),
        .m_axil_1_2_rvalid   (axil_pe_1_2.rvalid),
        // m_axil_1_3 -> axil_pe_1_3
        .m_axil_1_3_awaddr   (axil_pe_1_3.awaddr),
        .m_axil_1_3_awvalid  (axil_pe_1_3.awvalid),
        .m_axil_1_3_awready  (axil_pe_1_3.awready),
        .m_axil_1_3_wdata    (axil_pe_1_3.wdata),
        .m_axil_1_3_wvalid   (axil_pe_1_3.wvalid),
        .m_axil_1_3_wready   (axil_pe_1_3.wready),
        .m_axil_1_3_bready   (axil_pe_1_3.bready),
        .m_axil_1_3_bresp    (axil_pe_1_3.bresp),
        .m_axil_1_3_bvalid   (axil_pe_1_3.bvalid),
        .m_axil_1_3_araddr   (axil_pe_1_3.araddr),
        .m_axil_1_3_arvalid  (axil_pe_1_3.arvalid),
        .m_axil_1_3_arready  (axil_pe_1_3.arready),
        .m_axil_1_3_rready   (axil_pe_1_3.rready),
        .m_axil_1_3_rdata    (axil_pe_1_3.rdata),
        .m_axil_1_3_rresp    (axil_pe_1_3.rresp),
        .m_axil_1_3_rvalid   (axil_pe_1_3.rvalid),
        .interrupt_pe        (interrupt_pe)
    );

    // ============================================
    // 6 Process Elements (PEs) Instantiation
    // ============================================
`define CONNECT_AXI(PREFIX, IF) \
    .``PREFIX``_awid    (IF.awid),    \
    .``PREFIX``_awaddr  (IF.awaddr),  \
    .``PREFIX``_awlen   (IF.awlen),   \
    .``PREFIX``_awsize  (IF.awsize),  \
    .``PREFIX``_awburst (IF.awburst), \
    .``PREFIX``_awvalid (IF.awvalid), \
    .``PREFIX``_awready (IF.awready), \
    .``PREFIX``_wdata   (IF.wdata),   \
    .``PREFIX``_wstrb   (IF.wstrb),   \
    .``PREFIX``_wlast   (IF.wlast),   \
    .``PREFIX``_wvalid  (IF.wvalid),  \
    .``PREFIX``_wready  (IF.wready),  \
    .``PREFIX``_bid     (IF.bid),     \
    .``PREFIX``_bresp   (IF.bresp),   \
    .``PREFIX``_bvalid  (IF.bvalid),  \
    .``PREFIX``_bready  (IF.bready),  \
    .``PREFIX``_arid    (IF.arid),    \
    .``PREFIX``_araddr  (IF.araddr),  \
    .``PREFIX``_arlen   (IF.arlen),   \
    .``PREFIX``_arsize  (IF.arsize),  \
    .``PREFIX``_arburst (IF.arburst), \
    .``PREFIX``_arvalid (IF.arvalid), \
    .``PREFIX``_arready (IF.arready), \
    .``PREFIX``_rid     (IF.rid),     \
    .``PREFIX``_rdata   (IF.rdata),   \
    .``PREFIX``_rresp   (IF.rresp),   \
    .``PREFIX``_rlast   (IF.rlast),   \
    .``PREFIX``_rvalid  (IF.rvalid),  \
    .``PREFIX``_rready  (IF.rready)

    // Row 0
    pe u_pe_0_1 (
        .clk_data_bus    (clk_data_bus),
        .clk_pe          (clk_pe),
        .clk_ctrl_bus    (clk_ctrl_bus),
        .rst_n           (rst_n),
        .s_axil_awaddr   (axil_pe_0_1.awaddr),
        .s_axil_awvalid  (axil_pe_0_1.awvalid),
        .s_axil_awready  (axil_pe_0_1.awready),
        .s_axil_wdata    (axil_pe_0_1.wdata),
        .s_axil_wvalid   (axil_pe_0_1.wvalid),
        .s_axil_wready   (axil_pe_0_1.wready),
        .s_axil_bresp    (axil_pe_0_1.bresp),
        .s_axil_bvalid   (axil_pe_0_1.bvalid),
        .s_axil_bready   (axil_pe_0_1.bready),
        .s_axil_araddr   (axil_pe_0_1.araddr),
        .s_axil_arvalid  (axil_pe_0_1.arvalid),
        .s_axil_arready  (axil_pe_0_1.arready),
        .s_axil_rdata    (axil_pe_0_1.rdata),
        .s_axil_rresp    (axil_pe_0_1.rresp),
        .s_axil_rvalid   (axil_pe_0_1.rvalid),
        .s_axil_rready   (axil_pe_0_1.rready),
        `CONNECT_AXI(m_axi_left,     dram_shim_0),
        `CONNECT_AXI(m_axi_right,    axif_pe_0_1_to_0_2),
        `CONNECT_AXI(m_axi_vertical, axif_pe_0_1_to_1_1),
        `CONNECT_AXI(s_axi_left,     null_axif_0),
        `CONNECT_AXI(s_axi_right,    axif_pe_0_2_to_0_1),
        `CONNECT_AXI(s_axi_vertical, axif_pe_1_1_to_0_1),
        .interrupt_out   (interrupt_pe[0])
    );

    pe u_pe_0_2 (
        .clk_data_bus    (clk_data_bus),
        .clk_pe          (clk_pe),
        .clk_ctrl_bus    (clk_ctrl_bus),
        .rst_n           (rst_n),
        .s_axil_awaddr   (axil_pe_0_2.awaddr),
        .s_axil_awvalid  (axil_pe_0_2.awvalid),
        .s_axil_awready  (axil_pe_0_2.awready),
        .s_axil_wdata    (axil_pe_0_2.wdata),
        .s_axil_wvalid   (axil_pe_0_2.wvalid),
        .s_axil_wready   (axil_pe_0_2.wready),
        .s_axil_bresp    (axil_pe_0_2.bresp),
        .s_axil_bvalid   (axil_pe_0_2.bvalid),
        .s_axil_bready   (axil_pe_0_2.bready),
        .s_axil_araddr   (axil_pe_0_2.araddr),
        .s_axil_arvalid  (axil_pe_0_2.arvalid),
        .s_axil_arready  (axil_pe_0_2.arready),
        .s_axil_rdata    (axil_pe_0_2.rdata),
        .s_axil_rresp    (axil_pe_0_2.rresp),
        .s_axil_rvalid   (axil_pe_0_2.rvalid),
        .s_axil_rready   (axil_pe_0_2.rready),
        `CONNECT_AXI(m_axi_left,     axif_pe_0_2_to_0_1),
        `CONNECT_AXI(m_axi_right,    axif_pe_0_2_to_0_3),
        `CONNECT_AXI(m_axi_vertical, axif_pe_0_2_to_1_2),
        `CONNECT_AXI(s_axi_left,     axif_pe_0_1_to_0_2),
        `CONNECT_AXI(s_axi_right,    axif_pe_0_3_to_0_2),
        `CONNECT_AXI(s_axi_vertical, axif_pe_1_2_to_0_2),
        .interrupt_out   (interrupt_pe[1])
    );

    pe u_pe_0_3 (
        .clk_data_bus    (clk_data_bus),
        .clk_pe          (clk_pe),
        .clk_ctrl_bus    (clk_ctrl_bus),
        .rst_n           (rst_n),
        .s_axil_awaddr   (axil_pe_0_3.awaddr),
        .s_axil_awvalid  (axil_pe_0_3.awvalid),
        .s_axil_awready  (axil_pe_0_3.awready),
        .s_axil_wdata    (axil_pe_0_3.wdata),
        .s_axil_wvalid   (axil_pe_0_3.wvalid),
        .s_axil_wready   (axil_pe_0_3.wready),
        .s_axil_bresp    (axil_pe_0_3.bresp),
        .s_axil_bvalid   (axil_pe_0_3.bvalid),
        .s_axil_bready   (axil_pe_0_3.bready),
        .s_axil_araddr   (axil_pe_0_3.araddr),
        .s_axil_arvalid  (axil_pe_0_3.arvalid),
        .s_axil_arready  (axil_pe_0_3.arready),
        .s_axil_rdata    (axil_pe_0_3.rdata),
        .s_axil_rresp    (axil_pe_0_3.rresp),
        .s_axil_rvalid   (axil_pe_0_3.rvalid),
        .s_axil_rready   (axil_pe_0_3.rready),
        `CONNECT_AXI(m_axi_left,     axif_pe_0_3_to_0_2),
        `CONNECT_AXI(m_axi_right,    dram_shim_1),
        `CONNECT_AXI(m_axi_vertical, axif_pe_0_3_to_1_3),
        `CONNECT_AXI(s_axi_left,     axif_pe_0_2_to_0_3),
        `CONNECT_AXI(s_axi_right,    null_axif_1),
        `CONNECT_AXI(s_axi_vertical, axif_pe_1_3_to_0_3),
        .interrupt_out   (interrupt_pe[2])
    );

    // Row 1
    pe u_pe_1_1 (
        .clk_data_bus    (clk_data_bus),
        .clk_pe          (clk_pe),
        .clk_ctrl_bus    (clk_ctrl_bus),
        .rst_n           (rst_n),
        .s_axil_awaddr   (axil_pe_1_1.awaddr),
        .s_axil_awvalid  (axil_pe_1_1.awvalid),
        .s_axil_awready  (axil_pe_1_1.awready),
        .s_axil_wdata    (axil_pe_1_1.wdata),
        .s_axil_wvalid   (axil_pe_1_1.wvalid),
        .s_axil_wready   (axil_pe_1_1.wready),
        .s_axil_bresp    (axil_pe_1_1.bresp),
        .s_axil_bvalid   (axil_pe_1_1.bvalid),
        .s_axil_bready   (axil_pe_1_1.bready),
        .s_axil_araddr   (axil_pe_1_1.araddr),
        .s_axil_arvalid  (axil_pe_1_1.arvalid),
        .s_axil_arready  (axil_pe_1_1.arready),
        .s_axil_rdata    (axil_pe_1_1.rdata),
        .s_axil_rresp    (axil_pe_1_1.rresp),
        .s_axil_rvalid   (axil_pe_1_1.rvalid),
        .s_axil_rready   (axil_pe_1_1.rready),
        `CONNECT_AXI(m_axi_left,     dram_shim_2),
        `CONNECT_AXI(m_axi_right,    axif_pe_1_1_to_1_2),
        `CONNECT_AXI(m_axi_vertical, axif_pe_1_1_to_0_1),
        `CONNECT_AXI(s_axi_left,     null_axif_2),
        `CONNECT_AXI(s_axi_right,    axif_pe_1_2_to_1_1),
        `CONNECT_AXI(s_axi_vertical, axif_pe_0_1_to_1_1),
        .interrupt_out   (interrupt_pe[3])
    );

    pe u_pe_1_2 (
        .clk_data_bus    (clk_data_bus),
        .clk_pe          (clk_pe),
        .clk_ctrl_bus    (clk_ctrl_bus),
        .rst_n           (rst_n),
        .s_axil_awaddr   (axil_pe_1_2.awaddr),
        .s_axil_awvalid  (axil_pe_1_2.awvalid),
        .s_axil_awready  (axil_pe_1_2.awready),
        .s_axil_wdata    (axil_pe_1_2.wdata),
        .s_axil_wvalid   (axil_pe_1_2.wvalid),
        .s_axil_wready   (axil_pe_1_2.wready),
        .s_axil_bresp    (axil_pe_1_2.bresp),
        .s_axil_bvalid   (axil_pe_1_2.bvalid),
        .s_axil_bready   (axil_pe_1_2.bready),
        .s_axil_araddr   (axil_pe_1_2.araddr),
        .s_axil_arvalid  (axil_pe_1_2.arvalid),
        .s_axil_arready  (axil_pe_1_2.arready),
        .s_axil_rdata    (axil_pe_1_2.rdata),
        .s_axil_rresp    (axil_pe_1_2.rresp),
        .s_axil_rvalid   (axil_pe_1_2.rvalid),
        .s_axil_rready   (axil_pe_1_2.rready),
        `CONNECT_AXI(m_axi_left,     axif_pe_1_2_to_1_1),
        `CONNECT_AXI(m_axi_right,    axif_pe_1_2_to_1_3),
        `CONNECT_AXI(m_axi_vertical, axif_pe_1_2_to_0_2),
        `CONNECT_AXI(s_axi_left,     axif_pe_1_1_to_1_2),
        `CONNECT_AXI(s_axi_right,    axif_pe_1_3_to_1_2),
        `CONNECT_AXI(s_axi_vertical, axif_pe_0_2_to_1_2),
        .interrupt_out   (interrupt_pe[4])
    );

    pe u_pe_1_3 (
        .clk_data_bus    (clk_data_bus),
        .clk_pe          (clk_pe),
        .clk_ctrl_bus    (clk_ctrl_bus),
        .rst_n           (rst_n),
        .s_axil_awaddr   (axil_pe_1_3.awaddr),
        .s_axil_awvalid  (axil_pe_1_3.awvalid),
        .s_axil_awready  (axil_pe_1_3.awready),
        .s_axil_wdata    (axil_pe_1_3.wdata),
        .s_axil_wvalid   (axil_pe_1_3.wvalid),
        .s_axil_wready   (axil_pe_1_3.wready),
        .s_axil_bresp    (axil_pe_1_3.bresp),
        .s_axil_bvalid   (axil_pe_1_3.bvalid),
        .s_axil_bready   (axil_pe_1_3.bready),
        .s_axil_araddr   (axil_pe_1_3.araddr),
        .s_axil_arvalid  (axil_pe_1_3.arvalid),
        .s_axil_arready  (axil_pe_1_3.arready),
        .s_axil_rdata    (axil_pe_1_3.rdata),
        .s_axil_rresp    (axil_pe_1_3.rresp),
        .s_axil_rvalid   (axil_pe_1_3.rvalid),
        .s_axil_rready   (axil_pe_1_3.rready),
        `CONNECT_AXI(m_axi_left,     axif_pe_1_3_to_1_2),
        `CONNECT_AXI(m_axi_right,    dram_shim_3),
        `CONNECT_AXI(m_axi_vertical, axif_pe_1_3_to_0_3),
        `CONNECT_AXI(s_axi_left,     axif_pe_1_2_to_1_3),
        `CONNECT_AXI(s_axi_right,    null_axif_3),
        `CONNECT_AXI(s_axi_vertical, axif_pe_0_3_to_1_3),
        .interrupt_out   (interrupt_pe[5])
    );

endmodule

module axi4_full_tieoff (
    axi4_full_if.master axif
);

    assign axif.awid    = '0;
    assign axif.awaddr  = '0;
    assign axif.awlen   = '0;
    assign axif.awsize  = '0;
    assign axif.awburst = '0;
    assign axif.awvalid = 1'b0;
    
    assign axif.wdata   = '0;
    assign axif.wstrb   = '0;
    assign axif.wlast   = 1'b0;
    assign axif.wvalid  = 1'b0;
    
    assign axif.bready  = 1'b0;
    
    assign axif.arid    = '0;
    assign axif.araddr  = '0;
    assign axif.arlen   = '0;
    assign axif.arsize  = '0;
    assign axif.arburst = '0;
    assign axif.arvalid = 1'b0;
    
    assign axif.rready  = 1'b0;

endmodule
