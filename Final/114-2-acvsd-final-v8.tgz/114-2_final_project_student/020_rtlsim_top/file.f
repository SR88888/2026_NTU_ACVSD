// ============================================================================
// RTL simulation file list — top-level (RTL mode).
//
// Used by VCS via `vcs -f file.f`.  Paths are relative to this directory
// (020_rtlsim_top), so the simulator should be invoked from here.
// ============================================================================

// ---- include dirs ----------------------------------------------------------
+incdir+../001_interface
+incdir+../000_tb
+incdir+../010_rtl_top
+incdir+../011_rtl_pe

// ---- shared packages / interfaces (MUST come first) ------------------------
../001_interface/axi_pkg.sv
../001_interface/cmd_pkg.sv
../001_interface/axi_if.sv
../001_interface/axi4_full_checker.sv
../001_interface/axi4_lite_checker.sv

// ---- testbench behavioral models -------------------------------------------
../000_tb/dram.enc.sv
../000_tb/mcu.enc.sv
../000_tb/testbed.sv

// ---- DUT (controller + top + PEs) ------------------------------------------
../010_rtl_top/top.sv
../010_rtl_top/controller.sv
../011_rtl_pe/pe.sv

// PE sub-modules
