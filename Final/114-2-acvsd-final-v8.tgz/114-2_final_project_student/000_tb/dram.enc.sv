`timescale 1ns/1ps
import axi_pkg::*;

// =============================================================================
//  dram.sv  —  Pseudo DRAM with latency-modelling channel controllers
//
// -----------------------------------------------------------------------------
//  SPECIFICATION
// -----------------------------------------------------------------------------
//  1. Interface
//       - AXI4 full slave interface (axi4_full_if.slave) with 32-bit address,
//         128-bit (16-byte) data bus, 4-bit transaction ID, 16-bit wstrb.
//         Width constants come from axi_pkg (`AXI_ADDR_W=32, `AXI_DATA_W=128,
//         `AXI_ID_W=4, `AXI_STRB_W=16).
//       - Active-low asynchronous reset (rst_n).
//       - Clock: clk_data_bus (200 MHz / 5.0 ns period).
//
//  2. Memory
//       - Flat word array: mem[0 .. MEMORY_SIZE-1], each entry 32-bit.
//       - Total capacity: MEMORY_SIZE × 4 bytes  (default 1M words = 4 MB)
//       - Word index = byte_address >> 2.
//       - Uninitialised locations read as 'x (propagates through simulation).
//
//  3. AXI Beat Size
//       - Fixed beat size: 16 bytes = 4 × 32-bit words  (matches AXI_DATA_W=128).
//       - arlen / awlen encode (number_of_beats − 1), range 0–255 (1–256 beats).
//       - Address auto-increments by 16 between consecutive beats.
//
//  4. Read Channel (AR / R)
//       - Latency: CYCLE_LATENCY_READ (=30) cycles from AR handshake to first
//                  R beat (models tRCD + CL).
//       - Up to FIFO_DEPTH (default 8) read transactions may be outstanding.
//       - Burst engine streams beats back-to-back once latency expires;
//         each beat is gated by rready.
//       - rresp is always OKAY (2'b00) for simple simulation.
//
//  5. Write Channel (AW / W / B)
//       - Latency: CYCLE_LATENCY_WRITE (=20) cycles from AW handshake to
//                  wready assertion (models tRCD).
//       - Up to FIFO_DEPTH (default 8) write transactions may be outstanding.
//       - bresp is always OKAY (2'b00).
//
//  6. Output Timing
//       - All AXI outputs (ready/valid/data/resp) are driven through
//         `assign #(OUTPUT_DELAY)` with OUTPUT_DELAY.
//
//  7. Instance Identification & Debug
//       - Parameters DRAM_ID_X, DRAM_ID_Y label the instance in debug
//         $display prints (testbed.sv instantiates 4 pseudo-DRAMs in a mesh).
//
// -----------------------------------------------------------------------------
//  MODULES IN THIS FILE
// -----------------------------------------------------------------------------
//  1. dram_chan_ctrl  – Address-channel FIFO + per-entry cooldown counter.
//                       Instantiated twice inside `dram` — once for AR with
//                       COL_LATENCY=CYCLE_LATENCY_READ, once for AW with
//                       COL_LATENCY=CYCLE_LATENCY_WRITE.
//  2. dram            – Top-level: memory array, read/write burst engines,
//                       output-delay stage.
//
// -----------------------------------------------------------------------------
//  USAGE GUIDE
// -----------------------------------------------------------------------------
//  (1) Loading data into DRAM via load_file
//  ----------------------------------------
//  Call the backdoor task from the testbed after reset is released.
//  The instance path depends on how dram is instantiated
//  (e.g. u_testbed.dram_gen[0].u_dram).
//
//    Prototype:
//      task load_file(string filename,
//                     logic [`AXI_ADDR_W-1:0] start_addr,
//                     int num_elements);
//
//    Arguments:
//      filename     – path to a $readmemh hex file (one 32-bit word per line)
//      start_addr   – byte address of the first word to load (4-byte aligned)
//      num_elements – number of 32-bit words to load
//
//    Example:
//      // Load 1024 words (4 KB) from "image.hex" starting at byte address 0x200
//      dram_gen[0].u_dram.load_file("image.hex", 32'h0000_0200, 1024);
//
//  (2) Dumping DRAM contents via dump_file
//  ---------------------------------------
//    Prototype:
//      task dump_file(string filename,
//                     logic [`AXI_ADDR_W-1:0] start_addr,
//                     int num_elements);
//
//    Example:
//      // After simulation, dump the first 4 KB of DRAM(0) to "dram0_out.hex"
//      dram_gen[0].u_dram.dump_file("dram0_out.hex", 32'h0000_0000, 1024);
//
//  (3) Direct (backdoor) read from the memory array
//  ------------------------------------------------
//  The mem array is public and can be read directly in the testbed at any
//  time — no clock or AXI handshake needed (instant zero-latency backdoor).
//
//    Array declaration inside dram:
//      logic [31:0] mem [0:`MEMORY_SIZE-1];   // word-addressed, 32-bit per entry
//
//    Access pattern:
//      word_index = byte_address >> 2;
//      data       = <instance_path>.mem[word_index];
//
//    Examples:
//      // Read a single 32-bit word at byte address 0x200
//      logic [31:0] word;
//      word = dram_gen[0].u_dram.mem[32'h0000_0200 >> 2];
//
//      // Read 4 words (one full AXI beat = 16 bytes) starting at byte addr 0x200
//      logic [127:0] beat;
//      for (int i = 0; i < 4; i++)
//          beat[i*32+:32] = dram_gen[0].u_dram.mem[(32'h0000_0200 >> 2) + i];
//
//      // Compare an expected value against DRAM contents
//      assert (dram_gen[0].u_dram.mem[32'h0000_0200 >> 2] === 32'hDEAD_BEEF)
//          else $error("DRAM mismatch at 0x200");
// =============================================================================

`define CYCLE_LATENCY_READ  30   
`define CYCLE_LATENCY_WRITE 20   
`define INPUT_DELAY         2.5
`define OUTPUT_DELAY        2.5
`define MEMORY_SIZE         (1<<20)
// DEBUG_LEVEL — verbosity of the $display prints in the read (AR/R) and
// write (AW/W/B) FSMs.  Compared as a string at each print site, so any
// value not listed below behaves like "none" (silent).
//
//   "none"   : silent.  No prints.
//   "brief"  : one line per completed burst.
//                read  : on R_DATA final beat ("completed final beat! Going IDLE.")
//                write : on W_RESP B handshake ("completed B handshake! Going IDLE.")
//   "full"   : everything "brief" prints, PLUS per-burst lifecycle events —
//                read  : R_IDLE accept (addr/id/len) + windowed R_DATA beats
//                        (only when addr falls in the 0x80040400–0x80040420 probe range)
//                write : W_IDLE accept (addr/id)      + windowed W_DATA beats
//                        (same probe-range gate as read)
//   "lizard"
`define DEBUG_LEVEL         "none"

`protected
\(E[/5B3\N88+49U0^Y/@692JF?BaU>5?D^g/aR)?C.UXQYY2ZQO6)UQIgLCe.YT
E691RWYZ\<YS+8XYZ6\OZU:9KC@GT>DUY?e^;3.4GAT#P=5Z_cNGb4c]e3+E4L^5
<US4X8GBdb)g;H>=0=2T^#2<W3C]E\Jb3M:VV13a2c>:cA4>F(:>)G8]30SJ2DeW
2\-CZEJVSBKXY[;T,._<ZX49dN>ZdM0]\^Q#JW:5LL[AbP.S(ff<\M(:[,#/ZGI:
9EYK^7[-XD)4?Q59,e\4K::Xg@-UAZTT6S\P05W2gEC<cT=fRZR+eNWQ,OgI.4f+
\I<5E3_59bJQI&E.G[&dWV0C+c)_e_&N&3=dC])BPABMfP(HdUW4WVRd-a#1g3\+
2KSe6F/CH198,HZ^TgESV[#HFG)^CWJJRIU&X7I]MCW[J_F+P8_U=6)K9NIJB49,
<0\(K#_DaZL=K8A4FXe7CF)IGLae)c[K],UKNYSMd\3eB6]TG-EA.2#b+I^NBeAS
#/006OD]5<IVJd4d0H]WV>P:#E5[V[X:;/L(V\75\eF3=PX<^<7dV9VZ9^eOCdN&
C3ZJXJNQ1\>D8U>OAW3\):)?4I>PWbegPaUOHWWS040\R,9^88N8-QKg.H^aCMR7
+OSKdV=g),2C9L4]YM96<@U6Y0V:(BR+f^;,DW]IZ#R?HR1>Y?BVHR_=Mf<Q5OfU
GH3R>MS5d8I1>B5;>DBNL3SfWA-6FL+(=DOEeJ[;+a.Z_&.a[e6)#=3RSQMBb,=+
,1V?HM^/^CT?RgI5JXA\#XX/YZc9XZV350SaH1V/)BZ583KMNZ&gT^CG=DS)-#,A
+946MBdBcML[GH1MFUU^HR#-fFd;&^NH3fI.a)d4:+-B_47DU#],TfUEDQ)TZgC3
(41Q#;Q-Wgeg?b7T.=/HTTQ&<PW(\)FNL_KO_691N@M.NPD/[Wb3#,FW_/3\e8TD
dPa(AZG@.:&/8N0&DW07,T6P(K5W)D<T/2I\6A7HTd9\D>gDICG0W8S)QAJY=7@V
<^RZ_PH9[NfHgVW&?S;X-M/QHF<aa\DSe#H)I7/d3)&3,FUc7U97fP:0E?<MRX,a
[C2f-g_[7T46?f7:I?MV=McR]ZNVe5X15@==VZ08G@,9B0>0FU7MZU37S:V/A\]C
NKEGe),cb1c(M3_GF68=Uge(afT<<L89<dJIHgXI7]QATEQ_;0_,RMb1GZN]-.4-
DW[=##V@9NGV<FW@5\-05.&)=#4[V4g^#T_^/5JZ:?-gQ5-L.G@aOJ-b496]]-fV
ET?6M06Ob3J-2VQTR>75T:M@K@H[.#a1HG\a#/2=aFX(cH+R(\afg5TX8&(<>Ff>
L:&1Kg.[O3d5JDX+93)LCgK]Pa:7#,G32J:QL;S&a&N0Z]3B+g?X/c<_Lg\^PKI6
B).^Q5Z8>cP#R\<0V>/X)JLR,@]b9)50P)b&bg8,K&b9?1)PZd90fC>&VbI=<Xed
-.A&-MaV^G3[4=.g>E83;#3A@9<]9f9P.:H6;eQ1/cdKM>9c:67@9eTS5_[LX=)I
GW>]?T(ScVZ@0S)=BSV^cB^;Nf13N1=:WBYB3-LfALWI8-b=Q0D\KVM/9PAZeJ:C
6<>82[&\cD,,3(&_;4P:aY[&79b#J],=4+OX&D86JbU+W,UCeP?8[Y9N=I.WC9:1
\J@4NUc//c9@?HP:M9a3Fb3PFT)c3J\CY5CPH9Q;X=#6&Cf(S#bTMLa,/F+J7SZX
E.0a@PHg38=?ZbA,-8WSA?WOL>8;FL3K,YC97K>7bZAFPg=4AV6Z6C-P8?d9U0>L
CVB7b^I,P6/Qc^]WS--6(?D@.Z>?C)3Q&Q2C@+1ZJa<)(7NJ(e-R3TX7=WB-&##N
</H1B997B-5gN-MIT8(AZ)LRNZGYJ+QcZfNYD/]);M.Q^_<#]@\E-/T?R)/7J,SS
_/fK)Z_@AaG7NDcFb1fIU^aOHV<\C[HgB>g756/6&5b3\0HNW/[+^E@?JVePR0EG
]9]b\)FaN<d0W-a7A1GOT&<0=<)d/(VXb#8=D_)+UGBDd(&V9YCLcGLI:]a4bMG^
V]c:L:A7(@K<.B_F&:E+Jd^@Fa+MBNg0/M8dc/PC9#V6MSJ8/;X#;43H4.S:T+L#
1JNebZbCJ>EMLB;0DTB<<E2,J3W6XcP?IAMT0V5;Y>9GIP)D(-bU1XY.<c6+W;RW
MENLS:Gb3M9@bP]e(,JQH,J+6^)eE:^3PJ3>>#VF3baO86//)1(bL4V]RYK=Dd^U
7GZ[]KOM)a73F<\,Sb.00YU[-6==G2EO0/UgPYK^gPg;-W]GN7H/KGRbGV[;]Mf6
1@^..4J5Y.[D=+65(Qg?:b]55f9D5NgbK2Sa&B]U2KW5LN_CFCV29P7\7:_#MV1N
4O.S;&Adc9/L6)-+OfU08[FXF\O&1?V1H3#dPDUW>-B<3bV55LD.Za#NV,?#-HA4
^2,60YUf6VDOb.2ONSN-Uedc_EP2U]-V48IfeQECVdG^JNAV==Y-Y+ce1+ObU8SH
OP_eX_@9<B@B?R&]:c22^+)>9HcP[(BWaGcT.5;PN+R0-;[W&P^GDV0-[F2BQ0M^
eI-1TMIbA1C<30Z5<d@K3ae\HS0dHa]9-Sd^UeASgg]WUW@H,1J;&\[&eeE)W5Y.
,&aF)7ZG;F2gQKa&6e6?ED5J@,51=)?YQ3LfK1_GIP9aLePK:\B9WX1J8,?1Odd_
aIHXC<(&:.=SS68DG5&eR^I70Bd02C.Q],ZdN_N#9KCU226L8/\Q<PFUSd29;\>B
+(,K0&/KVf7TF-8(X37bg:2,F391I[&FW:(J@g[@ES]N\UC0Y5.F]V7,^>bXISLe
1f=OS5PB++PJ^:\O?O87[VTR85VG19-8YY&Vfa))\/NB.T)5/gNN/_0D#RIGQRW\
TI6#:\PF.V>9[W>=ML820P73=DM&:g>A@a8KFS)E,P+Xc3G-9R,Z_Y5#]b(DP9YY
?0g/5cbCY)4;U1Z=>W/&D?TbJZ\g.03<N]>[J5.<_+-K\&32>U5Za:22A1g9g59e
-OZ-8J=Y&K0]=79D)C9,06\CdB>f>W-RT)-W:J@QJ]<GH.;&QBCJa@:MYYPT//EY
Yc&,TLZP=J]5BURVL114W>E(^^UT532egDd?(e7Z4:CO4c)YALId-6LMWa3SaR5G
6YM55[)S=AD]L+e^aLCeC)@PK]+^B2>2E[91Q&>MNeN0g:(@>C4CY-)O9-WZe>3W
EQ+0Rg@##fZ,N6AP-V;=_YAU]41gE251<MH:JAGS.&89K&R?3J/e;fM.Ne]S>R&.
:aLR<X[fI#YSHf8>,FLSQ0>a0.c2#92_V&K@//Ie_7)aNO3?Tac798S07OZbQ(,Q
T3O-caD]Ve:IE,8.</gK2/R26dD@Xa1MP46ad&9?cZ3I\\8#OL#Fe0=+E1NE@B@@
D[X\_Y8W@L:NI:0#f1;F3F0QU#/4T?C9F4&cU)VP&f/P9UW(SW@-?GM[U=6RZA<8
Z/@e@?N36G2(&X\L<N,30X61]GE-45.B3@?VS6SYbeHVeZf^I_XM3^K@G2EQb9^?
6>)/TFf2+;1M5#6+QNA,P:a8I4Q?))g4\5+JV^JEV_YA-:),NXLIT+TK9ea6==?I
-BJ?<=.W:b-MZD.Z5;734Y&]/D=4B79,0;e7X9#Ka\T2c?J=>G8DZ_[>UK<<T;ML
N[F/Qe,eIfD[LM0>_JL=G^gQ@H7^N1,S26>b/3a:Vb@U;d[1MbP^L3C[TR(GWXG3
-1adcX&Vb&gZOR,=]:XR0CHYB+.HQVF#^&;9_,CI71W?<bHH(^[/4g/W0=^KNH&R
IS^)(7E.<2S=IUB-J42:bIbU4^RCGF2SNO,\.(HHYUY69GgEOLUg^KWHWCd(RRcI
BSZDYYQE@ZaCBc_4#&+VYRI=PCY<H)f]0HSUNY\OAb3ON.&K,R0B=ZEU\/;;MDB_
)9Z\XF0CX39C+$
`endprotected


// =============================================================================
//  2.  dram
// =============================================================================
module dram #(
    parameter int  DRAM_ID_X    = 0,
    parameter int  DRAM_ID_Y    = 0,
    parameter int  FIFO_DEPTH   = 8,
    parameter real OUTPUT_DELAY = `OUTPUT_DELAY,
    parameter real INPUT_DELAY  = `INPUT_DELAY
)(
    input  logic clk_data_bus,
    input  logic rst_n,
    axi4_full_if.slave s_axi
);
`protected
bX\;[BC^HbC6+^:^\_T?JVd45LfVOd9C;M9g=(>X7S@1NRN(d\]b5)cM=/Z9ZDH4
ed?_MT-_Ae7,D6a>RDI[bF_:Va\>Uf193+R?I=aNeJ:QgP[(GfH&d+:^Y(D=[;J3
=cI&6]6OgE3=KGgdg57+MG3[d,^&-LdQ:,,G/adFI<S07##+C?f[(BZ(fZX&C@R@
;K;PE#16ZG95NMdA9,N5&gT+;b);g5Z^P5;U30Bd\?#@#Of=Z,eBF0/S2))>F>-R
CIJ=S5d)3.U8aO-B75<QEa#ZVd:@d3?OP87PT6dSMaKg0:cY,&^9IV)E.BCF,KgU
KKA?#bRY]\,V+QH\R^CKM<HUTdHXH0BF:4@6M;G#e=bIK?LNE@4_.3dFZP&HQc6N
/<<+[N<WQ&);MgJGAMO9eG6F&gJ06KPJg:c[J,OTW?X]G4V(Ka@F:]c.ZHYc.#7[
RfHG:2U<_J@K=aA;4MP<23;8:WFg].QIX50CKVN3H713fAE,54=J=XCDPNK:CVR(
42]RaH.aW@JNJ(fJUDc#?-[V]ZY&FL+-B):TX@A;0+bf+QZQ8VGS<M(C-8I1fY)g
RLK[U[aRg1CeR&XbHA;c@;cF&^(TW&0IQ&E]g(;Bb8]FcXO@;7c[bJI-@@2?J+27
0IT78\d1EK@SF^6JfQ-a)\R+6J,=1&[YJ2#NO8@b6#D/f<&a@Cd>Z+1=6+>6>D94
EZ6>D.QA?g0@J0ZD=GKRO)@RV3>U)Ob[V3CLeT1CDO.fP_-]W47<QH,;#U94/Z=.
J=(^P_FMV__QAP^V2eN-Z9#S<VSKdgBR@XQDg)_CMR([E\>::@c9[fE;[NNE.K47
fWE;V\]J[>b-c)(O7V+QRSda#[HXC[^6[f9+2E@G7@(6W=K)2_CHF,aFH@<BW#H5
1K8V2@MX4E8&:c_+VLgK#M>I/0cAYF\a=.-)g1WT9RK/9=RV<-A^X_29=WAMQY#Z
KJM.+6&RH4=O[//Y@R#WY]>8a2#Q51Zg_3\ZKFd6+J#-YRVF&?2aYQ&Xg,L&1S2V
XfZ-PNc)D5dN.XO6Q0SdcOTE#bPZF/FeeA\YP[LA@0cGb^.^gFD5:#]HgQG/#XKX
N5\Y0G0RIO31I6X&7:;U^8S2#^=QR<[I>LXKMC89:_IUO<)VIQcBT?X9>7d@,3F.
a_L=;@UTH-Zb_?\4E22.07#Xa-@]]4@_VY/4cP)&Oca[F(LJ,X87V::(@+^5U?I0
6HfN.3M]2N4/V.8+)6T&K@>2]f#V5Fa=K\AV]+37RT_IXAG,d[U97CgBL<K&\R;E
ILIN<[?653cKcW9Q-4B)J=>fDH:UgRDNfXQS-fGU]9.88DU00LK6d,J?:L\0AI_/
OWWe;MJa5G\-?ANI:M>FA+(.OO>=J7KJY&LYd?;;:8J6Pe8=fDF<ge&13,&@XJ-8
OTNH05LadUUV]TefeQZGPRFTd.]>ca_PJAC@KT]be;27c5JK-531@=:#DCOMZIWe
)b^1W7Y4BFe#7&/XgNHeNGf8AF41F=63NQ12@8,@.0Gd#++73P1WMTaK)K-#C4Z]
c:U\?..3+[KK7@Y[ZEab;=dYRg.G)c>RMV->Lb[g,SQ,P0/41KT/<<)^3V]53IZ8
G<^(caBF,W92LVLI2GJ016]G,016fe4S_,KL#HVE349YB/XSZECYg@YUQ.-gF&3E
\D_CE<3eeME+6->_M+7A6K-:#>+B,YcO/>P=TXLY(:,P^H8fbaJdP4?\VF3NV5Z?
>?U<YP;g=D?..Id5E1I60LZD2EHN:]JAaH#9.1FbT&\=LNH[gdeVMa?7^J8^&MX#
Oe#VaSM;8Z2bQR,_b,c-c(-J)]U9KXWD17(4)>@3H]<@Occ@ZEc9_>=98e1<=5KG
<SKD.0U88&-=(FcZ.].Wb?#F<<[-YaCGR)YBW9F7L([a4D+5W#YKU4dFK61:1M+a
FL^,NaCWgRZG4e6.H1W<Z.]8_Kf=L-APO5EMf++<:dNI3J692S.PC:eaON94IQY?
S]Wd[RZe;)EDBfJ<OOM<Z//^WBMC[;+YR[(^@BLcg./6.b\FagG0R+TL>&JQ-4AP
@g>HKRQ9E1PT[Z)[AZVKN7:0OC=c:/2E9>RHRUU3#RdQYeL7PATFb_KH:5>MR(VL
Y0_]H47)B\^-:H8IPA2/6<eKT&-H4<^6D_,X.S+aD;:_/G5UA3F>&a0^/?5=gHE5
P;.7I]f>IL4&KQ3B3XC9Q#c<>_LDFC&PJZD+?Y&c.AV20DHf-W1>Za)e<)U)UFN1
I8&V6c5Sa/d23?W\PZK>R#NOa<f8),V1eTg]FA2Yd3;_=@J5[H>G->E^462^R1I^
E<aNgKHU2VQ5O^fEYg8G&VbNQEFY4B1.aSgA^XA4EEg9a3LCW=S6^;:9,.81ffT3
0YD;4>DU[=2aJEVfL:&\FP-#+GWZ,\aP@4FbLWNJP2XMU8^IQ_;XO7MC0]H[<840
QX&UVVY84:22@PX0):M@-PFc4<g<[ZZ;?-MT23\E&(,P=BZS>Y@M3UIP5HKb9)++
QVO;I\<40JaQK4#X]=J=CZb)T\40NYR/S3g7DbeRPaM>\eE&8f+^T>_gF^O577)T
]8,,0G+?FQ0/d1cJac0[cE?Kc/85VMS.YQ0&Kd.XVfPD7Y:L5.J\#A_dLL)Uf<2H
O]_0YJGP76fU+NXdA2/_67(5g.W/cGUUg.5<N)<7LL./A#],>3\P<>J/6+Sf>GO<
\f3FO@RB;[QeWTIL/A,PEI;Fdg0;-ca)-8)N/-,S0A(2?_[:GAW0#b92E?6//V]B
(2<BY+4CDPTWH_Q.>OG)BC6<:@UZU72d6UYeDB>_,CAE_Pb0ONaGPEgCB@ePK8XD
<,&7EYG+)gZH7/[9D6[ZQ[&/=AH:F2QN3/\MaK+@H^GCA(UL;Q@eAc/1&\\Z=?XG
Xde@3,?O7aT0?Z:HG.I-8BHY._.>c-H04#O=M^d0dA=FW8P-bM5C+1J72=-Y8Oe=
X36D9D^9<b.8,+I\RRA_EaO0K3a<6LN+dM9FT/DQWSW0GTggY^P63ac)]gV0cY.H
=9>Gd(gBaU?>,0D[?8cf3]/?DJ)IXaBe-V::COaFKNS7GN2#9EN?8UfI>fefPGT4
MAB6J^]Z[5SPX&H<&#43[Ud3@Y7<[=@MJ,LU5e6;07#[BIR&fRcTQO<.7Jc.EO\4
Y\6..9IWRJFgIL?SF.8N.[4NfOUYKS4<P&,Id/;B^&YB,LR8cT<DO[NJ3<25HR5\
5[)7fA?g+[A)d+(209CPC2RW^TM(8#Q@,5I-)Jc,PS&TP+^;SdA4MU\Y]DgMG^?]
@f[M=PEV4)(YPb;cc6UB137UTL31d(S;eacNa,U.,=JT/?])&f-\1N:(c?:+>Z/#
3^6dH5d<Zc\9T[fZY+UaD.D5HP8JR.Y/^#>T1LP[fP4G:@CeGHE;4<_@^a@BJ7N.
+NK]E-YG?4II_PH6@\=fA8\;aW)-:]&]:COHTJY8e&7:6+a8D(bBWCTN6;U0.]6[
;1@1D(:;2.gf#Y(ScT6fe<@YXIX;9a_NgJT:V^505\#?<)#BaBf,_BG[@FP/SCe3
JI?H70L&4N/REU=JY@:-9<MQFZbL2KfEBWK1>/M5GgQR,:#^2dD]81@.]]Y?1YX[
9MGg:T;E#eVNC\MA?b4/=A.;JR5N0Mdfgc@EPLIOR1^:D<@VCBU]]HLH:_-dB9/6
^_PSZ,eK))X>V^RBe)2X2_g#I/6gSeC/GEVC@8C.+179#6=[=VL8907:dX)dfIT(
/8-/)\e+F+,UB3SFgLGK?eNK8&7d:7CE-8T7JGM[f8QTW@O1a\E;(Q-5U5ZTeYf=
8S0ALSYS4O-Z3ZGU?\2H1^d\8>K?b@\#OIa67?Ya_MTFYFD-eV&[:Q,@JZRY)U@O
6G+<P10&;_3ASVI<93\17T[+QGCA7A49_Z0=E7Pea@=M_SDccb8R)#T1a-I=KTgC
R1M7d&9c>,-K^C2QDL<RH>N5Q(0>>MYMfDbG?6)#M@UfR;PLOU0(4PK=dOF?7CP7
^\DN05;c3g+NIBbZ4a_D.:8OL<RWGe,5g8IQ8&>[5KNCg4P:dVCESa_YVD+;L&R8
eX5Y-e3G)H3-WB(D;HN7-dU+b)H<6LW0,@2TbV+UeQbCZQO5(5W=COJDJEJAR5\W
@NF]e8V:&LDH]UNf109J@c.F)aP7P&K)I5G54>N&NS:U6C_[K?ZHVG6a4b[+DgE.
8^F,Pe6M4HI4a5??;Q,??P9W7>&5BdL&P+G-<:H<4a#AIMcL.CZ)3U0d;F\L=3>H
NU5=f7cCL0(D;_KFGI5R&Kd&F]OJ[[Y&UCN344a?)f/TF:C+,IL<XQLBHU^H\-dD
g&<RKC)^RE5CU6G2#4O<<,6,?EMUd.T;F&ZKS<<P-Oa/+(1d]&[QV69/:V[#=F1d
=G0UXC86,[9@F+c(c[97X,NM_DD[42eHQ9/R25R5H3IPO>UdZ.6Q(Q&,G5V/>X+5
R1YZg>e)/FQW3O8=69gN8&d>gCA>be+\<[\9)R6<S,cg6Bb0@@\JgGR],/=eMYbI
:NXTO>=#BgU?0\daA=.TC@RS_.fME6cS)K)gV/(]a9360He-[KX=SYK[?NFU;?G3
HXCG9c_a9-./FVNgB9/(W#&W8_NaK3-U=8\a7ST-D<bX,a[Mb0c=M;V>J,O&X+?G
6_@JJ)94JZM<(QRW+FaRA;?(D:YGW;e-,/_gce5Bg<6\ggA[9(56AaFF>4^<EHbU
5M^RaG^/.bAS:==;1F)6,aSQI]?SZV[(3>Cf;9Q(]@fHJ;:8V13-@(;6;d[^cE=b
\<e+6f0]A[1.La9W2C+BDAVJ,DY&YR:Jf1[g=LeRgCQ7R6^>N--.8E,M04[_-^,M
Xd/f<#2b>+#;GaF2]^7.,UPbAaHag;WYH8C4<HGegWKM@P>9PX>&A5=cbMaRCR56
ASVJRJ4..fZbB?@VIe;AU)4JP9N1db+VX1QeJA?/8a[XUdF]__+MR#]TKJAMAHFD
fBccQBWD3g265DP[[0fU0dfQCYKf:G0XaEag7)WSNOP?LfgS.8/L-b5Q:-[-NMg0
/>D+<a1\BR+Y&R-YI_H117@X:F0)FUIX4+\>Zf(N;[Z(-T44ed79T]:HS]6f;ac5
-I4YY0^O00U2]c[ZXTDCH.P,3<TYNLgcVH&OP5PH>4?H+&_N+RKSAf=3NR6@e0_^
AC#_YR_NDD5?RIcb#_J/6KT0P5dR8CTG6LM\U;5>J3EN^EO6P56@Q-I3_9,#E&]2
O^7a8HP.MGZ=)bMMD#WV-?]4C0G\^9GXS:WC8fRZ475@[\:gZ2FGH)GO_?,:2BG3
H<S0L8P_T9?P?PcL/JCP#+&C[;1+OPgM;aG_)5AQOC+BGDJ&4c=OJ=]AHPVPJ\>T
AW]C3=U<>JQ9TNaVH[S>Z_XTX^YDC1Aa^FM&)C^_?5ZJ@344]&f8U/b7V#gX:bH,
SaLd<c<SN\_JGZ+QP-G2F=(FKQ;44g7Od6?9Y8d+;5>Z(2;5;BPT9VdXCH9GFI/?
+Yb17S#b_A>ZH_V0&a<,eB1<6BFLOfaRQ^3a3Y)I77eWb&/77H>-VC3?GDR=O7A]
<a6,SEG\K2)YAb>X-Wbd3a45&JM>U6HW=;4DdM09YbUPCJF##0.;+g1^?K8LE<=@
NNFDZDDKV]#;\cT5(?\C_76Ucb(6\@^LQHNTM0;V]/?BVH-/,@L-0\2\9=g&Z+XR
D?f1D.NaR6P?+OL/dX[8f/=IN36KB\KWcBd.O[e@)8W3-[ZVSC>><HOGZDON;6V)
-Zc.^02)@0@=&1Z1d/_.?a[OHdA]/ae-YG664e71J_ZT4;09LB.=AVa_bM+Q3:Nb
UO1SUB(eeKW<\U(7AI]B01cMCIgCRP>#C2#1a0g1bO)e\FKD03fdV1:,,,EL<4RK
+2L-HA&-H<9d)a,)ZdR.a3G_,QN7K4NCT//gHLHa,)\3d6PNTY/N@,KT7++CC?_G
(bIA5S,OTA;cWgIKQ&LcG[)P2fN0T(2C?acCI/-IIX>-c@COXcL=a]V@ZWN\;_,/
+4fb\Y^M^1[GZWF/P.e&P:;]+cg2/=(0S]f-N6b;gZ/HWN)U<CP.Hc,SgG^1MG]d
1SCAeJODDX_HQZF5V.e>dHBQ>[T[P#3?+LP0&;S[#+EcM)d>_;?3&]/&B88IbZV&
7=FRSUN:@<.NJe\M+K>9)^d+RY(5W_Rf.@cBZV<JA6Ad>Q@3.S#V7YR7<.bJROJ>
RPJb7HZ_<f4=@K:S:0UF4-)Pc^1B4;;>QS[/#IIZ]\6/IYXf2^;C6\H1OIVV7bFV
]4BeH@QI@>0Xc;DKA)C:_<=Xf#&_Hg^3Mb,B)4F.V@3HA6&YZgO<YEeT\D&8/O28
:HW8ecWMVC\D;DBCAf>D+,g&4ASdQ;SGbIY.,I8(OU6F/HD]T1L#+)2e^I&]E)^+
+,QdfUATD^Q-8LgH@+5D^4<fg9V<#/Q7XTI>BE+2eEKKc)OJ;6J_d8O)POLXN5GR
+T.W4.^M)&3I.VJ=:Re4]-d;Wb?2H?52a?F8g>YDHI-GYE[eLU[Z9LD+2T81b;Y_
79&IA:1aK+&4c:@H\8:\IM&.\(2@Q].W,dc7HM9^O9gg^g6N]M23d,.(e>@=<=(F
Fg7<ZM=>_@?V3?0&BeUa4U>[7^EaIO5#Z#5S-V3G#+3/c6A(T(7X9>YC+X_aUQ5]
OHdUU=+feFQ>1cIaB@:JQcN=;ZdUQaeB]EM&;e-e:aV0(WH.<A(4MdC]EEDP3:XL
1549K&N3:DR9&SS^-aZ8XIa1S//C^^ON2K7JAd1?A7)fdg=-M7)OBK-3^2:A+:=f
NDL#^AM&\I;.eZXI<VMV?JQMN8NCg+dc.^=&\@^?:gdJcF5c20(1W._ULWf&6Y_/
#WMHW&D&=@.CU=PQ9[dQ\]W.RcKO7L(-2(R6[9<9dP8=Q+]DIXGI?JfNC]HWAc,9
e/JENENc@6U=_5A43ZRccU<Kg,?FD,8[=VH>WF=\7DFVQ\[d)D)7:D?aG7J3P-JG
Ff&\(ge]&^78^W0[KZ-Feg,;([aB+P)=+0@.NaPKLFD@d;BfRgJAP29CHJ;TQ5J]
fFAXK1F^--:YONXAaMe<=6>U8T#[]DX[PZH52-eC>^=dV3&MY1Gc#=)2^CB4Pe8D
gF(3^6<]1GGNd2;LU9?[ETX4F@aGRR6Rb^MF/daPZEX.P]\+PXL&L]4))fWa98)b
LBB)9_35A(c)E[#RZP6[9LagII08]9(><.J(LK8D=@daKKOcTKd@=gA&=RP)[g?9
:,_CH[?R=(F+ObVSK+O=YL((^PU1?O(4H1),6GV3=b#Nb,8)7ZP0(FI#dA)_7(d+
ff^KG@WXA9\LZMAE(\eW_<@A/g,K^W5EF(ZX&c^1N^1c@)B3(B#TYKPD3^=2R1M4
^&D(Q[:5dE:I#b?Q2LH_e_Y,]d0#=)E_e>I^6Y:K@BMcY?;]7_CWH#\3MR+3C,NC
Z:):#T-<_aQ<a&9d2a/;5bgZ/3\#F?J([)WP=BIU.^^5NT-XV^.E@,B@BP,QVP#-
9JV_QVK=@#6Ic4K:5\JT#)-e:Z<[XQ29A578=QT<)@-V0TQU6B0@I#F2aXdWZ?9D
]UMPCg;B]Dg3bF_f(VMbL?K.=9)S_<PG688A)3ZG.AC3B;=[9:],7d26@A<TMZQV
b/Od4W#[fTJ6_>CI,680^]^+D3><K8?,#R=#N&X^&LXT.Sg3_5Q+dP+cNY4I0(^N
0W,1VNK>XAbMX3W91G0e(+,NWg9VAT&(a[MJDWa+TO&dLXO6Q:L&0L0?eDYIaAR@
LLg.74Q3?(+)R22OIGQfBdMM3POI<afZWdAEXbVWO2XS1fJa3G2^Ug^1R&6P8(58
eL^.JX6ZL3UU,3VD61C.=N>RO;>eCcEJG\M;FY)f)V7O?\2AOUQ7W-OBRB?&JEF0
<NYDV-G6I/Y4,NHER0K?J0URWa=+S4S5Q2JO@:J8P:)CQ_+.@D5)15gZVS2LgW10
]TeEg@\GCDg3Z(-V.e.XKKLDBFVKTC]>_V^(EOO0H\,[]b<,\NNMC=PaAI^:;?7Z
&EM54Jf1M\,RAZ.M+/-V_#f)PC]-f--LY(F&=K;<GX--_c=P^b;\UI@?ag<W_-/T
-P47R?PK-]1eIgOQQ^X;U4_<T^Oa;MKcP3\=M#G(CP@TD^0Z\2.Wa@R0bg,K]YJ;
Y7X+)D=;;fB[?<(H3C^==-H[7;#9)YMA\eR4H,OAYb+&XP\GaKTaaB0dCCRfA3YK
@WSD+U\4B\H=e(V+4XD=IJgaD]#J&Z1+g<LZ;^]d2WAE-KNJOY2-T6CNd>@c93X4
D=fO&g^8GcZNBY\_e<gMM[WPH1[JL]BUZOV5F8#Va=JL]aUUNLG4F:ZTFa<.W]AY
-BFXKFP)SPg>1?G=U;:)<4cURN23:.,K<-N#9JO?B>.RJRXV+YN6Hg88UX9;[]N<
a<)_#gf_NC833-=F95NY0Pb8IX_Q+GR=RS_;@MgJ:@.UPS3_EK4e7<7/YRME=V9[
[e9#EM.\K@//85VA:O=Y>KUe82>/Y[QX&UA(VGIf.0ZV-4#;2Z:d[73-P@f6gBD@
JN4TO&;Y/)bW:6-4H>7@FbF5^&_VEMN,U(,E(&d7HX_35)25D;Z:cOI]>WCX6L9>
>cEbN]gGE3))R6OY1e4\SOD>C+5ZX/6:.eTA-Nb]f52cXCMW6HYS@4I76ceLWT1Q
f&@&2aTSc&95bER11g<<T>_]+:5R;&EVZBC2_U0>AbGTY#?@5JCBCc1@gIaXAOVR
2N[g4_05a5R)b&H^<Q/HYX.&T)9)Q..GG-EY4P>I9<VN]NS=E^M];:_6P8))K-g1
-#f-=,&\Ja0Z./II)Q]::]U19Z,I07e?;W1?DH2UO9WJ<IW8Mb,)(Ud:8/?g=D@3
AEH1g>XITYJ?]3fU&2Z+OQAT11FH[EN?Id,\WbUR6K[3Q^.XC=16#-RX/JeVXS?N
9gMHa+C,V;PI#M3g5^/;3RXWUS3=^>MgCZ1VWgJ[?AL)\Qbc(BUBYdYAMI4R4c,I
KG;M:.)=c-;\[_S(Z<0.&I)4A\E=c/:G@<)>=aM7MW:_e^b[K:@LC8UUL-9B4,Z?
OOM\dgPf(GZWeaG3-SO#J(:88fS.-33JbK=[OZg+K.;eH--/53^.,JBe]1([d?e8
POIOR.(>MK_F9HfN0agGAXC@@.D&d3eWABg]S9=_Bdg>+)NaJ2:S<Z6C:G,5Dfec
]DARNP+[>H4/ZggfZVcMa42VfU?)NdHF&.@7]_0<-[N5^T2+J^Y<)F_9@AV>5@bW
;b:^>IY6P+.CT8-X_aPdc#_HL/3<)7.@a10K(>F0W_JXXO38d_@9eFY^I8bI??aV
(3Re@N/\cN8K[1g8SRd19d:SML1])fY1ZV.cIZU#&TOV+4+[/].IeWLDFUY/MdcZ
O\XSH9dTV)AX093C7WA]4cSVI4bcTK@?<RCd3WNA<GB^4Of4P;H5,MS;X@1J6F<2
Va0X87)R/.>O[2ZbV#Mef]^g8ad@W2K,bH[7@M\(;eN^#/+;29QR6RBT190[IZWc
5/0fE&YL>_A_J6YSVXJ<9>f.\@O\W5IETU?CA[>9+RQe7[29\<+R,^3HUJVLNdQK
T^T:eL,.ZL4#V-\1HD5OKdL7(5VFI\\IO^309BV\S81A?3MTC2E?QCY8dP-/FQ_g
Df?4/@M)F2\TbG)Ff,e,g/D<C.G+_VE7Sf?^?[=J^N<87,.B(VVFM:a#C_<G@#OA
I@E5@8.A+W;Q:)4gI@0>C-;+HJ=VS:Uf#BI_A_R=>B[9HDU]#bb-G@WVgS&:4;b0
FDP0ANL2(&:N_)JfX?,\48W7B+e\2<aeLgbW3@XFS0a]Ja.94Id8HfS4IWICFB5b
VX>F(1+&S#@1[c(cT3eTP]Bf\]P/7Y,9(Z=7\T_P=2OCJC\4UO(DAg>E=>Ef>D@<
Te:(N>1Wc[dZ<aef=H2VRE5C_O7MV5#6NZgc1P[18)EH(MHH&@@?0P#>0I:;J)/P
[\K>3<HOOG6YWc?&[COb#PA-ZC586M^N&NXTgU-(\58[[c1-&0g2ge?9QVDED2NM
DTYJH7/:(P].bQ+FLVd_E1Ce89@.D[(Xc;>e\Z\7:,A_0/P^U8GW1=+VL_>@,?)&
F<#3d#TJVTYY.8-V09+Pc5Z0M4B-W/#UYRe(A,:7)M9L^\aRS&OcK^M&&ZP)GfXA
9ePIB_G5gNg+B=96dTU3LA4(,;0&eP1FY?d>c<J:V3\ee]@UF?IgXR;@gU)=?&c+
KRaG,QK9f/N^8W]]6BfQ#H_3LYcDe[;ceeDF5XF[4cDDTg1d-CaG\:eVSWg:I+QU
XE(gP4+PLc81NNcJ5P@)@,6AX+cD5[b+E2G5@24_E@c1)cdcL#8\4ISEQ;]GG2XX
37dUOg]IN1#Bc+T8YbNUJ>W[SP15+F5[g&WdL&075Q3_Vd=c[7)1K]3O8-(g<8a0
.-XX^>8Z@VK35Q3,1RI)/g(\R@Y3-FBaQ4<fSHd0S&bbFRUZM=<MC[E]:F]3_Z\-
>\QIGF@LNL-ZM93?&f](=TD_?=cYKb:MK(Dd5UX=BP52Z3MC?#DRMA&dAI^P6Vb<
@Z#&/R-e^L;]AU+4:H2(PY27;)SMJRA,9,[0TE>ZR8S?]&8KS1WR6WPV_2;bM<G9
7=X/-EU:@-)CP8@f8KWZH&HOD1>?b#95]AQ]H<cU&]S[(U?WC;UXHVBKGI0;P#DJ
Q^Ucf[2]>C._f.KVDT(,#V6PgZIg_1Z:Ob/LXU0e-S-ba?Db-CD3TEW;,>Z]3JVI
bK6dX=&Q0Y0MfJWggN=WRdfICd<=g&XSN49E;[&g7TgbXK89[=V2_UEW.]b#,aJ]
c;?>D\ZCe)cS=;dSHbXaDA3dAZ1S2;E@Y>R3P.a.;#N]T<(&]J]DWIU/>DfBMVX<
._,,6J:8TLeYd0,dX=TG5IB-,2Q>\.;J:E1[FR:8b.W\.AY-[=@W>(dV,_]_b+MM
^?7NSC>7d;=]/Pb-2RMeJOB<J;LU7eB(N^J8bAIT(O;#3C2662\ADYdKUG(17DA<
ObIWLYQ+g.@b9:]?5GMJQ8#1<eS[<a)@IJ1E@C2+T;HT6f8RZ6V+7H5&^MI<:SW@
#5V>9f.;#7B1PcJD(J2]+UO;E^(Q5:g4ICT(O88&GA/ON.?@4bKCA4KNXP78<4,1
fP[fCDFdL5gX7\+FM>+/&SVM-&P7TS>B12G]/B:O&WN@&G>^1+29#N#BbI5IPPG7
([]NU@.I?a[N8,YW6Q[H26TDARb&J(VGd6I;Xb8N(C8\,&N?79\^UFZ07D@H]BNb
&SeZC#(UI7<-SAbB#&XPE&_5d(YRS,4Y_I,JV+MER4PMPFfRHK&ZE(AME26JZ]CP
^bWO4BDF](;,7_DS@&E(Ye5+1D.-??<?2B<.VRSBTE&,61-N=LC=;Z]4E:I\AJQ>
g?Y06C>O89,b&fN7,@X3_0Of#QN02eKYYW7=N>U5Ub/7@>FVON[[Ccf)EH=[UJeD
WFVMDC<Q1e&ed0fGAXW;5cd51,YAbL9QBAU\/A.:Z9Za1&Q:aDT<6\&&7HYLDe[\
\^I.CL?/C-QMKeD\1M&fa4_0:gT9BP+>J)Q_N:fI8gE?d5dS#QPbJ)69J@Ue3J[W
),5MZZ/[H3.S[VO,f6g/N\Z:>ReCcKeDd)Z)SC^FP/XS.CI:&]O0)YB_05cK>?64
4=1J(cF>TX2Mf5UXeXM3.TH5[\Q]b6O#A#-139PL0;-XGa.A39LNAXA9fNHKL(HN
[S?V07C4+K6/_B1=K>HaC)f)]aaUG,Df>\2IEPY@8:JVCN;--f/4,d/agLRQ(_c-
#cNHXKf(A>I;5N;VX/b-5Y]HH-=:+[SFH\:7OYabM^<IWYAD#dT=ZG#JRf<c@16)
cR2DW34;^QW==P.-M[:&c;<<a]DCI0bG&(GAY#e_Fa\3=bG<JF56T&UH[T:fR<^S
VNZc+X;Ue+bdbOW/W/@0<E#/RKg4T(ES2V)a#7Aa?H<a<f?f8ZPCNKe&Y6;0)9,/
0SO:8QXf,>g4L7^.OP<7D\#O:W@XDXXA=(9<WN5-<K4T6:>cdX<M#\B2=D,=D?:<
YZ-.L<fRP:689HO4#8\JRXIVUc@fWC+7Jc@GG\IN4X+8LRPb)0fD8KB+ZGAO.+FR
ROM&5RQV3E6<;HL^WaS[P_VSFQcUP2#/&Ce\X;+b0JFK8\G[f?ZW>-c=FQF7dS,2
JbJ1(^<4\G\Td559ZS(3-Lb;63cQ;S/_7@@RcL./dVcN20:F]+P]@CEMOUc7,36?
N<g3,5OQB_=f>51T:GED:1M;GAQ988DR3N/DcAG5@I]:Y=8,QGZX70NE3:1_GCEH
F>:SRQN5&.2F+;EDR7a2I>a0H2?KS>NdY8V^4f)a@RJ0a>=d;aB.]E/;AU.b90=c
?+HA.&JgD8c8>d;,faZE0C1Tef17#26;J]7,XY^?L3E:CO9PDEJF^G,MGLOL8NSV
1]89.ecQ6U:RDD#eFbB/R4^)R77_aBKOFT-EZR\46:^WTNFCHH<.1JU2K3OG3;?[
CTTR:E+[5BTf.5aDaQ)DaG<&/WXUM[R];(ELE]c?(_JY0FcGAHd6JSZR>0#PCL?;
;KYg=Q]V]59XE>-JNd.3,;<@GNLC\dg:=7OTBbYY8W@=TD:,L5@7[aLSYXCf&&8C
EH/,(FD.6c^#VE>>MCXGXTB((UNL-;#Gd>\aQC&5]\?[DR.G@L_-7R6Y+LD4;_Gg
c3@^3,9W7>ECfO]c;014L=?IMD4D6CZ&6fg=OEAKgG9g\P9Tg[Q^AE7AXYCHCD5c
<(Z>LB>Hc-OG2^6SGM?H.]>KMV<4H5g0Kf8=9g4KHfG7[D1d99>PUZZbe#Dd50F0
O9M2[>2)POL#;6XH:VS7<SbE9ZbH]C3\e@0.+(a<W=B/Z]<Cf8VVG<E@B+<H6?Z.
-5D0e=Jc4L4ZVXNRVJUYDY@.K\FUM1U_H-f]QUIdXEHF\YI(5]^S[G;6;?S\fHZ]
>&376#c,RCgWWS108SKL0P)A/>9NUIQD+A\fW=1ZH/9NPE,SXbY;T=a;L;P]7:Td
A18TeK@=ZC.RYG]D7g8N3+@>D:HEa(.U>a\OA__OB=02.&[<bT)JJ1WI/;.2\V)@
>+(M1TL3731cZBL__7PEQdTSH:+:#Ke42_/V-L_O=XdBF\ZV:Q@A(?E]cC@c.J66
KR^5N/?JWY4EW+.)XS8ZMe(<Gc@AOMO+6+QP6WVH7:;2VE.Qc&4H=O_fMZS[5,&)
dLTBb?SR[d(YM>cBRIU,OSD4BKZgZM+>F)8g)1JGcc8WDKAQA6UaL[3eJPb^Va<.
CE=I?_RTFA>8XS;BYZ[cQHGU8cNISYeY60B1\eX_-S?eF/7MCcN.D=ZP+c3AF]E>
/7/>M8XIf]]]K9>0O\LTX9#C1/QWBRe/?TWdR.)eLU;_:afJd2X=\9.(/96Q(>EM
1K[67aQTdWd+V7PDYePV6XeI6Q6?>0)?D5FM+/9TL8:]&L92eMYT6FE_UaI>\N5V
cJ8A->f+c2+aU#<Z)-OAN0_I+bc/SD@S[X7S#UJ-dgBTK\:\6FCFV=eP,@6E4SV6
>;gG(/1=@Gc\=c]Y8-4??0;+TYg60D?4B)eQ5_&dM33.5^(UI9L\7I]D+B2g[]^-
K,]S><:M>T9aZUGA4DLHG?B:9c?>/:MKR]D]K.0MMHYN:Y<7RQ@#NR>9FYD+M[-V
1Q8N0^d>LLD]MA9@K4-Fg28]I#>&6@-=FKI(;_B-]@);-C+5JC[eWDb24F:-7LJW
_7&]PM[^7Q]67ANR&G9);AE,LQ77eQY]IC5JHfW?#e/.(fUO>T5G4GU/?^?g9CN6
d1(NFd1c?I9_DY[6=5>c@c0Z>bfQW<L[d@6+KAEX&+&^R7,][TLcN&O[D?4A-;]+
@d0ZWAS,\c+LMTF@2=P6,I6MYA[:TJfcY^5N7[24E9,IRA@:O+2#?E2F,BID396>
EK8R:)E[8\0?OPSZfAM<PV(&&W[689+f:[;W^dJCR<_G<.C>Ac-WMHfDIVAZg0=]
ef\0,J81&#a?TB9[F&TXXH;VG[,YcRXI\4C_SCZWc6&:))@212fF:?9E6+T?bK8D
dTX#3E[.8Aa/L?b(b<R,PJAV-&L__O4HdV:RU<&aM?,R8TS@T94>MX/1fYH[g#Wd
cJ6LZ5A)a9N_8JQEg#&)U#_UbP7P8c0)^7)QQTC3NJB>W5T-)O70X\E&3a17W3?P
/Q0&>=IF^B+ACaY9/@^I_.=61>e@,F8FTF^/2bb):_ggPg+,#dP4,L0Vg#R),67X
C;_^dND^fN&0aG[W;dGFcg5a&QC9Y8Q/TQWgASLfe3_[6gHBWD[RCa@G0)JIBCV0
]IP)4JN,B4,Q+F<B?Ja@IINa+HQ_R.Z4\^AZ)R2X@=b]+0,DW+e:JV?CCF#FWM+6
-g)Bf(XUEL0E(UU,(B]GB:RNT+\O.bW.?\+L5E8XB8,UD_&BN8TR0]65JE2;VX7X
8^VDXTg87MJTR//>D_L^A&e7&4E9]OQE[eSP>J##3CQN(8XbJX6?08MQ7YD9e[2M
bbB8==DBYLD&B)SY02019NB^@4RY2-PP3L>,U5\G<4R&3.0fRe#>bULL(B)2:;[V
\2H.?WI6DC1Fg-7:WR)&&M>3ZfC+CED9Ua@^9EDW:?^1\_+5@d_gH_2H62fF,[0Q
QC-Q#YDV3V>)+^PSJSJ<56=CWL<Dc-WTMeKFZIb]?JC,#PF)T^cSP[J_LCgM_GFK
#E>07+M,4X&6[WR.X(V+D3e&TdK&J\YEE-)M+gVXY9]6/#1/0\]5]@_Y7&U(c<\B
Jf-=^S1@)c6=g5KF>cZ=<<]/-\/&Y[@IdUdD52:]b#5WC5O\4MNRGgOKf(6BJEcg
4(2^+CCKe[J-+d=e/[A=7+SF/YdbSNZE78#_>\K6:Q(6CMU)(:MVWLX6\>PDWf-d
SAFX;XFES<1+aS^=JW#g56c>95K.Oe\-FYFFBR3E1bNB#.9<#)4d@Q9ZTSD]^R(\
&1A@8G(T<\#dC(ENQL;YNCRgDDHPI>BF0Y(]=DICIZT]-Q1-gfCE,JC09cC_7U3/
&S5Za][:GeC6E._E,bK7eJAG;)<@]GJ]86?EQ)R(>[5DLIbW,O4bB2FW>BM9#5PF
)HR@[AH0M2XIL1PZE]dY7eGC[WN2[J;,J0.d;c=?aSI.fL6PX.)1YQ+KKL:PMLQ#
fcASVE,eQ2b23R(D_]B1&+XaR=C=Y<@A4PN5Bb)[[P:[__ATDZCbe;2]BCRg^9;,
;.QQ=NM&SX(9.58J])eMC>(-SHPUIFHE:R\C[KZD3V-9gO@LLD(,\#>ML)Q?M_g]
RN.KEBL5A1c.:[F+Ud4R6K@Z.TZRTgG^;eILe1WQDR5=Ef=H=EO)KNgCC,8G/2]@
,O4N/\?L2F4)ac@7N#d9I,f^+R+ag]2e@ZT3UVR:(IRBU.7BU]/LX/7G8a&#Q;&B
-a_=f51G67e/.;U9UBg=W;&V8YNF]K2KX2E<ObOO?@1A7^dGS7.F<DY1R]5_-7c)
=^[KfCFb.TAT>&YB(DT:L,RU08VO\,4XF=+I_.#4.1MAWYHWaXXfcN#IL_NY84FJ
>0Df(9;T^CbG^0-.\,FD]g3V)><^1M@E9P+8f=2gR/Q.WSCY+GgB70@b:15M.H,,
+Mc;@Z5]Se&[L6;HOS,59Wc4TXf57];H,Z7d]#LaGeD.UN,.>0T=/BPgWHMZa2Vf
1^APAe_;8dD>8Mb3JCMN[5NH+.+:0Ha_.UA6d#?2bM,<=&IL]^4&ZCS5M\N-P=MK
M=<f3\?M7f0R&U#dD&\<-TO+/5M]-[_G81176<94[Y/ORG?@3&0;/G]bf2L5PKE:
++LJ\Y8bB.d+LfI1aK/Z=NE\EbI(:f-O6P8H<6/?Nb69K_b(VAT)e.YTZb^[A.eO
HWJ_ACa[B>VcPHP\^8>J,^gSV=I9<_TJ5RLJR1@]+F,6O3>_#_20BCaX<A=P<(7+
XcdZ<,<-O_DC,?IYP[[78/aJ/Q;S_]DBZN4QF1R2gVU&3f2_?(E#_1HN\I55Gf@K
f,HM9fT8]bLBFHcLU.5)VER^H[PVX,/48,H=W6R4Sf8QLWb^cDYW(&,;.:IfUO>N
<a05RLW?,KIBJ\d-/GF23GbeMJJ^cHA^,aPTYQ,9E\W=2cb1H-Qf1;.T/e:3N,VF
c2#OA,,OYF,7N\Ad([+ZYF]:Ya-fXe;XXXQ49[OBa>.W79d-HWU@/<8UYVYWRK);
<Q/Gf1+OV(O]ZQS2_T\a[G_-+,VdDVHLfId8CZUaHRW(X\?#SW4QP8Y4<VN4F8,d
BFb06dJc8U(]-g3_QJOQ)/-1JGGB=+EdP6ePD?,S.OMF?>O6H-Ca?)-V_We45\I]
)S-S^F+B4P2:g#c>ZG\/0X.B],GT2RC?)9ADE?2.AQe>cafWGB7FKM3P.8O(@E^T
8C)2QKBM3c[08]YATTH5<SbRAI-B7YAb^9[0[TN_S:Dd=[7@]-cH7_a@#e<LeCK0
Z?H@KCX2_.a4O2Ld<:7K8Y6UT\G6_RKRc?e:HZ,YWAUTMA20WH_0Y)LI@:+N\_+0
8a3\EPB,><8<?7YTZRG3?T[[)R>R6K2NXKeTF3\A)+VNTU(3#SPBG?5S@_cASK+L
I;2NCVF3>g]6I1LY;/fb30AFbP#-S8(aIBT\GV=&D[H._C8N<c(T6B;)WCWVL12?
@CO>]-O)EdAOF462YH1H9;Q;gdcWAO.d&LN10-&8;/UG)Q@a[C.,fGAN,R8A\<\G
Fa>Qf,0ZJI334#<WE/IR[;+T)>#.?]/We3KIeIE,[/V8@SAL_;::Yb+<\VO<2:MA
(DWK\#E2(T:8_e_&/,I:b/P3_-f1)#XI)D?f6+VBWUX8H$
`endprotected
