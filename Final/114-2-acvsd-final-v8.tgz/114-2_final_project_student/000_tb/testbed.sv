`timescale 1ns/1ps
import axi_pkg::*;

`define CLK_DATA_BUS_PERIOD 5.0    // 200 MHz
`define CLK_CTRL_BUS_PERIOD 20.0   // ~50 MHz
`define CLK_PE_PERIOD       2.0    // 500 MHz

`define MAX_STIM_TIME       150_000_000 // 150 milliseconds

module testbed;

    logic clk_data_bus;
    logic clk_ctrl_bus;
    logic clk_pe;
    logic rst_n;

    // =========================================================================
    // Clocks and Reset
    // =========================================================================
    // All clocks are held LOW while rst_n=0. 
    initial begin
        rst_n        = 0;
        clk_data_bus = 0;
        clk_ctrl_bus = 0;
        clk_pe       = 0;
        #1000;
        rst_n = 1;
        #1000;   
        // hold clocks low 1000 ns AFTER reset deasserts — let all FFs settle
        fork
            forever #(`CLK_DATA_BUS_PERIOD / 2.0) clk_data_bus = ~clk_data_bus;
            forever #(`CLK_CTRL_BUS_PERIOD / 2.0) clk_ctrl_bus = ~clk_ctrl_bus;
            forever #(`CLK_PE_PERIOD       / 2.0) clk_pe       = ~clk_pe;
        join_none
    end

    // =========================================================================
    // AXI4-Lite Flat Signals
    // =========================================================================
    logic [`AXIL_ADDRW-1:0]  axil_awaddr;
    logic                    axil_awvalid;
    logic                    axil_awready;
    logic [`AXIL_DATAW-1:0]  axil_wdata;
    logic                    axil_wvalid;
    logic                    axil_wready;
    logic [`AXIL_RESPW-1:0]  axil_bresp;
    logic                    axil_bvalid;
    logic                    axil_bready;
    logic [`AXIL_ADDRW-1:0]  axil_araddr;
    logic                    axil_arvalid;
    logic                    axil_arready;
    logic [`AXIL_DATAW-1:0]  axil_rdata;
    logic [`AXIL_RESPW-1:0]  axil_rresp;
    logic                    axil_rvalid;
    logic                    axil_rready;

    // =========================================================================
    // pseudo microcontroller
    // =========================================================================
    mcu #(
        .INPUT_DELAY (`CLK_CTRL_BUS_PERIOD / 2.0),
        .OUTPUT_DELAY(`CLK_CTRL_BUS_PERIOD / 2.0)
    ) u_mcu (
        .clk_ctrl_bus  (clk_ctrl_bus),
        .rst_n         (rst_n),
        .axil_awaddr   (axil_awaddr),
        .axil_awvalid  (axil_awvalid),
        .axil_awready  (axil_awready),
        .axil_wdata    (axil_wdata),
        .axil_wvalid   (axil_wvalid),
        .axil_wready   (axil_wready),
        .axil_bresp    (axil_bresp),
        .axil_bvalid   (axil_bvalid),
        .axil_bready   (axil_bready),
        .axil_araddr   (axil_araddr),
        .axil_arvalid  (axil_arvalid),
        .axil_arready  (axil_arready),
        .axil_rdata    (axil_rdata),
        .axil_rresp    (axil_rresp),
        .axil_rvalid   (axil_rvalid),
        .axil_rready   (axil_rready)
    );

    // =========================================================================
    // AXI4-Full Interfaces for Behavioral DRAMs
    // =========================================================================
    axi4_full_if dram_if[3:0]();

    // =========================================================================
    // DUT
    // =========================================================================
    // -----------------------------------------------------------------------
    // DUT: top.sv (RTL) / top_syn.v (GATE) / top_apr.v (POST)
    // GATE/POST additionally require DFT scan ports from the synthesized netlist.
    // -----------------------------------------------------------------------
    top u_top (
        .clk_data_bus        (clk_data_bus),
        .clk_ctrl_bus        (clk_ctrl_bus),
        .clk_pe              (clk_pe),
        .rst_n               (rst_n),

        // s_axil — AXI4-Lite slave
        .s_axil_awaddr       (axil_awaddr),
        .s_axil_awvalid      (axil_awvalid),
        .s_axil_awready      (axil_awready),
        .s_axil_wdata        (axil_wdata),
        .s_axil_wvalid       (axil_wvalid),
        .s_axil_wready       (axil_wready),
        .s_axil_bresp        (axil_bresp),
        .s_axil_bvalid       (axil_bvalid),
        .s_axil_bready       (axil_bready),
        .s_axil_araddr       (axil_araddr),
        .s_axil_arvalid      (axil_arvalid),
        .s_axil_arready      (axil_arready),
        .s_axil_rdata        (axil_rdata),
        .s_axil_rresp        (axil_rresp),
        .s_axil_rvalid       (axil_rvalid),
        .s_axil_rready       (axil_rready),

        // m_dram_0 — Bank A
        .m_dram_0_awid       (dram_if[0].awid),
        .m_dram_0_awaddr     (dram_if[0].awaddr),
        .m_dram_0_awlen      (dram_if[0].awlen),
        .m_dram_0_awsize     (dram_if[0].awsize),
        .m_dram_0_awburst    (dram_if[0].awburst),
        .m_dram_0_awvalid    (dram_if[0].awvalid),
        .m_dram_0_awready    (dram_if[0].awready),
        .m_dram_0_wdata      (dram_if[0].wdata),
        .m_dram_0_wstrb      (dram_if[0].wstrb),
        .m_dram_0_wlast      (dram_if[0].wlast),
        .m_dram_0_wvalid     (dram_if[0].wvalid),
        .m_dram_0_wready     (dram_if[0].wready),
        .m_dram_0_bid        (dram_if[0].bid),
        .m_dram_0_bresp      (dram_if[0].bresp),
        .m_dram_0_bvalid     (dram_if[0].bvalid),
        .m_dram_0_bready     (dram_if[0].bready),
        .m_dram_0_arid       (dram_if[0].arid),
        .m_dram_0_araddr     (dram_if[0].araddr),
        .m_dram_0_arlen      (dram_if[0].arlen),
        .m_dram_0_arsize     (dram_if[0].arsize),
        .m_dram_0_arburst    (dram_if[0].arburst),
        .m_dram_0_arvalid    (dram_if[0].arvalid),
        .m_dram_0_arready    (dram_if[0].arready),
        .m_dram_0_rid        (dram_if[0].rid),
        .m_dram_0_rdata      (dram_if[0].rdata),
        .m_dram_0_rresp      (dram_if[0].rresp),
        .m_dram_0_rlast      (dram_if[0].rlast),
        .m_dram_0_rvalid     (dram_if[0].rvalid),
        .m_dram_0_rready     (dram_if[0].rready),

        // m_dram_1 — Bank B
        .m_dram_1_awid       (dram_if[1].awid),
        .m_dram_1_awaddr     (dram_if[1].awaddr),
        .m_dram_1_awlen      (dram_if[1].awlen),
        .m_dram_1_awsize     (dram_if[1].awsize),
        .m_dram_1_awburst    (dram_if[1].awburst),
        .m_dram_1_awvalid    (dram_if[1].awvalid),
        .m_dram_1_awready    (dram_if[1].awready),
        .m_dram_1_wdata      (dram_if[1].wdata),
        .m_dram_1_wstrb      (dram_if[1].wstrb),
        .m_dram_1_wlast      (dram_if[1].wlast),
        .m_dram_1_wvalid     (dram_if[1].wvalid),
        .m_dram_1_wready     (dram_if[1].wready),
        .m_dram_1_bid        (dram_if[1].bid),
        .m_dram_1_bresp      (dram_if[1].bresp),
        .m_dram_1_bvalid     (dram_if[1].bvalid),
        .m_dram_1_bready     (dram_if[1].bready),
        .m_dram_1_arid       (dram_if[1].arid),
        .m_dram_1_araddr     (dram_if[1].araddr),
        .m_dram_1_arlen      (dram_if[1].arlen),
        .m_dram_1_arsize     (dram_if[1].arsize),
        .m_dram_1_arburst    (dram_if[1].arburst),
        .m_dram_1_arvalid    (dram_if[1].arvalid),
        .m_dram_1_arready    (dram_if[1].arready),
        .m_dram_1_rid        (dram_if[1].rid),
        .m_dram_1_rdata      (dram_if[1].rdata),
        .m_dram_1_rresp      (dram_if[1].rresp),
        .m_dram_1_rlast      (dram_if[1].rlast),
        .m_dram_1_rvalid     (dram_if[1].rvalid),
        .m_dram_1_rready     (dram_if[1].rready),

        // m_dram_2 — Bank C
        .m_dram_2_awid       (dram_if[2].awid),
        .m_dram_2_awaddr     (dram_if[2].awaddr),
        .m_dram_2_awlen      (dram_if[2].awlen),
        .m_dram_2_awsize     (dram_if[2].awsize),
        .m_dram_2_awburst    (dram_if[2].awburst),
        .m_dram_2_awvalid    (dram_if[2].awvalid),
        .m_dram_2_awready    (dram_if[2].awready),
        .m_dram_2_wdata      (dram_if[2].wdata),
        .m_dram_2_wstrb      (dram_if[2].wstrb),
        .m_dram_2_wlast      (dram_if[2].wlast),
        .m_dram_2_wvalid     (dram_if[2].wvalid),
        .m_dram_2_wready     (dram_if[2].wready),
        .m_dram_2_bid        (dram_if[2].bid),
        .m_dram_2_bresp      (dram_if[2].bresp),
        .m_dram_2_bvalid     (dram_if[2].bvalid),
        .m_dram_2_bready     (dram_if[2].bready),
        .m_dram_2_arid       (dram_if[2].arid),
        .m_dram_2_araddr     (dram_if[2].araddr),
        .m_dram_2_arlen      (dram_if[2].arlen),
        .m_dram_2_arsize     (dram_if[2].arsize),
        .m_dram_2_arburst    (dram_if[2].arburst),
        .m_dram_2_arvalid    (dram_if[2].arvalid),
        .m_dram_2_arready    (dram_if[2].arready),
        .m_dram_2_rid        (dram_if[2].rid),
        .m_dram_2_rdata      (dram_if[2].rdata),
        .m_dram_2_rresp      (dram_if[2].rresp),
        .m_dram_2_rlast      (dram_if[2].rlast),
        .m_dram_2_rvalid     (dram_if[2].rvalid),
        .m_dram_2_rready     (dram_if[2].rready),

        // m_dram_3 — Bank D
        .m_dram_3_awid       (dram_if[3].awid),
        .m_dram_3_awaddr     (dram_if[3].awaddr),
        .m_dram_3_awlen      (dram_if[3].awlen),
        .m_dram_3_awsize     (dram_if[3].awsize),
        .m_dram_3_awburst    (dram_if[3].awburst),
        .m_dram_3_awvalid    (dram_if[3].awvalid),
        .m_dram_3_awready    (dram_if[3].awready),
        .m_dram_3_wdata      (dram_if[3].wdata),
        .m_dram_3_wstrb      (dram_if[3].wstrb),
        .m_dram_3_wlast      (dram_if[3].wlast),
        .m_dram_3_wvalid     (dram_if[3].wvalid),
        .m_dram_3_wready     (dram_if[3].wready),
        .m_dram_3_bid        (dram_if[3].bid),
        .m_dram_3_bresp      (dram_if[3].bresp),
        .m_dram_3_bvalid     (dram_if[3].bvalid),
        .m_dram_3_bready     (dram_if[3].bready),
        .m_dram_3_arid       (dram_if[3].arid),
        .m_dram_3_araddr     (dram_if[3].araddr),
        .m_dram_3_arlen      (dram_if[3].arlen),
        .m_dram_3_arsize     (dram_if[3].arsize),
        .m_dram_3_arburst    (dram_if[3].arburst),
        .m_dram_3_arvalid    (dram_if[3].arvalid),
        .m_dram_3_arready    (dram_if[3].arready),
        .m_dram_3_rid        (dram_if[3].rid),
        .m_dram_3_rdata      (dram_if[3].rdata),
        .m_dram_3_rresp      (dram_if[3].rresp),
        .m_dram_3_rlast      (dram_if[3].rlast),
        .m_dram_3_rvalid     (dram_if[3].rvalid),
        .m_dram_3_rready     (dram_if[3].rready)
`ifndef RTL
        ,
        .SE                  (1'b0),
        .SI0                 (1'b0),
        .SI1                 (1'b0),
        .SI2                 (1'b0),
        .SO0                 (),
        .SO1                 (),
        .SO2                 ()
`endif
    );

    // =========================================================================
    // SDF Back-Annotation (only when GATE_SDF / POST_SDF explicitly defined)
    // =========================================================================
`ifdef GATE_SDF
    initial $sdf_annotate("../040_syn_top/netlist/top_syn.sdf", u_top);
    initial $sdf_annotate("../041_syn_pe/netlist/pe_syn.sdf", u_top.u_pe_0_1);
    initial $sdf_annotate("../041_syn_pe/netlist/pe_syn.sdf", u_top.u_pe_0_2);
    initial $sdf_annotate("../041_syn_pe/netlist/pe_syn.sdf", u_top.u_pe_0_3);
    initial $sdf_annotate("../041_syn_pe/netlist/pe_syn.sdf", u_top.u_pe_1_1);
    initial $sdf_annotate("../041_syn_pe/netlist/pe_syn.sdf", u_top.u_pe_1_2);
    initial $sdf_annotate("../041_syn_pe/netlist/pe_syn.sdf", u_top.u_pe_1_3);
`elsif POST_SDF
    initial $sdf_annotate("../070_apr_top/output/top_apr.sdf", u_top);
    initial $sdf_annotate("../071_apr_pe/output/pe_apr.sdf", u_top.u_pe_0_1);
    initial $sdf_annotate("../071_apr_pe/output/pe_apr.sdf", u_top.u_pe_0_2);
    initial $sdf_annotate("../071_apr_pe/output/pe_apr.sdf", u_top.u_pe_0_3);
    initial $sdf_annotate("../071_apr_pe/output/pe_apr.sdf", u_top.u_pe_1_1);
    initial $sdf_annotate("../071_apr_pe/output/pe_apr.sdf", u_top.u_pe_1_2);
    initial $sdf_annotate("../071_apr_pe/output/pe_apr.sdf", u_top.u_pe_1_3);
`endif

    // =========================================================================
    // 4x Behavioral DRAMs (same for all modes)
    // =========================================================================
    genvar i;
    generate
        for (i = 0; i < 4; i++) begin : dram_gen
            dram #(
                .INPUT_DELAY (`CLK_DATA_BUS_PERIOD / 2.0),
                .OUTPUT_DELAY(`CLK_DATA_BUS_PERIOD / 2.0)
            ) u_dram (
                .clk_data_bus (clk_data_bus),
                .rst_n        (rst_n),
                .s_axi        (dram_if[i])
            );
        end
    endgenerate

    // =========================================================================
    // Timeout
    // =========================================================================
    initial begin
        #`MAX_STIM_TIME;
        $display("[testbed] Timeout reached.");
        $finish;
    end

    // =========================================================================
    // FSDB Waveform Dump
    // =========================================================================
`ifdef FSDB
    initial begin : fsdb_dump
        $display("[testbed] %0t: FSDB dump -> top.fsdb", $time);
        $fsdbDumpfile("top.fsdb");
        $fsdbDumpvars(0, testbed);
        $fsdbDumpMDA();
    end
`endif

    // =========================================================================
    // SAIF Toggle Monitoring (gate-level / post-layout only)
    // =========================================================================
`ifdef RTL
    // RTL sim: monitor all regs; nets only if they are ports
    initial $set_gate_level_monitoring("rtl_on");
`else
    // Gate / post sim: monitor nets (default gate-level policy)
    initial $set_gate_level_monitoring("on");
`endif
    initial begin
        $set_toggle_region(testbed.u_top);
        @(posedge clk_ctrl_bus);
        $toggle_start();
    end

    final begin
        $toggle_stop();
        $toggle_report("sim.saif", 1.0e-9, "testbed.u_top");
    end

endmodule
