module RST_Sync (
    input   logic   i_clk,
    input   logic   i_async_rst_n,
    output  logic   o_sync_rst_n,

    input   logic   test_mode
);

    logic   rst_n_sync_1_r, rst_n_sync_2_r;

    assign  o_sync_rst_n = (test_mode) ? i_async_rst_n : rst_n_sync_2_r;

    always_ff @( posedge i_clk or negedge i_async_rst_n ) begin
        if (!i_async_rst_n) begin
            rst_n_sync_1_r <= 1'b0;
            rst_n_sync_2_r <= 1'b0;
        end else begin
            rst_n_sync_1_r <= 1'b1;
            rst_n_sync_2_r <= rst_n_sync_1_r;
        end
    end

endmodule