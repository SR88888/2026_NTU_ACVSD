module Interconnect #(
    parameter   DATA_WIDTH = 16
) (
    input   logic   i_clk,
    input   logic   i_rst_n,
    // tb
    input   logic   [  13:0] tb_HADDR,
    input   logic            tb_HWRITE,
    input   logic   [   2:0] tb_HSIZE,
    input   logic   [   2:0] tb_HBURST,
    input   logic   [   1:0] tb_HTRANS,
    input   logic   [1023:0] tb_HWDATA,
    output  logic            tb_HREADY,
    output  logic            tb_HRESP,
    output  logic   [1023:0] tb_HRDATA,
    // SIMD
    input   logic            SIMD_data_EN,
    input   logic   [  13:0] SIMD_data_HADDR,
    input   logic            SIMD_data_HWRITE,
    input   logic   [   2:0] SIMD_data_HSIZE,
    input   logic   [   2:0] SIMD_data_HBURST,
    input   logic   [   1:0] SIMD_data_HTRANS,
    input   logic   [ 255:0] SIMD_data_HWDATA,
    output  logic            SIMD_data_HREADY,
    output  logic            SIMD_data_HRESP,
    output  logic   [ 255:0] SIMD_data_HRDATA,
    output  logic   [  13:0] SIMD_cfg_HADDR,
    output  logic            SIMD_cfg_HWRITE,
    output  logic   [   2:0] SIMD_cfg_HSIZE,
    output  logic   [   2:0] SIMD_cfg_HBURST,
    output  logic   [   1:0] SIMD_cfg_HTRANS,
    output  logic   [  15:0] SIMD_cfg_HWDATA,
    input   logic            SIMD_cfg_HREADY,
    input   logic            SIMD_cfg_HRESP,
    input   logic   [  15:0] SIMD_cfg_HRDATA,
    // GEMM
    input   logic            GEMM_data_EN,
    input   logic   [  13:0] GEMM_data_HADDR,
    input   logic            GEMM_data_HWRITE,
    input   logic   [   2:0] GEMM_data_HSIZE,
    input   logic   [   2:0] GEMM_data_HBURST,
    input   logic   [   1:0] GEMM_data_HTRANS,
    input   logic   [ 511:0] GEMM_data_HWDATA,
    output  logic            GEMM_data_HREADY,
    output  logic            GEMM_data_HRESP,
    output  logic   [ 511:0] GEMM_data_HRDATA,
    output  logic   [  13:0] GEMM_cfg_HADDR,
    output  logic            GEMM_cfg_HWRITE,
    output  logic   [   2:0] GEMM_cfg_HSIZE,
    output  logic   [   2:0] GEMM_cfg_HBURST,
    output  logic   [   1:0] GEMM_cfg_HTRANS,
    output  logic   [  15:0] GEMM_cfg_HWDATA,
    input   logic            GEMM_cfg_HREADY,
    input   logic            GEMM_cfg_HRESP,
    input   logic   [  15:0] GEMM_cfg_HRDATA,
    // Shared Memory
    output  logic   [  13:0] MEM_data_HADDR,
    output  logic            MEM_data_HWRITE,
    output  logic   [   2:0] MEM_data_HSIZE,
    output  logic   [   2:0] MEM_data_HBURST,
    output  logic   [   1:0] MEM_data_HTRANS,
    output  logic   [1023:0] MEM_data_HWDATA,
    input   logic            MEM_data_HREADY,
    input   logic            MEM_data_HRESP,
    input   logic   [1023:0] MEM_data_HRDATA,
    output  logic   [  13:0] MEM_cfg_HADDR,
    output  logic            MEM_cfg_HWRITE,
    output  logic   [   2:0] MEM_cfg_HSIZE,
    output  logic   [   2:0] MEM_cfg_HBURST,
    output  logic   [   1:0] MEM_cfg_HTRANS,
    output  logic   [  15:0] MEM_cfg_HWDATA,
    input   logic            MEM_cfg_HREADY,
    input   logic            MEM_cfg_HRESP,
    input   logic   [  15:0] MEM_cfg_HRDATA
);

    localparam NORMAL = 1'b0;
    localparam ERROR  = 1'b1;

    logic       state_r, state_w;
    logic [1:0] config_sel;
    logic       error_en;
    logic       error_HREADY, error_HRESP;

    assign config_sel = tb_HADDR[11:10];

    always @(*) begin
        case(state_r)
            NORMAL: state_w = error_en ? ERROR : NORMAL;
            ERROR:  state_w = error_HREADY ? NORMAL : ERROR;
        endcase
    end

    always @(*) begin
        tb_HREADY = 1;
        tb_HRESP = 0;
        tb_HRDATA = 0;
        SIMD_data_HREADY = 0;
        SIMD_data_HRESP = 0;
        SIMD_data_HRDATA = 0;
        SIMD_cfg_HADDR = 0;
        SIMD_cfg_HWRITE = 0;
        SIMD_cfg_HSIZE = 0;
        SIMD_cfg_HBURST = 0;
        SIMD_cfg_HTRANS = 0;
        SIMD_cfg_HWDATA = 0;
        GEMM_data_HREADY = 0;
        GEMM_data_HRESP = 0;
        GEMM_data_HRDATA = 0;
        GEMM_cfg_HADDR = 0;
        GEMM_cfg_HWRITE = 0;
        GEMM_cfg_HSIZE = 0;
        GEMM_cfg_HBURST = 0;
        GEMM_cfg_HTRANS = 0;
        GEMM_cfg_HWDATA = 0;
        MEM_data_HADDR = 0;
        MEM_data_HWRITE = 0;
        MEM_data_HSIZE = 0;
        MEM_data_HBURST = 0;
        MEM_data_HTRANS = 0;
        MEM_data_HWDATA = 0;
        MEM_cfg_HADDR = 0;
        MEM_cfg_HWRITE = 0;
        MEM_cfg_HSIZE = 0;
        MEM_cfg_HBURST = 0;
        MEM_cfg_HTRANS = 0;
        MEM_cfg_HWDATA = 0;
        error_en = 0;

        if (state_r == ERROR) begin
            tb_HREADY = error_HREADY;
            tb_HRESP = error_HRESP;
        end
        else begin     

            if (tb_HTRANS[1]) begin
                if (tb_HADDR[13]) begin
                    error_en = tb_HADDR[12] || &tb_HADDR[11:10];
                end
                else begin
                    error_en = &tb_HADDR[12:11] && MEM_data_HREADY;
                end
            end

            if (SIMD_data_EN) begin
                // SIMD -> MEM
                MEM_data_HADDR   = SIMD_data_HADDR;
                MEM_data_HWRITE  = SIMD_data_HWRITE;
                MEM_data_HSIZE   = SIMD_data_HSIZE;
                MEM_data_HBURST  = SIMD_data_HBURST;
                MEM_data_HTRANS  = SIMD_data_HTRANS;
                MEM_data_HWDATA  = SIMD_data_HWDATA;
                // SIMD <- MEM
                SIMD_data_HREADY = MEM_data_HREADY;
                SIMD_data_HRESP  = MEM_data_HRESP;
                SIMD_data_HRDATA = MEM_data_HRDATA[255:0];
            end
            if (GEMM_data_EN) begin
                // GEMM -> MEM
                MEM_data_HADDR   = GEMM_data_HADDR;
                MEM_data_HWRITE  = GEMM_data_HWRITE;
                MEM_data_HSIZE   = GEMM_data_HSIZE;
                MEM_data_HBURST  = GEMM_data_HBURST;
                MEM_data_HTRANS  = GEMM_data_HTRANS;
                MEM_data_HWDATA  = GEMM_data_HWDATA;
                // GEMM <- MEM
                GEMM_data_HREADY = MEM_data_HREADY;
                GEMM_data_HRESP  = MEM_data_HRESP;
                GEMM_data_HRDATA = MEM_data_HRDATA[511:0];
            end

            if (tb_HADDR[13]) begin
                case (config_sel)
                    2'b00: begin
                        // tb -> SIMD_cfg
                        SIMD_cfg_HADDR  = tb_HADDR;
                        SIMD_cfg_HWRITE = tb_HWRITE;
                        SIMD_cfg_HSIZE  = tb_HSIZE;
                        SIMD_cfg_HBURST = tb_HBURST;
                        SIMD_cfg_HTRANS = tb_HTRANS;
                        SIMD_cfg_HWDATA = tb_HWDATA[15:0];
                        // tb <- SIMD_cfg
                        tb_HREADY       = SIMD_cfg_HREADY;
                        tb_HRESP        = SIMD_cfg_HRESP;
                        tb_HRDATA       = SIMD_cfg_HRDATA;
                    end
                    2'b01: begin
                        // tb -> GEMM_cfg
                        GEMM_cfg_HADDR  = tb_HADDR;
                        GEMM_cfg_HWRITE = tb_HWRITE;
                        GEMM_cfg_HSIZE  = tb_HSIZE;
                        GEMM_cfg_HBURST = tb_HBURST;
                        GEMM_cfg_HTRANS = tb_HTRANS;
                        GEMM_cfg_HWDATA = tb_HWDATA[15:0];
                        // tb <- GEMM_cfg
                        tb_HREADY       = GEMM_cfg_HREADY;
                        tb_HRESP        = GEMM_cfg_HRESP;
                        tb_HRDATA       = GEMM_cfg_HRDATA;
                        end
                    2'b10: begin
                        // tb -> MEM_cfg
                        MEM_cfg_HADDR   = tb_HADDR;
                        MEM_cfg_HWRITE  = tb_HWRITE;
                        MEM_cfg_HSIZE   = tb_HSIZE;
                        MEM_cfg_HBURST  = tb_HBURST;
                        MEM_cfg_HTRANS  = tb_HTRANS;
                        MEM_cfg_HWDATA  = tb_HWDATA[15:0];
                        // tb <- MEM_cfg
                        tb_HREADY       = MEM_cfg_HREADY;
                        tb_HRESP        = MEM_cfg_HRESP;
                        tb_HRDATA       = MEM_cfg_HRDATA;
                    end
                endcase
            end
            else if (~|{SIMD_data_EN, GEMM_data_EN})begin
                MEM_data_HADDR   = tb_HADDR;
                MEM_data_HWRITE  = tb_HWRITE;
                MEM_data_HSIZE   = tb_HSIZE;
                MEM_data_HBURST  = tb_HBURST;
                MEM_data_HTRANS  = tb_HTRANS;
                MEM_data_HWDATA  = tb_HWDATA;
                // tb <- MEM_data
                tb_HREADY        = MEM_data_HREADY;
                tb_HRESP         = MEM_data_HRESP;
                tb_HRDATA        = MEM_data_HRDATA;
            end
        end
    end

    error_response u_error_response (
        .i_clk      (i_clk),
        .i_rst_n    (i_rst_n),
        .i_en       (error_en),
        .o_HREADY   (error_HREADY),
        .o_HRESP    (error_HRESP)
    );

    always @(posedge i_clk) begin
        if (!i_rst_n) state_r <= NORMAL;
        else          state_r <= state_w;
    end
        
endmodule

module error_response (
    input   logic   i_clk,
    input   logic   i_rst_n,
    input   logic   i_en,
    output  logic   o_HREADY,
    output  logic   o_HRESP
);

    localparam IDLE = 1'b0;
    localparam RESP = 1'b1;

    logic       state_r, state_w;
    logic       hready_r, hready_w;

    assign o_HREADY = hready_r;
    assign o_HRESP  = (state_r == RESP);

    always @(*) begin
        case(state_r)
            IDLE: state_w = i_en ? RESP : IDLE;
            RESP: state_w = hready_r ? IDLE : RESP;
        endcase
        hready_w = i_en ? 1'b0 : 1'b1;
    end

    always @(posedge i_clk) begin
        if (!i_rst_n) begin
            state_r <= IDLE;
            hready_r <= 1'b1;
        end
        else begin
            state_r <= state_w;
            hready_r <= hready_w;
        end
    end

endmodule
