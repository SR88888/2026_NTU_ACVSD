module Shared_Memory #(
    parameter   DATA_WIDTH = 16
) (
    input   logic   i_clk,
    input   logic   i_rst_n,
    output  logic   irq,
    // Interconnect
    input   logic   [  13:0] MEM_data_HADDR,
    input   logic            MEM_data_HWRITE,
    input   logic   [   2:0] MEM_data_HSIZE,
    input   logic   [   2:0] MEM_data_HBURST,
    input   logic   [   1:0] MEM_data_HTRANS,
    input   logic   [1023:0] MEM_data_HWDATA,
    output  logic            MEM_data_HREADY,
    output  logic            MEM_data_HRESP,
    output  logic   [1023:0] MEM_data_HRDATA,
    input   logic   [  13:0] MEM_cfg_HADDR,
    input   logic            MEM_cfg_HWRITE,
    input   logic   [   2:0] MEM_cfg_HSIZE,  // IGNORE
    input   logic   [   2:0] MEM_cfg_HBURST, // IGNORE
    input   logic   [   1:0] MEM_cfg_HTRANS,
    input   logic   [  15:0] MEM_cfg_HWDATA,
    output  logic            MEM_cfg_HREADY,
    output  logic            MEM_cfg_HRESP,
    output  logic   [  15:0] MEM_cfg_HRDATA
);

    localparam REGULAR   = 3'd0;
    localparam WAIT      = 3'd1;
    localparam CFG       = 3'd2;
    localparam MBIST_W0  = 3'd3;
    localparam MBIST_R0  = 3'd4;
    localparam MBIST_W1  = 3'd5;
    localparam MBIST_R1  = 3'd6;
    localparam MBIST_FIN = 3'd7;

    logic [   2:0]  state_r, state_w;
    logic           start;
    logic           busy_r, busy_w;
    logic [   4:0]  cnt_delay_r, cnt_delay_w;
    logic [   8:0]  addr_r, addr_w;
    logic [   8:0]  addr_add1;
    logic [   1:0]  byte_sel_r, byte_sel_w;
    logic [   3:0]  size_r, size_w;
    logic [  31:0]  data_in;
    logic           wen0, wen1, wen2;
    logic [  44:0]  data_out0, data_out1, data_out2;
    logic [   1:0]  sram_cnt_r, sram_cnt_w;
    logic [   3:0]  error_mask0, error_mask1;
    logic [   1:0]  fault_cnt_add1, fault_cnt_add2;
    logic [  12:0]  fault_addr_r[0:2], fault_addr_w[0:2];
    logic [   1:0]  fault_cnt_r, fault_cnt_w;
    logic [   2:0]  fault_access_r, fault_access_w;
    logic [   7:0]  fault_replace_data;
    logic [  31:0]  data1_r, data1_w;
    logic [  31:0]  data2_r, data2_w;
    logic [  31:0]  data3_r, data3_w;
    logic           first_r, first_w;
    logic [1023:0]  data_buffer_r, data_buffer_w;
    logic [   1:0]  sram_en_r, sram_en_w;

    assign MEM_data_HREADY = (state_r == REGULAR);
    assign MEM_data_HRESP = 1'b0;                        

    assign MEM_cfg_HREADY = 1'b1;
    assign MEM_cfg_HRESP = 1'b0;

    always @(*) begin
        case(MEM_cfg_HADDR[2:1])
            2'd0: MEM_cfg_HRDATA = 16'd0;
            2'd1: MEM_cfg_HRDATA = {busy_r, 2'd0, fault_addr_r[0]};
            2'd2: MEM_cfg_HRDATA = {3'd0, fault_addr_r[1]};
            2'd3: MEM_cfg_HRDATA = {3'd0, fault_addr_r[2]};
        endcase
    end

    assign start = (MEM_cfg_HTRANS[1] && ~|MEM_cfg_HADDR[2:1]);
    assign irq = (state_r == MBIST_FIN);
    assign first_w = (state_r == REGULAR) && (state_w == WAIT);
    assign sram_en_w = (state_r == REGULAR) ? (MEM_data_HADDR[12] ? 2'd2 : MEM_data_HADDR[11] ? 2'd1 : 2'd0) : sram_en_r;
    assign fault_cnt_add1 = fault_cnt_r[1] ? 2'd3 : fault_cnt_r[0] ? 2'd2 : 2'd1;
    assign fault_cnt_add2 = fault_cnt_r[0] ? 2'd3 : 2'd2;
    assign addr_add1 = addr_r + 1'b1;
    assign fault_access_w[2] = ({sram_en_w, addr_w} == fault_addr_r[2][12:2]);
    assign fault_access_w[1] = ({sram_en_w, addr_w} == fault_addr_r[1][12:2]);
    assign fault_access_w[0] = ({sram_en_w, addr_w} == fault_addr_r[0][12:2]);

    always @(*) begin
        state_w = state_r;
        case(state_r)
            REGULAR:   state_w = start ? CFG : (MEM_data_HTRANS[1] ? WAIT : REGULAR);
            WAIT:      state_w = |cnt_delay_r ? WAIT : REGULAR;
            CFG:       state_w = MEM_cfg_HWDATA[0] ? MBIST_W0 : REGULAR;
            MBIST_W0:  state_w = &addr_r ? MBIST_R0 : MBIST_W0;
            MBIST_R0:  state_w = &{sram_cnt_r[1], addr_r} ? MBIST_W1 : MBIST_R0;
            MBIST_W1:  state_w = ~|addr_r ? MBIST_R1 : MBIST_W1;
            MBIST_R1:  state_w = (sram_cnt_r[1] && ~|addr_r) ? MBIST_FIN : MBIST_R1;
            MBIST_FIN: state_w = REGULAR;
        endcase
    end

    always @(*) begin
        busy_w = (state_r != REGULAR) && (state_r != WAIT);
        cnt_delay_w = (state_r == REGULAR) ? (|MEM_data_HSIZE[2:1] ? (6'd1 << (MEM_data_HSIZE - 2'd2)) - 1'b1 : 5'd0) : cnt_delay_r - 1'b1;
    end

    always @(*) begin
        case(size_r[2:0])
            4'd0: begin
                case(byte_sel_r)
                    2'd0: MEM_data_HRDATA = data_buffer_r[999:992];
                    2'd1: MEM_data_HRDATA = data_buffer_r[1007:1000];
                    2'd2: MEM_data_HRDATA = data_buffer_r[1015:1008];
                    2'd3: MEM_data_HRDATA = data_buffer_r[1023:1016];
                endcase
            end
            4'd1: begin
                case(byte_sel_r[1])
                    1'b0: MEM_data_HRDATA = data_buffer_r[1007:992];
                    1'b1: MEM_data_HRDATA = data_buffer_r[1023:1008];
                endcase
            end
            4'd2: MEM_data_HRDATA = data_buffer_r[1023:992];
            4'd3: MEM_data_HRDATA = data_buffer_r[1023:960];
            4'd4: MEM_data_HRDATA = data_buffer_r[1023:896];
            4'd5: MEM_data_HRDATA = data_buffer_r[1023:768];
            4'd6: MEM_data_HRDATA = data_buffer_r[1023:512];
            4'd7: MEM_data_HRDATA = data_buffer_r;
        endcase
    end

    always @(*) begin
        addr_w = 0;
        sram_cnt_w = 0;
        byte_sel_w = byte_sel_r;
        size_w = size_r;
        data_in = 0;
        {wen0, wen1, wen2} = 3'b111;
        case(state_r)
            REGULAR: begin
                addr_w = MEM_data_HADDR[10:2];
                size_w = {~MEM_data_HWRITE, MEM_data_HSIZE};
                byte_sel_w = MEM_data_HADDR[1:0];
            end
            WAIT: begin
                addr_w = ((first_r && ~size_r[3]) || ~|size_r[3:1]) ? addr_r : addr_r + 1'b1; // first write or write size <= 2 bytes
                wen0 = ~size_r[3] ? |sram_en_r[1:0] : 1'b1;
                wen1 = ~size_r[3] ? ~(sram_en_r[0]) : 1'b1;
                wen2 = ~size_r[3] ? ~(sram_en_r[1]) : 1'b1;
                if (|size_r[3:1]) begin
                    if (first_r) begin
                        if (fault_access_w[2]) begin
                            case(fault_addr_r[2][1:0])
                                2'd0: data_in = {MEM_data_HWDATA[31:8], 8'd0};
                                2'd1: data_in = {MEM_data_HWDATA[31:16], 8'd0, MEM_data_HWDATA[7:0]};
                                2'd2: data_in = {MEM_data_HWDATA[31:24], 8'd0, MEM_data_HWDATA[15:0]};
                                2'd3: data_in = {8'd0, MEM_data_HWDATA[23:0]};
                            endcase
                        end
                        else if (fault_access_w[1]) begin
                            case(fault_addr_r[1][1:0])
                                2'd0: data_in = {MEM_data_HWDATA[31:8], 8'd0};
                                2'd1: data_in = {MEM_data_HWDATA[31:16], 8'd0, MEM_data_HWDATA[7:0]};
                                2'd2: data_in = {MEM_data_HWDATA[31:24], 8'd0, MEM_data_HWDATA[15:0]};
                                2'd3: data_in = {8'd0, MEM_data_HWDATA[23:0]};
                            endcase
                        end
                        else if (fault_access_w[0]) begin
                            case(fault_addr_r[0][1:0])
                                2'd0: data_in = {MEM_data_HWDATA[31:8], 8'd0};
                                2'd1: data_in = {MEM_data_HWDATA[31:16], 8'd0, MEM_data_HWDATA[7:0]};
                                2'd2: data_in = {MEM_data_HWDATA[31:24], 8'd0, MEM_data_HWDATA[15:0]};
                                2'd3: data_in = {8'd0, MEM_data_HWDATA[23:0]};
                            endcase
                        end
                        else data_in = MEM_data_HWDATA[31:0];
                    end
                    else begin
                        if (fault_access_w[2]) begin
                            case(fault_addr_r[2][1:0])
                                2'd0: data_in = {data_buffer_r[31:8], 8'd0};
                                2'd1: data_in = {data_buffer_r[31:16], 8'd0, data_buffer_r[7:0]};
                                2'd2: data_in = {data_buffer_r[31:24], 8'd0, data_buffer_r[15:0]};
                                2'd3: data_in = {8'd0, data_buffer_r[23:0]};
                            endcase
                        end
                        else if (fault_access_w[1]) begin
                            case(fault_addr_r[1][1:0])
                                2'd0: data_in = {data_buffer_r[31:8], 8'd0};
                                2'd1: data_in = {data_buffer_r[31:16], 8'd0, data_buffer_r[7:0]};
                                2'd2: data_in = {data_buffer_r[31:24], 8'd0, data_buffer_r[15:0]};
                                2'd3: data_in = {8'd0, data_buffer_r[23:0]};
                            endcase
                        end
                        else if (fault_access_w[0]) begin
                            case(fault_addr_r[0][1:0])
                                2'd0: data_in = {data_buffer_r[31:8], 8'd0};
                                2'd1: data_in = {data_buffer_r[31:16], 8'd0, data_buffer_r[7:0]};
                                2'd2: data_in = {data_buffer_r[31:24], 8'd0, data_buffer_r[15:0]};
                                2'd3: data_in = {8'd0, data_buffer_r[23:0]};
                            endcase
                        end
                        else data_in = data_buffer_r[31:0];
                    end
                end
                else if (size_r[0]) begin
                    if (sram_en_r[1]) begin
                        if (fault_access_w[2]) begin
                            case(fault_addr_r[2][1:0])
                                2'd0: data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:0], data_out2[15:0]} : {data_out2[31:16], MEM_data_HWDATA[15:8], 8'd0};
                                2'd1: data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:0], data_out2[15:0]} : {data_out2[31:16], 8'd0, MEM_data_HWDATA[7:0]};
                                2'd2: data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:8], 8'd0, data_out2[15:0]} : {data_out2[31:16], MEM_data_HWDATA[15:0]};
                                2'd3: data_in = byte_sel_r[1] ? {8'd0, MEM_data_HWDATA[7:0], data_out2[15:0]} : {data_out2[31:16], MEM_data_HWDATA[15:0]};
                            endcase
                        end
                        else if (fault_access_w[1]) begin
                            case(fault_addr_r[1][1:0])
                                2'd0: data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:0], data_out2[15:0]} : {data_out2[31:16], MEM_data_HWDATA[15:8], 8'd0};
                                2'd1: data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:0], data_out2[15:0]} : {data_out2[31:16], 8'd0, MEM_data_HWDATA[7:0]};
                                2'd2: data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:8], 8'd0, data_out2[15:0]} : {data_out2[31:16], MEM_data_HWDATA[15:0]};
                                2'd3: data_in = byte_sel_r[1] ? {8'd0, MEM_data_HWDATA[7:0], data_out2[15:0]} : {data_out2[31:16], MEM_data_HWDATA[15:0]};
                            endcase
                        end
                        else if (fault_access_w[0]) begin
                            case(fault_addr_r[0][1:0])
                                2'd0: data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:0], data_out2[15:0]} : {data_out2[31:16], MEM_data_HWDATA[15:8], 8'd0};
                                2'd1: data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:0], data_out2[15:0]} : {data_out2[31:16], 8'd0, MEM_data_HWDATA[7:0]};
                                2'd2: data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:8], 8'd0, data_out2[15:0]} : {data_out2[31:16], MEM_data_HWDATA[15:0]};
                                2'd3: data_in = byte_sel_r[1] ? {8'd0, MEM_data_HWDATA[7:0], data_out2[15:0]} : {data_out2[31:16], MEM_data_HWDATA[15:0]};
                            endcase
                        end
                        else data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:0], data_out2[15:0]} : {data_out2[31:16], MEM_data_HWDATA[15:0]};
                    end
                    else if (sram_en_r[0]) begin
                        if (fault_access_w[2]) begin
                            case(fault_addr_r[2][1:0])
                                2'd0: data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:0], data_out1[15:0]} : {data_out1[31:16], MEM_data_HWDATA[15:8], 8'd0};
                                2'd1: data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:0], data_out1[15:0]} : {data_out1[31:16], 8'd0, MEM_data_HWDATA[7:0]};
                                2'd2: data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:8], 8'd0, data_out1[15:0]} : {data_out1[31:16], MEM_data_HWDATA[15:0]};
                                2'd3: data_in = byte_sel_r[1] ? {8'd0, MEM_data_HWDATA[7:0], data_out1[15:0]} : {data_out1[31:16], MEM_data_HWDATA[15:0]};
                            endcase
                        end
                        else if (fault_access_w[1]) begin
                            case(fault_addr_r[1][1:0])
                                2'd0: data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:0], data_out1[15:0]} : {data_out1[31:16], MEM_data_HWDATA[15:8], 8'd0};
                                2'd1: data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:0], data_out1[15:0]} : {data_out1[31:16], 8'd0, MEM_data_HWDATA[7:0]};
                                2'd2: data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:8], 8'd0, data_out1[15:0]} : {data_out1[31:16], MEM_data_HWDATA[15:0]};
                                2'd3: data_in = byte_sel_r[1] ? {8'd0, MEM_data_HWDATA[7:0], data_out1[15:0]} : {data_out1[31:16], MEM_data_HWDATA[15:0]};
                            endcase
                        end
                        else if (fault_access_w[0]) begin
                            case(fault_addr_r[0][1:0])
                                2'd0: data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:0], data_out1[15:0]} : {data_out1[31:16], MEM_data_HWDATA[15:8], 8'd0};
                                2'd1: data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:0], data_out1[15:0]} : {data_out1[31:16], 8'd0, MEM_data_HWDATA[7:0]};
                                2'd2: data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:8], 8'd0, data_out1[15:0]} : {data_out1[31:16], MEM_data_HWDATA[15:0]};
                                2'd3: data_in = byte_sel_r[1] ? {8'd0, MEM_data_HWDATA[7:0], data_out1[15:0]} : {data_out1[31:16], MEM_data_HWDATA[15:0]};
                            endcase
                        end
                        else data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:0], data_out1[15:0]} : {data_out1[31:16], MEM_data_HWDATA[15:0]};
                    end
                    else begin
                        if (fault_access_w[2]) begin
                            case(fault_addr_r[2][1:0])
                                2'd0: data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:0], data_out0[15:0]} : {data_out0[31:16], MEM_data_HWDATA[15:8], 8'd0};
                                2'd1: data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:0], data_out0[15:0]} : {data_out0[31:16], 8'd0, MEM_data_HWDATA[7:0]};
                                2'd2: data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:8], 8'd0, data_out0[15:0]} : {data_out0[31:16], MEM_data_HWDATA[15:0]};
                                2'd3: data_in = byte_sel_r[1] ? {8'd0, MEM_data_HWDATA[7:0], data_out0[15:0]} : {data_out0[31:16], MEM_data_HWDATA[15:0]};
                            endcase
                        end
                        else if (fault_access_w[1]) begin
                            case(fault_addr_r[1][1:0])
                                2'd0: data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:0], data_out0[15:0]} : {data_out0[31:16], MEM_data_HWDATA[15:8], 8'd0};
                                2'd1: data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:0], data_out0[15:0]} : {data_out0[31:16], 8'd0, MEM_data_HWDATA[7:0]};
                                2'd2: data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:8], 8'd0, data_out0[15:0]} : {data_out0[31:16], MEM_data_HWDATA[15:0]};
                                2'd3: data_in = byte_sel_r[1] ? {8'd0, MEM_data_HWDATA[7:0], data_out0[15:0]} : {data_out0[31:16], MEM_data_HWDATA[15:0]};
                            endcase
                        end
                        else if (fault_access_w[0]) begin
                            case(fault_addr_r[0][1:0])
                                2'd0: data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:0], data_out0[15:0]} : {data_out0[31:16], MEM_data_HWDATA[15:8], 8'd0};
                                2'd1: data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:0], data_out0[15:0]} : {data_out0[31:16], 8'd0, MEM_data_HWDATA[7:0]};
                                2'd2: data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:8], 8'd0, data_out0[15:0]} : {data_out0[31:16], MEM_data_HWDATA[15:0]};
                                2'd3: data_in = byte_sel_r[1] ? {8'd0, MEM_data_HWDATA[7:0], data_out0[15:0]} : {data_out0[31:16], MEM_data_HWDATA[15:0]};
                            endcase
                        end
                        else data_in = byte_sel_r[1] ? {MEM_data_HWDATA[15:0], data_out0[15:0]} : {data_out0[31:16], MEM_data_HWDATA[15:0]};
                    end
                end
                else begin
                    if (sram_en_r[1]) begin
                        if (fault_access_w[2]) begin
                            case(fault_addr_r[2][1:0])
                                2'd0: begin
                                    data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out2[23:0]} : 
                                              byte_sel_r[1] ? {data_out2[31:24], MEM_data_HWDATA[7:0], data_out2[15:0]} : 
                                              byte_sel_r[0] ? {data_out2[31:16], MEM_data_HWDATA[7:0], data_out2[7:0]} : {data_out2[31:8], 8'd0}); 
                                end
                                2'd1: begin
                                    data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out2[23:0]} : 
                                              byte_sel_r[1] ? {data_out2[31:24], MEM_data_HWDATA[7:0], data_out2[15:0]} : 
                                              byte_sel_r[0] ? {data_out2[31:16], 8'd0, data_out2[7:0]} : {data_out2[31:8], MEM_data_HWDATA[7:0]}); 
                                end
                                2'd2: begin
                                    data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out2[23:0]} : 
                                              byte_sel_r[1] ? {data_out2[31:24], 8'd0, data_out2[15:0]} : 
                                              byte_sel_r[0] ? {data_out2[31:16], MEM_data_HWDATA[7:0], data_out2[7:0]} : {data_out2[31:8], MEM_data_HWDATA[7:0]});  
                                end
                                2'd3: begin
                                    data_in = (&byte_sel_r[1:0] ? {8'd0, data_out2[23:0]} : 
                                              byte_sel_r[1] ? {data_out2[31:24], MEM_data_HWDATA[7:0], data_out2[15:0]} : 
                                              byte_sel_r[0] ? {data_out2[31:16], MEM_data_HWDATA[7:0], data_out2[7:0]} : {data_out2[31:8], MEM_data_HWDATA[7:0]}); 
                                end
                            endcase
                        end
                        else if (fault_access_w[1]) begin
                            case(fault_addr_r[1][1:0])
                                2'd0: begin
                                    data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out2[23:0]} : 
                                              byte_sel_r[1] ? {data_out2[31:24], MEM_data_HWDATA[7:0], data_out2[15:0]} : 
                                              byte_sel_r[0] ? {data_out2[31:16], MEM_data_HWDATA[7:0], data_out2[7:0]} : {data_out2[31:8], 8'd0}); 
                                end
                                2'd1: begin
                                    data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out2[23:0]} : 
                                              byte_sel_r[1] ? {data_out2[31:24], MEM_data_HWDATA[7:0], data_out2[15:0]} : 
                                              byte_sel_r[0] ? {data_out2[31:16], 8'd0, data_out2[7:0]} : {data_out2[31:8], MEM_data_HWDATA[7:0]}); 
                                end
                                2'd2: begin
                                    data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out2[23:0]} : 
                                              byte_sel_r[1] ? {data_out2[31:24], 8'd0, data_out2[15:0]} : 
                                              byte_sel_r[0] ? {data_out2[31:16], MEM_data_HWDATA[7:0], data_out2[7:0]} : {data_out2[31:8], MEM_data_HWDATA[7:0]});  
                                end
                                2'd3: begin
                                    data_in = (&byte_sel_r[1:0] ? {8'd0, data_out2[23:0]} : 
                                              byte_sel_r[1] ? {data_out2[31:24], MEM_data_HWDATA[7:0], data_out2[15:0]} : 
                                              byte_sel_r[0] ? {data_out2[31:16], MEM_data_HWDATA[7:0], data_out2[7:0]} : {data_out2[31:8], MEM_data_HWDATA[7:0]}); 
                                end
                            endcase
                        end
                        else if (fault_access_w[0]) begin
                            case(fault_addr_r[0][1:0])
                                2'd0: begin
                                    data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out2[23:0]} : 
                                              byte_sel_r[1] ? {data_out2[31:24], MEM_data_HWDATA[7:0], data_out2[15:0]} : 
                                              byte_sel_r[0] ? {data_out2[31:16], MEM_data_HWDATA[7:0], data_out2[7:0]} : {data_out2[31:8], 8'd0}); 
                                end
                                2'd1: begin
                                    data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out2[23:0]} : 
                                              byte_sel_r[1] ? {data_out2[31:24], MEM_data_HWDATA[7:0], data_out2[15:0]} : 
                                              byte_sel_r[0] ? {data_out2[31:16], 8'd0, data_out2[7:0]} : {data_out2[31:8], MEM_data_HWDATA[7:0]}); 
                                end
                                2'd2: begin
                                    data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out2[23:0]} : 
                                              byte_sel_r[1] ? {data_out2[31:24], 8'd0, data_out2[15:0]} : 
                                              byte_sel_r[0] ? {data_out2[31:16], MEM_data_HWDATA[7:0], data_out2[7:0]} : {data_out2[31:8], MEM_data_HWDATA[7:0]});  
                                end
                                2'd3: begin
                                    data_in = (&byte_sel_r[1:0] ? {8'd0, data_out2[23:0]} : 
                                              byte_sel_r[1] ? {data_out2[31:24], MEM_data_HWDATA[7:0], data_out2[15:0]} : 
                                              byte_sel_r[0] ? {data_out2[31:16], MEM_data_HWDATA[7:0], data_out2[7:0]} : {data_out2[31:8], MEM_data_HWDATA[7:0]}); 
                                end
                            endcase
                        end
                        else begin
                            data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out2[23:0]} : 
                                      byte_sel_r[1] ? {data_out2[31:24], MEM_data_HWDATA[7:0], data_out2[15:0]} : 
                                      byte_sel_r[0] ? {data_out2[31:16], MEM_data_HWDATA[7:0], data_out2[7:0]} : {data_out2[31:8], MEM_data_HWDATA[7:0]});
                        end
                    end
                    else if (sram_en_r[0]) begin
                        if (fault_access_w[2]) begin
                            case(fault_addr_r[2][1:0])
                                2'd0: begin
                                    data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out1[23:0]} : 
                                              byte_sel_r[1] ? {data_out1[31:24], MEM_data_HWDATA[7:0], data_out1[15:0]} : 
                                              byte_sel_r[0] ? {data_out1[31:16], MEM_data_HWDATA[7:0], data_out1[7:0]} : {data_out1[31:8], 8'd0}); 
                                end
                                2'd1: begin
                                    data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out1[23:0]} : 
                                              byte_sel_r[1] ? {data_out1[31:24], MEM_data_HWDATA[7:0], data_out1[15:0]} : 
                                              byte_sel_r[0] ? {data_out1[31:16], 8'd0, data_out1[7:0]} : {data_out1[31:8], MEM_data_HWDATA[7:0]}); 
                                end
                                2'd2: begin
                                    data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out1[23:0]} : 
                                              byte_sel_r[1] ? {data_out1[31:24], 8'd0, data_out1[15:0]} : 
                                              byte_sel_r[0] ? {data_out1[31:16], MEM_data_HWDATA[7:0], data_out1[7:0]} : {data_out1[31:8], MEM_data_HWDATA[7:0]});  
                                end
                                2'd3: begin
                                    data_in = (&byte_sel_r[1:0] ? {8'd0, data_out1[23:0]} : 
                                              byte_sel_r[1] ? {data_out1[31:24], MEM_data_HWDATA[7:0], data_out1[15:0]} : 
                                              byte_sel_r[0] ? {data_out1[31:16], MEM_data_HWDATA[7:0], data_out1[7:0]} : {data_out1[31:8], MEM_data_HWDATA[7:0]}); 
                                end
                            endcase
                        end
                        else if (fault_access_w[1]) begin
                            case(fault_addr_r[1][1:0])
                                2'd0: begin
                                    data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out1[23:0]} : 
                                              byte_sel_r[1] ? {data_out1[31:24], MEM_data_HWDATA[7:0], data_out1[15:0]} : 
                                              byte_sel_r[0] ? {data_out1[31:16], MEM_data_HWDATA[7:0], data_out1[7:0]} : {data_out1[31:8], 8'd0}); 
                                end
                                2'd1: begin
                                    data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out1[23:0]} : 
                                              byte_sel_r[1] ? {data_out1[31:24], MEM_data_HWDATA[7:0], data_out1[15:0]} : 
                                              byte_sel_r[0] ? {data_out1[31:16], 8'd0, data_out1[7:0]} : {data_out1[31:8], MEM_data_HWDATA[7:0]}); 
                                end
                                2'd2: begin
                                    data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out1[23:0]} : 
                                              byte_sel_r[1] ? {data_out1[31:24], 8'd0, data_out1[15:0]} : 
                                              byte_sel_r[0] ? {data_out1[31:16], MEM_data_HWDATA[7:0], data_out1[7:0]} : {data_out1[31:8], MEM_data_HWDATA[7:0]});  
                                end
                                2'd3: begin
                                    data_in = (&byte_sel_r[1:0] ? {8'd0, data_out1[23:0]} : 
                                              byte_sel_r[1] ? {data_out1[31:24], MEM_data_HWDATA[7:0], data_out1[15:0]} : 
                                              byte_sel_r[0] ? {data_out1[31:16], MEM_data_HWDATA[7:0], data_out1[7:0]} : {data_out1[31:8], MEM_data_HWDATA[7:0]}); 
                                end
                            endcase
                        end
                        else if (fault_access_w[0]) begin
                            case(fault_addr_r[0][1:0])
                                2'd0: begin
                                    data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out1[23:0]} : 
                                              byte_sel_r[1] ? {data_out1[31:24], MEM_data_HWDATA[7:0], data_out1[15:0]} : 
                                              byte_sel_r[0] ? {data_out1[31:16], MEM_data_HWDATA[7:0], data_out1[7:0]} : {data_out1[31:8], 8'd0}); 
                                end
                                2'd1: begin
                                    data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out1[23:0]} : 
                                              byte_sel_r[1] ? {data_out1[31:24], MEM_data_HWDATA[7:0], data_out1[15:0]} : 
                                              byte_sel_r[0] ? {data_out1[31:16], 8'd0, data_out1[7:0]} : {data_out1[31:8], MEM_data_HWDATA[7:0]}); 
                                end
                                2'd2: begin
                                    data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out1[23:0]} : 
                                              byte_sel_r[1] ? {data_out1[31:24], 8'd0, data_out1[15:0]} : 
                                              byte_sel_r[0] ? {data_out1[31:16], MEM_data_HWDATA[7:0], data_out1[7:0]} : {data_out1[31:8], MEM_data_HWDATA[7:0]});  
                                end
                                2'd3: begin
                                    data_in = (&byte_sel_r[1:0] ? {8'd0, data_out1[23:0]} : 
                                              byte_sel_r[1] ? {data_out1[31:24], MEM_data_HWDATA[7:0], data_out1[15:0]} : 
                                              byte_sel_r[0] ? {data_out1[31:16], MEM_data_HWDATA[7:0], data_out1[7:0]} : {data_out1[31:8], MEM_data_HWDATA[7:0]}); 
                                end
                            endcase
                        end
                        else begin
                            data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out1[23:0]} : 
                                      byte_sel_r[1] ? {data_out1[31:24], MEM_data_HWDATA[7:0], data_out1[15:0]} : 
                                      byte_sel_r[0] ? {data_out1[31:16], MEM_data_HWDATA[7:0], data_out1[7:0]} : {data_out1[31:8], MEM_data_HWDATA[7:0]});
                        end
                    end
                    else begin
                        if (fault_access_w[2]) begin
                            case(fault_addr_r[2][1:0])
                                2'd0: begin
                                    data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out0[23:0]} : 
                                              byte_sel_r[1] ? {data_out0[31:24], MEM_data_HWDATA[7:0], data_out0[15:0]} : 
                                              byte_sel_r[0] ? {data_out0[31:16], MEM_data_HWDATA[7:0], data_out0[7:0]} : {data_out0[31:8], 8'd0}); 
                                end
                                2'd1: begin
                                    data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out0[23:0]} : 
                                              byte_sel_r[1] ? {data_out0[31:24], MEM_data_HWDATA[7:0], data_out0[15:0]} : 
                                              byte_sel_r[0] ? {data_out0[31:16], 8'd0, data_out0[7:0]} : {data_out0[31:8], MEM_data_HWDATA[7:0]}); 
                                end
                                2'd2: begin
                                    data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out0[23:0]} : 
                                              byte_sel_r[1] ? {data_out0[31:24], 8'd0, data_out0[15:0]} : 
                                              byte_sel_r[0] ? {data_out0[31:16], MEM_data_HWDATA[7:0], data_out0[7:0]} : {data_out0[31:8], MEM_data_HWDATA[7:0]});  
                                end
                                2'd3: begin
                                    data_in = (&byte_sel_r[1:0] ? {8'd0, data_out0[23:0]} : 
                                              byte_sel_r[1] ? {data_out0[31:24], MEM_data_HWDATA[7:0], data_out0[15:0]} : 
                                              byte_sel_r[0] ? {data_out0[31:16], MEM_data_HWDATA[7:0], data_out0[7:0]} : {data_out0[31:8], MEM_data_HWDATA[7:0]}); 
                                end
                            endcase
                        end
                        else if (fault_access_w[1]) begin
                            case(fault_addr_r[1][1:0])
                                2'd0: begin
                                    data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out0[23:0]} : 
                                              byte_sel_r[1] ? {data_out0[31:24], MEM_data_HWDATA[7:0], data_out0[15:0]} : 
                                              byte_sel_r[0] ? {data_out0[31:16], MEM_data_HWDATA[7:0], data_out0[7:0]} : {data_out0[31:8], 8'd0}); 
                                end
                                2'd1: begin
                                    data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out0[23:0]} : 
                                              byte_sel_r[1] ? {data_out0[31:24], MEM_data_HWDATA[7:0], data_out0[15:0]} : 
                                              byte_sel_r[0] ? {data_out0[31:16], 8'd0, data_out0[7:0]} : {data_out0[31:8], MEM_data_HWDATA[7:0]}); 
                                end
                                2'd2: begin
                                    data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out0[23:0]} : 
                                              byte_sel_r[1] ? {data_out0[31:24], 8'd0, data_out0[15:0]} : 
                                              byte_sel_r[0] ? {data_out0[31:16], MEM_data_HWDATA[7:0], data_out0[7:0]} : {data_out0[31:8], MEM_data_HWDATA[7:0]});  
                                end
                                2'd3: begin
                                    data_in = (&byte_sel_r[1:0] ? {8'd0, data_out0[23:0]} : 
                                              byte_sel_r[1] ? {data_out0[31:24], MEM_data_HWDATA[7:0], data_out0[15:0]} : 
                                              byte_sel_r[0] ? {data_out0[31:16], MEM_data_HWDATA[7:0], data_out0[7:0]} : {data_out0[31:8], MEM_data_HWDATA[7:0]}); 
                                end
                            endcase
                        end
                        else if (fault_access_w[0]) begin
                            case(fault_addr_r[0][1:0])
                                2'd0: begin
                                    data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out0[23:0]} : 
                                              byte_sel_r[1] ? {data_out0[31:24], MEM_data_HWDATA[7:0], data_out0[15:0]} : 
                                              byte_sel_r[0] ? {data_out0[31:16], MEM_data_HWDATA[7:0], data_out0[7:0]} : {data_out0[31:8], 8'd0}); 
                                end
                                2'd1: begin
                                    data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out0[23:0]} : 
                                              byte_sel_r[1] ? {data_out0[31:24], MEM_data_HWDATA[7:0], data_out0[15:0]} : 
                                              byte_sel_r[0] ? {data_out0[31:16], 8'd0, data_out0[7:0]} : {data_out0[31:8], MEM_data_HWDATA[7:0]}); 
                                end
                                2'd2: begin
                                    data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out0[23:0]} : 
                                              byte_sel_r[1] ? {data_out0[31:24], 8'd0, data_out0[15:0]} : 
                                              byte_sel_r[0] ? {data_out0[31:16], MEM_data_HWDATA[7:0], data_out0[7:0]} : {data_out0[31:8], MEM_data_HWDATA[7:0]});  
                                end
                                2'd3: begin
                                    data_in = (&byte_sel_r[1:0] ? {8'd0, data_out0[23:0]} : 
                                              byte_sel_r[1] ? {data_out0[31:24], MEM_data_HWDATA[7:0], data_out0[15:0]} : 
                                              byte_sel_r[0] ? {data_out0[31:16], MEM_data_HWDATA[7:0], data_out0[7:0]} : {data_out0[31:8], MEM_data_HWDATA[7:0]}); 
                                end
                            endcase
                        end
                        else begin
                            data_in = (&byte_sel_r[1:0] ? {MEM_data_HWDATA[7:0], data_out0[23:0]} : 
                                      byte_sel_r[1] ? {data_out0[31:24], MEM_data_HWDATA[7:0], data_out0[15:0]} : 
                                      byte_sel_r[0] ? {data_out0[31:16], MEM_data_HWDATA[7:0], data_out0[7:0]} : {data_out0[31:8], MEM_data_HWDATA[7:0]});
                        end
                    end
                end
            end
            CFG: begin
                addr_w = 0;
                {wen0, wen1, wen2} = 3'b000;
                data_in = {32{1'b0}};
            end
            MBIST_W0: begin
                addr_w = addr_r + 1'b1;
                {wen0, wen1, wen2} = &addr_r ? 3'b111 : 3'b000;
                data_in = {32{1'b0}};
            end
            MBIST_R0: begin
                addr_w = &addr_r ? (sram_cnt_r[1] ? addr_r : 9'd0) : addr_r + 1'b1;
                sram_cnt_w = &addr_r ? sram_cnt_r + 1'b1 : sram_cnt_r;
                {wen0, wen1, wen2} = &{sram_cnt_r[1], addr_r} ? 3'b000 : 3'b111;
                data_in = {32{1'b1}};
            end
             MBIST_W1: begin
                addr_w = addr_r - 1'b1;
                {wen0, wen1, wen2} = ~|addr_r ? 3'b111 : 3'b000;
                data_in = {32{1'b1}};
                sram_cnt_w = 2'd0;
            end
            MBIST_R1: begin
                addr_w = ~|addr_r ? (sram_cnt_r[1] ? addr_r : 9'h1ff) : addr_r - 1'b1;
                sram_cnt_w = ~|addr_r ? sram_cnt_r + 1'b1 : sram_cnt_r;
            end
        endcase
    end

    always @(*) begin
        data1_w = (~&{wen0, wen1, wen2} && fault_access_w[0]) ? (first_r ? MEM_data_HWDATA[31:0] : data_buffer_r[31:0]) : data1_r;
        data2_w = (~&{wen0, wen1, wen2} && fault_access_w[1]) ? (first_r ? MEM_data_HWDATA[31:0] : data_buffer_r[31:0]) : data2_r;
        data3_w = (~&{wen0, wen1, wen2} && fault_access_w[2]) ? (first_r ? MEM_data_HWDATA[31:0] : data_buffer_r[31:0]) : data3_r;
    end

    always @(*) begin
        fault_replace_data = sram_en_r[1] ? data_out2[39:32] : sram_en_r[0] ? data_out1[39:32] : data_out0[39:32];
        if (state_r == WAIT) begin
            if (|size_r[3:1]) begin
                if (fault_access_r[2]) begin
                    case(fault_addr_r[2][1:0])
                        2'd0: fault_replace_data = MEM_data_HWDATA[7:0];
                        2'd1: fault_replace_data = MEM_data_HWDATA[15:8];
                        2'd2: fault_replace_data = MEM_data_HWDATA[23:16];
                        2'd3: fault_replace_data = MEM_data_HWDATA[31:24];
                    endcase
                end
                else if (fault_access_r[1]) begin
                    case(fault_addr_r[1][1:0])
                        2'd0: fault_replace_data = MEM_data_HWDATA[7:0];
                        2'd1: fault_replace_data = MEM_data_HWDATA[15:8];
                        2'd2: fault_replace_data = MEM_data_HWDATA[23:16];
                        2'd3: fault_replace_data = MEM_data_HWDATA[31:24];
                    endcase
                end
                else if (fault_access_r[0]) begin
                    case(fault_addr_r[0][1:0])
                        2'd0: fault_replace_data = MEM_data_HWDATA[7:0];
                        2'd1: fault_replace_data = MEM_data_HWDATA[15:8];
                        2'd2: fault_replace_data = MEM_data_HWDATA[23:16];
                        2'd3: fault_replace_data = MEM_data_HWDATA[31:24];
                    endcase
                end
            end
            else if (size_r[0]) begin
                if (fault_access_r[2]) begin
                    case(fault_addr_r[2][0])
                        1'b0: fault_replace_data = MEM_data_HWDATA[7:0];
                        1'b1: fault_replace_data = MEM_data_HWDATA[15:8];
                    endcase
                end
                else if (fault_access_r[1]) begin
                    case(fault_addr_r[1][0])
                        1'b0: fault_replace_data = MEM_data_HWDATA[7:0];
                        1'b1: fault_replace_data = MEM_data_HWDATA[15:8];
                    endcase
                end
                else if (fault_access_r[0]) begin
                    case(fault_addr_r[0][0])
                        1'b0: fault_replace_data = MEM_data_HWDATA[7:0];
                        1'b1: fault_replace_data = MEM_data_HWDATA[15:8];
                    endcase
                end
            end
            else begin
                if (|fault_access_r) begin
                    fault_replace_data = MEM_data_HWDATA[7:0];
                end
            end
        end
    end

    always @(*) begin
        data_buffer_w = data_buffer_r;
        if (state_r == WAIT) begin
            if (~size_r[3]) begin // write
                data_buffer_w = first_r ? MEM_data_HWDATA[1023:32] : data_buffer_r[1023:32];
            end
            else begin // read
                if (sram_en_r[1]) begin
                    if (fault_access_r[2]) begin
                        data_buffer_w = {data3_r, data_buffer_r[1023:32]};
                    end
                    else if (fault_access_r[1]) begin
                        data_buffer_w = {data2_r, data_buffer_r[1023:32]};
                    end
                    else if (fault_access_r[0]) begin
                        data_buffer_w = {data1_r, data_buffer_r[1023:32]};
                    end
                    else data_buffer_w = {data_out2[31:0], data_buffer_r[1023:32]};
                end 
                else if (sram_en_r[0]) begin
                    if (fault_access_r[2]) begin
                        data_buffer_w = {data3_r, data_buffer_r[1023:32]};
                    end
                    else if (fault_access_r[1]) begin
                        data_buffer_w = {data2_r, data_buffer_r[1023:32]};
                    end
                    else if (fault_access_r[0]) begin
                        data_buffer_w = {data1_r, data_buffer_r[1023:32]};
                    end
                    else data_buffer_w = {data_out1[31:0], data_buffer_r[1023:32]};
                end
                else begin
                    if (fault_access_r[2]) begin
                        data_buffer_w = {data3_r, data_buffer_r[1023:32]};
                    end
                    else if (fault_access_r[1]) begin
                        data_buffer_w = {data2_r, data_buffer_r[1023:32]};
                    end
                    else if (fault_access_r[0]) begin
                        data_buffer_w = {data1_r, data_buffer_r[1023:32]};
                    end
                    else data_buffer_w = {data_out0[31:0], data_buffer_r[1023:32]};
                end
            end
        end
    end

    always @(*) begin
        error_mask0 = sram_cnt_r[1] ? {|data_out2[31:24], |data_out2[23:16], |data_out2[15:8], |data_out2[7:0]} :
                      sram_cnt_r[0] ? {|data_out1[31:24], |data_out1[23:16], |data_out1[15:8], |data_out1[7:0]} :
                                      {|data_out0[31:24], |data_out0[23:16], |data_out0[15:8], |data_out0[7:0]};
        error_mask1 = sram_cnt_r[1] ? {~&data_out2[31:24], ~&data_out2[23:16], ~&data_out2[15:8], ~&data_out2[7:0]} :
                      sram_cnt_r[0] ? {~&data_out1[31:24], ~&data_out1[23:16], ~&data_out1[15:8], ~&data_out1[7:0]} :
                                      {~&data_out0[31:24], ~&data_out0[23:16], ~&data_out0[15:8], ~&data_out0[7:0]}; 
        fault_cnt_w = fault_cnt_r;
        fault_addr_w[0] = fault_addr_r[0];
        fault_addr_w[1] = fault_addr_r[1];
        fault_addr_w[2] = fault_addr_r[2];
        case(state_r)
            MBIST_R0: begin
                case(error_mask0)
                    4'b0001: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd0} : fault_addr_r[fault_cnt_r];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                    4'b0010: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd1} : fault_addr_r[fault_cnt_r];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                    4'b0100: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd2} : fault_addr_r[fault_cnt_r];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                    4'b1000: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd3} : fault_addr_r[fault_cnt_r];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                    4'b0011: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd0} : fault_addr_r[fault_cnt_r];
                        fault_addr_w[fault_cnt_add1] = ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd1} : fault_addr_r[fault_cnt_add1];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? fault_cnt_add2 : 
                                      ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                    4'b0101: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd0} : fault_addr_r[fault_cnt_r];
                        fault_addr_w[fault_cnt_add1] = ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd2} : fault_addr_r[fault_cnt_add1];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? fault_cnt_add2 : 
                                      ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                    4'b1001: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd0} : fault_addr_r[fault_cnt_r];
                        fault_addr_w[fault_cnt_add1] = ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd3} : fault_addr_r[fault_cnt_add1];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add2 : 
                                      ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                    4'b0110: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd1} : fault_addr_r[fault_cnt_r];
                        fault_addr_w[fault_cnt_add1] = ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd2} : fault_addr_r[fault_cnt_add1];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? fault_cnt_add2 : 
                                      ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                    4'b1010: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd1} : fault_addr_r[fault_cnt_r];
                        fault_addr_w[fault_cnt_add1] = ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd3} : fault_addr_r[fault_cnt_add1];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add2 :
                                      ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                    4'b1100: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd2} : fault_addr_r[fault_cnt_r];
                        fault_addr_w[fault_cnt_add1] = ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd3} : fault_addr_r[fault_cnt_add1];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add2 :
                                      ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                    4'b0111: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd0} : fault_addr_r[fault_cnt_r];
                        fault_addr_w[fault_cnt_add1] = ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd1} : fault_addr_r[fault_cnt_add1];
                        fault_addr_w[fault_cnt_add2] = ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd2} : fault_addr_r[fault_cnt_add2];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? 2'd3 :
                                      ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? fault_cnt_add2 :
                                      ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? fault_cnt_add2 :
                                      ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? fault_cnt_add2 : 
                                      ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                    4'b1011: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd0} : fault_addr_r[fault_cnt_r];
                        fault_addr_w[fault_cnt_add1] = ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd1} : fault_addr_r[fault_cnt_add1];
                        fault_addr_w[fault_cnt_add2] = ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd3} : fault_addr_r[fault_cnt_add2];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? 2'd3 :
                                      ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? fault_cnt_add2 :
                                      ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add2 :
                                      ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add2 : 
                                      ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                    4'b1101: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd0} : fault_addr_r[fault_cnt_r];
                        fault_addr_w[fault_cnt_add1] = ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd2} : fault_addr_r[fault_cnt_add1];
                        fault_addr_w[fault_cnt_add2] = ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd3} : fault_addr_r[fault_cnt_add2];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? 2'd3 :
                                      ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? fault_cnt_add2 :
                                      ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add2 :
                                      ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add2 :
                                      ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                    4'b1110: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd1} : fault_addr_r[fault_cnt_r];
                        fault_addr_w[fault_cnt_add1] = ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd2} : fault_addr_r[fault_cnt_add1];
                        fault_addr_w[fault_cnt_add2] = ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd3} : fault_addr_r[fault_cnt_add2];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? 2'd3 :
                                      ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? fault_cnt_add2 :
                                      ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add2 :
                                      ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add2 : 
                                      ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                endcase
            end
            MBIST_R1: begin
                case(error_mask1)
                    4'b0001: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd0} : fault_addr_r[fault_cnt_r];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                    4'b0010: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd1} : fault_addr_r[fault_cnt_r];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                    4'b0100: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd2} : fault_addr_r[fault_cnt_r];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                    4'b1000: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd3} : fault_addr_r[fault_cnt_r];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                    4'b0011: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd0} : fault_addr_r[fault_cnt_r];
                        fault_addr_w[fault_cnt_add1] = ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd1} : fault_addr_r[fault_cnt_add1];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? fault_cnt_add2 : 
                                      ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                    4'b0101: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd0} : fault_addr_r[fault_cnt_r];
                        fault_addr_w[fault_cnt_add1] = ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd2} : fault_addr_r[fault_cnt_add1];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? fault_cnt_add2 : 
                                      ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                    4'b0110: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd1} : fault_addr_r[fault_cnt_r];
                        fault_addr_w[fault_cnt_add1] = ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd2} : fault_addr_r[fault_cnt_add1];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? fault_cnt_add2 : 
                                      ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                    4'b1001: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd0} : fault_addr_r[fault_cnt_r];
                        fault_addr_w[fault_cnt_add1] = ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd3} : fault_addr_r[fault_cnt_add1];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add2 : 
                                      ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                    4'b1010: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd1} : fault_addr_r[fault_cnt_r];
                        fault_addr_w[fault_cnt_add1] = ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd3} : fault_addr_r[fault_cnt_add1];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add2 :
                                      ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                    4'b1100: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd2} : fault_addr_r[fault_cnt_r];
                        fault_addr_w[fault_cnt_add1] = ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd3} : fault_addr_r[fault_cnt_add1];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add2 :
                                      ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                    4'b0111: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd0} : fault_addr_r[fault_cnt_r];
                        fault_addr_w[fault_cnt_add1] = ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd1} : fault_addr_r[fault_cnt_add1];
                        fault_addr_w[fault_cnt_add2] = ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd2} : fault_addr_r[fault_cnt_add2];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? 2'd3 :
                                      ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? fault_cnt_add2 :
                                      ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? fault_cnt_add2 :
                                      ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? fault_cnt_add2 : 
                                      ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                    4'b1011: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd0} : fault_addr_r[fault_cnt_r];
                        fault_addr_w[fault_cnt_add1] = ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd1} : fault_addr_r[fault_cnt_add1];
                        fault_addr_w[fault_cnt_add2] = ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd3} : fault_addr_r[fault_cnt_add2];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? 2'd3 :
                                      ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? fault_cnt_add2 :
                                      ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add2 :
                                      ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add2 : 
                                      ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                    4'b1101: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd0} : fault_addr_r[fault_cnt_r];
                        fault_addr_w[fault_cnt_add1] = ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd2} : fault_addr_r[fault_cnt_add1];
                        fault_addr_w[fault_cnt_add2] = ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd3} : fault_addr_r[fault_cnt_add2];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? 2'd3 :
                                      ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? fault_cnt_add2 :
                                      ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add2 :
                                      ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add2 :
                                      ({sram_cnt_r, addr_r, 2'd0} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd0} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                    4'b1110: begin
                        fault_addr_w[fault_cnt_r] = ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                                     {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                                     {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd1} : fault_addr_r[fault_cnt_r];
                        fault_addr_w[fault_cnt_add1] = ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd2} : fault_addr_r[fault_cnt_add1];
                        fault_addr_w[fault_cnt_add2] = ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                                        {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                                        {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? {sram_cnt_r, addr_r, 2'd3} : fault_addr_r[fault_cnt_add2];
                        fault_cnt_w = ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? 2'd3 :
                                      ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? fault_cnt_add2 :
                                      ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add2 :
                                      ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add2 : 
                                      ({sram_cnt_r, addr_r, 2'd1} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd1} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd2} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd2} != fault_addr_r[2]) ? fault_cnt_add1 :
                                      ({sram_cnt_r, addr_r, 2'd3} != fault_addr_r[0] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[1] &&
                                       {sram_cnt_r, addr_r, 2'd3} != fault_addr_r[2]) ? fault_cnt_add1 : fault_cnt_r;
                    end
                endcase
            end
        endcase
    end

    always @(posedge i_clk) begin
        if (~i_rst_n) begin
            state_r <= REGULAR;
            busy_r <= 1'b0;
            cnt_delay_r <= 0;
            addr_r <= 0;
            byte_sel_r <= 0;
            size_r <= 0;
            fault_addr_r[0] <= {13{1'b1}};
            fault_addr_r[1] <= {13{1'b1}};
            fault_addr_r[2] <= {13{1'b1}};
            fault_cnt_r <= 0;
            sram_cnt_r <= 0;
            data_buffer_r <= 0;
            data1_r <= 0;
            data2_r <= 0;
            data3_r <= 0;
            first_r <= 1'b0;
            sram_en_r <= 2'b11;
            fault_access_r <= 3'b000;
        end 
        else begin
            state_r <= state_w;
            busy_r <= busy_w;
            cnt_delay_r <= cnt_delay_w;
            addr_r <= addr_w;
            byte_sel_r <= byte_sel_w;
            size_r <= size_w;
            fault_addr_r[0] <= fault_addr_w[0];
            fault_addr_r[1] <= fault_addr_w[1];
            fault_addr_r[2] <= fault_addr_w[2];
            fault_cnt_r <= fault_cnt_w;
            sram_cnt_r <= sram_cnt_w;
            data_buffer_r <= data_buffer_w;
            data1_r <= data1_w;
            data2_r <= data2_w;
            data3_r <= data3_w;
            first_r <= first_w;
            sram_en_r <= sram_en_w;
            fault_access_r <= fault_access_w;
        end
    end

    
    spsram512x45m4 u_sram0 (
        .SLP(1'b0),
        .DSLP(1'b0),
        .SD(1'b0),
        .CLK(i_clk),
        .CEB(1'b0),
        .WEB(wen0),
        .A(addr_w),
        .D({5'd0, fault_replace_data, data_in}),
        .BWEB({45{1'b0}}),
        .Q(data_out0),
        .PUDELAY()
    );

    spsram512x45m4 u_sram1 (
        .SLP(1'b0),
        .DSLP(1'b0),
        .SD(1'b0),
        .CLK(i_clk),
        .CEB(1'b0),
        .WEB(wen1),
        .A(addr_w),
        .D({5'd0, fault_replace_data, data_in}),
        .BWEB({45{1'b0}}),
        .Q(data_out1),
        .PUDELAY()
    );

    spsram512x45m4 u_sram2 (
        .SLP(1'b0),
        .DSLP(1'b0),
        .SD(1'b0),
        .CLK(i_clk),
        .CEB(1'b0),
        .WEB(wen2),
        .A(addr_w),
        .D({5'd0, fault_replace_data, data_in}),
        .BWEB({45{1'b0}}),
        .Q(data_out2),
        .PUDELAY()
    );

endmodule
