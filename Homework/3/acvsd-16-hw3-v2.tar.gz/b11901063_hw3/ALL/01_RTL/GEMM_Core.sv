module GEMM_Core #(
    parameter   DATA_WIDTH = 16
) (
    input   logic   i_clk,
    input   logic   i_rst_n,
    input   logic   test_mode,
    input   logic   start,
    output  logic   irq,
    // Interconnect
    output  logic            GEMM_data_EN,
    output  logic   [  13:0] GEMM_data_HADDR,
    output  logic            GEMM_data_HWRITE,
    output  logic   [   2:0] GEMM_data_HSIZE,
    output  logic   [   2:0] GEMM_data_HBURST,
    output  logic   [   1:0] GEMM_data_HTRANS,
    output  logic   [ 511:0] GEMM_data_HWDATA,
    input   logic            GEMM_data_HREADY,
    input   logic            GEMM_data_HRESP,
    input   logic   [ 511:0] GEMM_data_HRDATA,
    output  logic            PSW_NSLEEPIN,
    output  logic            ISO_EN,
    input   logic            PSW_ACK
);

    localparam IDLE   = 3'd0;
    localparam READ_A = 3'd1;
    localparam READ_B = 3'd2;
    localparam WAIT   = 3'd3;
    localparam WRITE  = 3'd4;
    localparam FINISH = 3'd5;

    logic [   2:0]  state_r, state_w;
    logic           busy_r, busy_w;
    logic [   4:0]  cnt_r, cnt_w;
    logic [   4:0]  cnt_col_r, cnt_col_w;
    logic           pmu_en;
    logic [   1:0]  pmu_valid_sel;
    logic [ 511:0]  pmu_out_data;
    logic           pmu_out_valid;
    logic           pmu_request_B;

    assign PSW_NSLEEPIN = test_mode ? 1'b1 : (busy_r ? 1'b1 : 1'b0);
    assign ISO_EN = test_mode ? 1'b0 : (busy_r ? 1'b0 : 1'b1);

    assign GEMM_data_EN = busy_r;
    assign GEMM_data_HSIZE = 3'b110; // 64 bytes
    assign GEMM_data_HBURST = 3'b000; // SINGLE

    assign irq = (state_r == FINISH) && busy_r;

    GEMM_pmu u_GEMM_pmu (
        .i_clk              (i_clk),
        .i_rst_n            (i_rst_n),
        .i_en               (pmu_en),
        .test_mode          (test_mode),
        .in_data            (GEMM_data_HRDATA),
        .valid_sel          (pmu_valid_sel),
        .out_data           (pmu_out_data),
        .out_valid          (pmu_out_valid),
        .request_B          (pmu_request_B)
    );

    always @(*) begin
        state_w = state_r;
        case(state_r)
            IDLE:   state_w = start ? READ_A : IDLE;
            READ_A: state_w = GEMM_data_HREADY ? READ_B : READ_A;
            READ_B: state_w = GEMM_data_HREADY ? WAIT : READ_B;
            WAIT:   state_w = GEMM_data_HREADY ? WRITE : WAIT;
            WRITE:  state_w = pmu_out_valid ? (&cnt_r ? FINISH : READ_A) : (pmu_request_B ? READ_B : WRITE);
            FINISH: state_w = FINISH;
        endcase
    end

    always @(*) begin
        busy_w = (state_r == FINISH) ? 1'b0 : (busy_r || start);
        cnt_w = (state_r == WRITE && pmu_out_valid) ? cnt_r + 1'b1 : cnt_r;
        cnt_col_w = (state_r == WRITE && (pmu_request_B || pmu_out_valid)) ? cnt_col_r + 1'b1 : cnt_col_r;
    end

    always @(*) begin
        GEMM_data_HADDR = 14'd0;
        GEMM_data_HWRITE = 1'b0;
        GEMM_data_HTRANS = 2'b00;
        pmu_valid_sel = 2'b00;
        case(state_r)
            READ_A: begin
                GEMM_data_HADDR = {3'd0, cnt_r, 6'd0};
                GEMM_data_HWRITE = 1'b0;
                GEMM_data_HTRANS = 2'b10; // NONSEQ
            end
            READ_B: begin
                GEMM_data_HADDR = {3'd1, cnt_col_r, 6'd0};
                GEMM_data_HWRITE = 1'b0;
                GEMM_data_HTRANS = 2'b10; // NONSEQ
                pmu_valid_sel = (GEMM_data_HREADY && ~|cnt_col_r) ? 2'b01 : 2'b00;
            end
            WAIT: begin
                GEMM_data_HTRANS = 2'b00; // IDLE
                pmu_valid_sel = GEMM_data_HREADY ? 2'b10 : 2'b00;
            end
            WRITE: begin
                GEMM_data_HADDR = {3'd2, cnt_r, 6'd0};
                GEMM_data_HWRITE = 1'b1;
                GEMM_data_HTRANS = pmu_out_valid ? 2'b10 : 2'b00; // NONSEQ, IDLE
            end
        endcase
    end

    always @(posedge i_clk) begin
        if (!i_rst_n) begin
            state_r <= IDLE;
            busy_r <= 1'b0;
            cnt_r <= 5'd0;
            cnt_col_r <= 5'd0;
            GEMM_data_HWDATA <= 512'd0;
            pmu_en <= 1'b0;
        end
        else begin
            state_r <= state_w;
            busy_r <= busy_w;
            cnt_r <= cnt_w;
            cnt_col_r <= cnt_col_w;
            GEMM_data_HWDATA <= pmu_out_data;
            pmu_en <= busy_r;
        end
    end

endmodule


module GEMM_pmu (
    input   logic   i_clk,
    input   logic   i_rst_n,
    input   logic   i_en,
    input   logic   test_mode,

    input   logic   [ 511:0] in_data,
    input   logic   [   1:0] valid_sel,
    output  logic   [ 511:0] out_data,
    output  logic            out_valid,
    output  logic            request_B
);
    // when test_mode is 1, PSW should be always closed and ISO should be always disabled

    localparam IDLE = 3'd0;
    localparam WAIT = 3'd1;
    localparam MULT = 3'd2;
    localparam ADD  = 3'd3;
    localparam OUT  = 3'd4;

    logic [ 2:0]    state_r, state_w;
    logic [15:0]    a_buffer_r[0:31], a_buffer_w[0:31];
    logic [15:0]    b_buffer_r[0:31], b_buffer_w[0:31];
    logic [ 4:0]    cnt_col_r, cnt_col_w;
    logic [15:0]    mult_buffer_r[0:31], mult_buffer_w[0:31];
    logic [15:0]    out_buffer_r[0:31], out_buffer_w[0:31];
    logic [15:0]    dw_mult_result[0:31];
    logic           dw_mult_ctrl;
    logic [15:0]    dw_add_result_lv1[0:15];
    logic [15:0]    dw_add_result_lv2[0:7];
    logic [15:0]    dw_add_result_lv3[0:3];
    logic [15:0]    dw_add_result_lv4[0:1];
    logic [15:0]    dw_add_result_lv5;
    logic           dw_add_ctrl;
    integer         i;

    assign dw_mult_ctrl = (state_r == MULT);
    assign dw_add_ctrl = (state_r == ADD);

    assign out_valid = (state_r == OUT);
    assign out_data = {out_buffer_r[31], out_buffer_r[30], out_buffer_r[29], out_buffer_r[28],
                       out_buffer_r[27], out_buffer_r[26], out_buffer_r[25], out_buffer_r[24],
                       out_buffer_r[23], out_buffer_r[22], out_buffer_r[21], out_buffer_r[20],
                       out_buffer_r[19], out_buffer_r[18], out_buffer_r[17], out_buffer_r[16],
                       out_buffer_r[15], out_buffer_r[14], out_buffer_r[13], out_buffer_r[12],
                       out_buffer_r[11], out_buffer_r[10], out_buffer_r[ 9], out_buffer_r[ 8],
                       out_buffer_r[ 7], out_buffer_r[ 6], out_buffer_r[ 5], out_buffer_r[ 4],
                       out_buffer_r[ 3], out_buffer_r[ 2], out_buffer_r[ 1], out_buffer_r[ 0]};

    assign request_B = (state_r == ADD) && ~&cnt_col_r;
    
    always @(*) begin
        state_w = IDLE;
        case(state_r)
            IDLE: state_w = i_en ? WAIT : IDLE;
            WAIT: state_w = valid_sel[1] ? MULT : WAIT;
            MULT: state_w = ADD;
            ADD:  state_w = &cnt_col_r ? OUT : WAIT;
            OUT:  state_w = WAIT;
        endcase
    end

    always @(*) begin
        cnt_col_w = (state_r != IDLE) ? (state_r == ADD) ? cnt_col_r + 1'b1 : cnt_col_r : 5'd0;
    end

    always @(*) begin
        for (i = 0; i < 32; i = i + 1) begin
            a_buffer_w[i] = a_buffer_r[i];
            b_buffer_w[i] = b_buffer_r[i];
            mult_buffer_w[i] = mult_buffer_r[i];
        end
        if (state_r == WAIT) begin
            if (valid_sel[0]) begin
                for (i = 0; i < 32; i = i + 1) begin
                    a_buffer_w[i] = in_data[16*i +: 16];
                end
            end
            else if (valid_sel[1]) begin
                for (i = 0; i < 32; i = i + 1) begin
                    b_buffer_w[i] = in_data[16*i +: 16];
                end
            end
        end
        else if (state_r == MULT) begin
            for (i = 0; i < 32; i = i + 1) begin
                mult_buffer_w[i] = dw_mult_result[i];
            end
        end
    end

    always @(*) begin
        for (i = 0; i < 32; i = i + 1) begin
            out_buffer_w[i] = out_buffer_r[i];
        end
        if (state_r == ADD) begin
            for (i = 0; i < 31; i = i + 1) begin
                out_buffer_w[i] = out_buffer_r[i+1];
            end
            out_buffer_w[31] = dw_add_result_lv5;
        end
    end

    genvar gen_mult;
    generate
        for (gen_mult = 0; gen_mult < 32; gen_mult = gen_mult + 1) begin
            DW_fp_mult_DG #(.sig_width(10), .exp_width(5), .ieee_compliance(1)
            ) u_fp_mac (
                .a      (a_buffer_r[gen_mult]),
                .b      (b_buffer_r[gen_mult]),
                .rnd    (3'b000),
                .z      (dw_mult_result[gen_mult]),
                .status (),
                .DG_ctrl(dw_mult_ctrl)
            );
        end
    endgenerate

    genvar gen_add;
    generate
        for (gen_add = 0; gen_add < 16; gen_add = gen_add + 1) begin
            DW_fp_add_DG #(.sig_width(10), .exp_width(5), .ieee_compliance(1)
            ) u_fp_add (
                .a      (mult_buffer_r[2*gen_add]),
                .b      (mult_buffer_r[2*gen_add + 1]),
                .rnd    (3'b000),
                .z      (dw_add_result_lv1[gen_add]),
                .status (),
                .DG_ctrl(dw_add_ctrl)
            );
        end
        for (gen_add = 0; gen_add < 8; gen_add = gen_add + 1) begin
            DW_fp_add_DG #(.sig_width(10), .exp_width(5), .ieee_compliance(1)
            ) u_fp_add_lv2 (
                .a      (dw_add_result_lv1[2*gen_add]),
                .b      (dw_add_result_lv1[2*gen_add + 1]),
                .rnd    (3'b000),
                .z      (dw_add_result_lv2[gen_add]),
                .status (),
                .DG_ctrl(dw_add_ctrl)
            );
        end
        for (gen_add = 0; gen_add < 4; gen_add = gen_add + 1) begin
            DW_fp_add_DG #(.sig_width(10), .exp_width(5), .ieee_compliance(1)
            ) u_fp_add_lv3 (
                .a      (dw_add_result_lv2[2*gen_add]),
                .b      (dw_add_result_lv2[2*gen_add + 1]),
                .rnd    (3'b000),
                .z      (dw_add_result_lv3[gen_add]),
                .status (),
                .DG_ctrl(dw_add_ctrl)
            );
        end
        for (gen_add = 0; gen_add < 2; gen_add = gen_add + 1) begin
            DW_fp_add_DG #(.sig_width(10), .exp_width(5), .ieee_compliance(1)
            ) u_fp_add_lv4 (
                .a      (dw_add_result_lv3[2*gen_add]),
                .b      (dw_add_result_lv3[2*gen_add + 1]),
                .rnd    (3'b000),
                .z      (dw_add_result_lv4[gen_add]),
                .status (),
                .DG_ctrl(dw_add_ctrl)
            );
        end
        DW_fp_add_DG #(.sig_width(10), .exp_width(5), .ieee_compliance(1)
        ) u_fp_add_lv5 (
            .a      (dw_add_result_lv4[0]),
            .b      (dw_add_result_lv4[1]),
            .rnd    (3'b000),
            .z      (dw_add_result_lv5),
            .status (),
            .DG_ctrl(dw_add_ctrl)
        );
    endgenerate

    always @(posedge i_clk) begin
        if (!i_rst_n || !i_en) begin
            state_r <= IDLE;
            cnt_col_r <= 5'd0;
            for (i = 0; i < 32; i = i + 1) begin
                a_buffer_r[i] <= 16'd0;
                b_buffer_r[i] <= 16'd0;
                mult_buffer_r[i] <= 16'd0;
                out_buffer_r[i] <= 16'd0;
            end
        end
        else begin
            state_r <= state_w;
            cnt_col_r <= cnt_col_w;
            for (i = 0; i < 32; i = i + 1) begin
                a_buffer_r[i] <= a_buffer_w[i];
                b_buffer_r[i] <= b_buffer_w[i];
                mult_buffer_r[i] <= mult_buffer_w[i];
                out_buffer_r[i] <= out_buffer_w[i];
            end
        end
    end 

endmodule
