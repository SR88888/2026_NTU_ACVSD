// Testbench
../00_TB/tb.sv

// DesignWare
-y /usr/cad/synopsys/synthesis/cur/dw/sim_ver
+libext+.v+.sv+.vlib
+incdir++/usr/cad/synopsys/synthesis/cur/dw/sim_ver+

// UPF
-power
-upf ../01_RTL/top.upf

// SRAM
-v /share1/tech/ADFP/Executable_Package/Collaterals/IP/sram/N16ADFP_SRAM/VERILOG/N16ADFP_SRAM_100a.v
-y ../01_RTL/SRAM/
+libext++.v+.sv

// Design files
../01_RTL/top.sv
../01_RTL/RST_Sync.sv
../01_RTL/SIMD_Core.sv
../01_RTL/GEMM_Core.sv
../01_RTL/Shared_Memory.sv
../01_RTL/Interconnect.sv
