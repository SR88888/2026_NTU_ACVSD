module top # (
    parameter   DATA_WIDTH = 16
) (
    input   logic   CLK,
    input   logic   CLK_CORE,
    input   logic   RST_N,
    output  logic   IRQ,

    input   logic   [  13:0] HADDR,
    input   logic            HWRITE,
    input   logic   [   2:0] HSIZE,
    input   logic   [   2:0] HBURST,
    input   logic   [   1:0] HTRANS,
    input   logic   [1023:0] HWDATA,
    output  logic            HREADY,
    output  logic            HRESP,
    output  logic   [1023:0] HRDATA,

    input   logic   test_mode,      // for PMU bypass
    input   logic   scan_enable     // for DFT, not used in RTL
);

    logic          SIMD_irq;
    logic          SIMD_data_EN;
    logic [  13:0] SIMD_data_HADDR;
    logic          SIMD_data_HWRITE;
    logic [   2:0] SIMD_data_HSIZE;
    logic [   2:0] SIMD_data_HBURST;
    logic [   1:0] SIMD_data_HTRANS;
    logic [ 255:0] SIMD_data_HWDATA;
    logic          SIMD_data_HREADY;
    logic          SIMD_data_HRESP;
    logic [ 255:0] SIMD_data_HRDATA;
    logic          SIMD_start;
    logic          GEMM_irq;
    logic          GEMM_data_EN;
    logic [  13:0] GEMM_data_HADDR;
    logic          GEMM_data_HWRITE;
    logic [   2:0] GEMM_data_HSIZE;
    logic [   2:0] GEMM_data_HBURST;
    logic [   1:0] GEMM_data_HTRANS;
    logic [ 511:0] GEMM_data_HWDATA;
    logic          GEMM_data_HREADY;
    logic          GEMM_data_HRESP;
    logic [ 511:0] GEMM_data_HRDATA;
    logic          GEMM_start;

    logic          MEM_irq;
    logic          MEM_data_valid;
    logic [  13:0] MEM_data_HADDR;
    logic          MEM_data_HWRITE;
    logic [   2:0] MEM_data_HSIZE;
    logic [   2:0] MEM_data_HBURST;
    logic [   1:0] MEM_data_HTRANS;
    logic [1023:0] MEM_data_HWDATA;
    logic          MEM_data_HREADY;
    logic          MEM_data_HRESP;
    logic          MEM_data_read_valid;
    logic [1023:0] MEM_data_HRDATA;
    logic          MEM_start;
    logic          MEM_cfg_valid;
    logic [   1:0] MEM_cfg_sel;
    logic [  15:0] MEM_cfg_HRDATA;

    logic          rst_n_CLK, rst_n_CLK_CORE;
    
    RST_Sync u_rst_sync_CLK (
        .i_clk          (CLK),
        .i_async_rst_n  (RST_N),
        .o_sync_rst_n   (rst_n_CLK),
        .test_mode      (test_mode)
    );

    RST_Sync u_rst_sync_CLK_CORE (
        .i_clk          (CLK_CORE),
        .i_async_rst_n  (RST_N),
        .o_sync_rst_n   (rst_n_CLK_CORE),
        .test_mode      (test_mode)
    );

    // SIMD
    SIMD_Core #(
        .DATA_WIDTH (DATA_WIDTH)
    ) u_SIMD (
        .i_clk              (CLK_CORE),
        .i_rst_n            (rst_n_CLK_CORE),
        .test_mode          (test_mode),
        .start              (SIMD_start),
        .irq                (SIMD_irq),
        .SIMD_data_EN       (SIMD_data_EN),
        .SIMD_data_HADDR    (SIMD_data_HADDR),
        .SIMD_data_HWRITE   (SIMD_data_HWRITE),
        .SIMD_data_HSIZE    (SIMD_data_HSIZE),
        .SIMD_data_HBURST   (SIMD_data_HBURST),
        .SIMD_data_HTRANS   (SIMD_data_HTRANS),
        .SIMD_data_HWDATA   (SIMD_data_HWDATA),
        .SIMD_data_HREADY   (SIMD_data_HREADY),
        .SIMD_data_HRESP    (SIMD_data_HRESP),
        .SIMD_data_HRDATA   (SIMD_data_HRDATA)
    );

    // GEMM
    GEMM_Core #(
        .DATA_WIDTH (DATA_WIDTH)
    ) u_GEMM (
        .i_clk              (CLK_CORE),
        .i_rst_n            (rst_n_CLK_CORE),
        .test_mode          (test_mode),
        .start              (GEMM_start),
        .irq                (GEMM_irq),
        .GEMM_data_EN       (GEMM_data_EN),
        .GEMM_data_HADDR    (GEMM_data_HADDR),
        .GEMM_data_HWRITE   (GEMM_data_HWRITE),
        .GEMM_data_HSIZE    (GEMM_data_HSIZE),
        .GEMM_data_HBURST   (GEMM_data_HBURST),
        .GEMM_data_HTRANS   (GEMM_data_HTRANS),
        .GEMM_data_HWDATA   (GEMM_data_HWDATA),
        .GEMM_data_HREADY   (GEMM_data_HREADY),
        .GEMM_data_HRESP    (GEMM_data_HRESP),
        .GEMM_data_HRDATA   (GEMM_data_HRDATA)
    );

    // Shared Memory
    Shared_Memory #(
        .DATA_WIDTH (DATA_WIDTH)
    ) u_Shared_Memory (
        .i_clk              (CLK_CORE),
        .i_rst_n            (rst_n_CLK_CORE),
        .start              (MEM_start),
        .irq                (MEM_irq),
        .MEM_data_valid     (MEM_data_valid),
        .MEM_data_HADDR     (MEM_data_HADDR),
        .MEM_data_HWRITE    (MEM_data_HWRITE),
        .MEM_data_HSIZE     (MEM_data_HSIZE),
        .MEM_data_HBURST    (MEM_data_HBURST),
        .MEM_data_HTRANS    (MEM_data_HTRANS),
        .MEM_data_HWDATA    (MEM_data_HWDATA),
        .MEM_data_HREADY    (MEM_data_HREADY),
        .MEM_data_HRESP     (MEM_data_HRESP),
        .MEM_data_HRDATA    (MEM_data_HRDATA),
        .MEM_cfg_valid      (MEM_cfg_valid),
        .MEM_cfg_sel        (MEM_cfg_sel),
        .MEM_cfg_HRDATA     (MEM_cfg_HRDATA)
    );

    // Interconnect
    Interconnect #(
        .DATA_WIDTH (DATA_WIDTH)
    ) u_Interconnect (
        .i_clk              (CLK),
        .i_clk_core         (CLK_CORE),
        .i_rst_n            (rst_n_CLK),
        .i_rst_n_core       (rst_n_CLK_CORE),
        .tb_HADDR           (HADDR),
        .tb_HWRITE          (HWRITE),
        .tb_HSIZE           (HSIZE),
        .tb_HBURST          (HBURST),
        .tb_HTRANS          (HTRANS),
        .tb_HWDATA          (HWDATA),
        .tb_HREADY          (HREADY),
        .tb_HRESP           (HRESP),
        .tb_HRDATA          (HRDATA),
        .SIMD_start         (SIMD_start),
        .SIMD_irq           (SIMD_irq),
        .SIMD_data_EN       (SIMD_data_EN),
        .SIMD_data_HADDR    (SIMD_data_HADDR),
        .SIMD_data_HWRITE   (SIMD_data_HWRITE),
        .SIMD_data_HSIZE    (SIMD_data_HSIZE),
        .SIMD_data_HBURST   (SIMD_data_HBURST),
        .SIMD_data_HTRANS   (SIMD_data_HTRANS),
        .SIMD_data_HWDATA   (SIMD_data_HWDATA),
        .SIMD_data_HREADY   (SIMD_data_HREADY),
        .SIMD_data_HRESP    (SIMD_data_HRESP),
        .SIMD_data_HRDATA   (SIMD_data_HRDATA),
        .GEMM_start         (GEMM_start),
        .GEMM_irq           (GEMM_irq),
        .GEMM_data_EN       (GEMM_data_EN),
        .GEMM_data_HADDR    (GEMM_data_HADDR),
        .GEMM_data_HWRITE   (GEMM_data_HWRITE),
        .GEMM_data_HSIZE    (GEMM_data_HSIZE),
        .GEMM_data_HBURST   (GEMM_data_HBURST),
        .GEMM_data_HTRANS   (GEMM_data_HTRANS),
        .GEMM_data_HWDATA   (GEMM_data_HWDATA),
        .GEMM_data_HREADY   (GEMM_data_HREADY),
        .GEMM_data_HRESP    (GEMM_data_HRESP),
        .GEMM_data_HRDATA   (GEMM_data_HRDATA),
        .MEM_start          (MEM_start),
        .MEM_irq            (MEM_irq),
        .MEM_data_valid     (MEM_data_valid),
        .MEM_data_HADDR     (MEM_data_HADDR),
        .MEM_data_HWRITE    (MEM_data_HWRITE),
        .MEM_data_HSIZE     (MEM_data_HSIZE),
        .MEM_data_HBURST    (MEM_data_HBURST),
        .MEM_data_HTRANS    (MEM_data_HTRANS),
        .MEM_data_HWDATA    (MEM_data_HWDATA),
        .MEM_data_HREADY    (MEM_data_HREADY),
        .MEM_data_HRESP     (MEM_data_HRESP),
        .MEM_data_HRDATA    (MEM_data_HRDATA),
        .MEM_cfg_valid      (MEM_cfg_valid),
        .MEM_cfg_sel        (MEM_cfg_sel),
        .MEM_cfg_HRDATA     (MEM_cfg_HRDATA),
        .IRQ                (IRQ)
    );
    
endmodule
