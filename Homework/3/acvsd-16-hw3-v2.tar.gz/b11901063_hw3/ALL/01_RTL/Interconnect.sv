module Interconnect #(
    parameter   DATA_WIDTH = 16
) (
    input   logic   i_clk,
    input   logic   i_clk_core,
    input   logic   i_rst_n,
    input   logic   i_rst_n_core,
    // tb
    input   logic   [  13:0] tb_HADDR,
    input   logic            tb_HWRITE,
    input   logic   [   2:0] tb_HSIZE,
    input   logic   [   2:0] tb_HBURST,
    input   logic   [   1:0] tb_HTRANS,
    input   logic   [1023:0] tb_HWDATA,
    output  logic            tb_HREADY,
    output  logic            tb_HRESP,
    output  logic   [1023:0] tb_HRDATA,
    // SIMD
    output  logic            SIMD_start,
    input   logic            SIMD_irq,
    input   logic            SIMD_data_EN,
    input   logic   [  13:0] SIMD_data_HADDR,
    input   logic            SIMD_data_HWRITE,
    input   logic   [   2:0] SIMD_data_HSIZE,
    input   logic   [   2:0] SIMD_data_HBURST,
    input   logic   [   1:0] SIMD_data_HTRANS,
    input   logic   [ 255:0] SIMD_data_HWDATA,
    output  logic            SIMD_data_HREADY,
    output  logic            SIMD_data_HRESP,
    output  logic   [ 255:0] SIMD_data_HRDATA,
    // GEMM
    output  logic            GEMM_start,
    input   logic            GEMM_irq,
    input   logic            GEMM_data_EN,
    input   logic   [  13:0] GEMM_data_HADDR,
    input   logic            GEMM_data_HWRITE,
    input   logic   [   2:0] GEMM_data_HSIZE,
    input   logic   [   2:0] GEMM_data_HBURST,
    input   logic   [   1:0] GEMM_data_HTRANS,
    input   logic   [ 511:0] GEMM_data_HWDATA,
    output  logic            GEMM_data_HREADY,
    output  logic            GEMM_data_HRESP,
    output  logic   [ 511:0] GEMM_data_HRDATA,
    // Shared Memory
    output  logic            MEM_start,
    input   logic            MEM_irq,
    output  logic            MEM_data_valid,
    output  logic   [  13:0] MEM_data_HADDR,
    output  logic            MEM_data_HWRITE,
    output  logic   [   2:0] MEM_data_HSIZE,
    output  logic   [   2:0] MEM_data_HBURST,
    output  logic   [   1:0] MEM_data_HTRANS,
    output  logic   [1023:0] MEM_data_HWDATA,
    input   logic            MEM_data_HREADY,
    input   logic            MEM_data_HRESP,
    input   logic   [1023:0] MEM_data_HRDATA,
    output  logic            MEM_cfg_valid,
    output  logic   [   1:0] MEM_cfg_sel,
    input   logic   [  15:0] MEM_cfg_HRDATA,

    output  logic            IRQ
);

    localparam NORMAL = 1'b0;
    localparam ERROR  = 1'b1;

    logic           state_r, state_w;
    logic [   1:0]  config_sel;
    logic           pre_start_r, pre_start_w;
    logic           error_en;
    logic           error_HREADY, error_HRESP;

    logic           SIMD_start_w, GEMM_start_w, MEM_start_w;
    logic           SIMD_start_r1, GEMM_start_r1, MEM_start_r1;
    logic           SIMD_start_r2, GEMM_start_r2, MEM_start_r2;
    logic           wait_r, wait_w;
    logic           seq_write_r, seq_write_w;
    logic           write_start_r, write_start_w;
    logic           wait_read_r, wait_read_w;
    logic           core_start_r, core_start_w;
    logic           seq_read_r, seq_read_w;

    logic           SIMD_data_EN_r1, GEMM_data_EN_r1;
    logic           SIMD_data_EN_r2, GEMM_data_EN_r2;

    logic           SIMD_irq_r1, GEMM_irq_r1, MEM_irq_r1;
    logic           SIMD_irq_r2, GEMM_irq_r2, MEM_irq_r2;

    logic           mem_data_in_push, mem_data_in_pop, mem_data_in_empty, mem_data_in_full;
    logic           mem_cfg_in_push, mem_cfg_in_pop, mem_cfg_in_empty;
    logic           mem_data_out_push, mem_data_out_pop, mem_data_out_empty;
    logic           mem_cfg_out_push, mem_cfg_out_pop, mem_cfg_out_empty;
    logic [1041:0]  mem_data_in_data_push, mem_data_in_data_pop;
    logic [   1:0]  mem_cfg_in_data_push, mem_cfg_in_data_pop;
    logic [1023:0]  mem_data_out_data_push, mem_data_out_data_pop;
    logic [  15:0]  mem_cfg_out_data_push, mem_cfg_out_data_pop;

    assign config_sel = tb_HADDR[11:10];

    assign SIMD_start = SIMD_start_r2;
    assign GEMM_start = GEMM_start_r2;
    assign MEM_start = MEM_start_r2;

    assign IRQ = SIMD_irq_r2 | GEMM_irq_r2 | MEM_irq_r2;

    always @(*) begin
        case(state_r)
            NORMAL: state_w = error_en ? ERROR : NORMAL;
            ERROR:  state_w = error_HREADY ? NORMAL : ERROR;
        endcase
    end

    always @(*) begin
        tb_HREADY = 1;
        tb_HRESP = 0;
        tb_HRDATA = 0;
        SIMD_data_HREADY = 0;
        SIMD_data_HRESP = 0;
        SIMD_data_HRDATA = 0;
        GEMM_data_HREADY = 0;
        GEMM_data_HRESP = 0;
        GEMM_data_HRDATA = 0;
        MEM_data_valid = 0;
        MEM_data_HADDR = 0;
        MEM_data_HWRITE = 0;
        MEM_data_HSIZE = 0;
        MEM_data_HBURST = 0;
        MEM_data_HTRANS = 0;
        MEM_data_HWDATA = mem_data_in_data_pop[1023:0];
        MEM_cfg_valid = 0;
        MEM_cfg_sel = 0;
        error_en = 0;
        pre_start_w = 0;
        SIMD_start_w = 0;
        GEMM_start_w = 0;
        MEM_start_w = 0;
        wait_w = 0;
        seq_write_w = 0;
        write_start_w = tb_HWRITE || write_start_r;
        wait_read_w = 0;
        core_start_w = core_start_r || pre_start_r;
        seq_read_w = 0;
        mem_cfg_in_push = 0;
        mem_cfg_in_data_push = 0;
        mem_cfg_in_pop = 0;
        mem_cfg_out_push = 0;
        mem_cfg_out_data_push = 0;
        mem_cfg_out_pop = 0;
        mem_data_in_push = 0;
        mem_data_in_data_push = 0;
        mem_data_in_pop = 0;
        mem_data_out_push = 0;
        mem_data_out_data_push = 0;
        mem_data_out_pop = 0;

        if (state_r == ERROR) begin
            tb_HREADY = error_HREADY;
            tb_HRESP = error_HRESP;
        end
        else begin     

            if (tb_HTRANS[1]) begin
                if (tb_HADDR[13]) begin
                    error_en = tb_HADDR[12] || &tb_HADDR[11:10];
                end
                else begin
                    error_en = &tb_HADDR[12:11] && MEM_data_HREADY;
                end
            end

            if (SIMD_data_EN) begin
                // SIMD -> MEM
                MEM_data_valid   = 1;
                MEM_data_HADDR   = SIMD_data_HADDR;
                MEM_data_HWRITE  = SIMD_data_HWRITE;
                MEM_data_HSIZE   = SIMD_data_HSIZE;
                MEM_data_HBURST  = SIMD_data_HBURST;
                MEM_data_HTRANS  = SIMD_data_HTRANS;
                MEM_data_HWDATA  = SIMD_data_HWDATA;
                // SIMD <- MEM
                SIMD_data_HREADY = MEM_data_HREADY;
                SIMD_data_HRESP  = MEM_data_HRESP;
                SIMD_data_HRDATA = MEM_data_HRDATA[255:0];
            end
            if (GEMM_data_EN) begin
                // GEMM -> MEM
                MEM_data_valid   = 1;
                MEM_data_HADDR   = GEMM_data_HADDR;
                MEM_data_HWRITE  = GEMM_data_HWRITE;
                MEM_data_HSIZE   = GEMM_data_HSIZE;
                MEM_data_HBURST  = GEMM_data_HBURST;
                MEM_data_HTRANS  = GEMM_data_HTRANS;
                MEM_data_HWDATA  = GEMM_data_HWDATA;
                // GEMM <- MEM
                GEMM_data_HREADY = MEM_data_HREADY;
                GEMM_data_HRESP  = MEM_data_HRESP;
                GEMM_data_HRDATA = MEM_data_HRDATA[511:0];
            end

            if (tb_HADDR[13] && ~error_en) begin
                case (config_sel)
                    2'b00: begin
                        pre_start_w = (tb_HTRANS[1] && ~tb_HADDR[1]);
                        SIMD_start_w = pre_start_r && tb_HWDATA[0];
                        tb_HREADY = mem_data_in_empty;
                        tb_HRESP = 0;
                        tb_HRDATA = {SIMD_data_EN_r2, 15'd0};
                        write_start_w = ~mem_data_in_empty;
                    end
                    2'b01: begin
                        pre_start_w = (tb_HTRANS[1] && ~tb_HADDR[1]);
                        GEMM_start_w = pre_start_r && tb_HWDATA[0];
                        tb_HREADY = 1;
                        tb_HRESP = 0;
                        tb_HRDATA = {GEMM_data_EN_r2, 15'd0};
                        write_start_w = ~mem_data_in_empty;
                    end
                    2'b10: begin
                        // tb -> MEM_cfg
                        pre_start_w = (tb_HTRANS[1] && ~|tb_HADDR[2:1]);
                        MEM_start_w = pre_start_r && tb_HWDATA[0];
                        if (tb_HWRITE) begin
                            tb_HREADY = 1;
                            tb_HRESP = 0;
                        end
                        else begin
                            mem_cfg_out_pop = ~mem_cfg_out_empty;
                            tb_HREADY = tb_HTRANS[1] ? 1'b1 : seq_read_r ? mem_cfg_out_pop : 1'b1;
                            mem_cfg_in_push = tb_HTRANS[1] && tb_HREADY;
                            mem_cfg_in_data_push = tb_HADDR[2:1];
                            wait_w = mem_cfg_in_push || mem_cfg_out_empty;

                            mem_cfg_in_pop = ~mem_cfg_in_empty;
                            MEM_cfg_valid = mem_cfg_in_pop;
                            MEM_cfg_sel = mem_cfg_in_data_pop;
                            mem_cfg_out_push = mem_cfg_in_pop;
                            mem_cfg_out_data_push = MEM_cfg_HRDATA;

                            tb_HRDATA = mem_cfg_out_data_pop;
                            seq_read_w = (tb_HTRANS[1] && !tb_HWRITE) ? 1'b1 : ~tb_HREADY;
                        end
                    end
                endcase
            end

            else if (~|{SIMD_data_EN, GEMM_data_EN} && ~error_en) begin
                if (tb_HWRITE || seq_write_r) begin
                    seq_write_w = (tb_HTRANS[1] && tb_HWRITE) ? 1'b1 : mem_data_in_full;
                    mem_data_in_push = ~mem_data_in_full;
                    mem_data_in_data_push = {tb_HADDR[12:0], tb_HWRITE, tb_HSIZE, tb_HTRANS[1], tb_HWDATA};
                    tb_HREADY = ~mem_data_in_full;
                end
                else begin
                    mem_data_out_pop = ~mem_data_out_empty;
                    tb_HREADY = (tb_HTRANS[1] && core_start_r) ? (~tb_HTRANS[0] || mem_data_out_pop) : seq_read_r ? mem_data_out_pop : 1'b1;
                    tb_HRDATA = mem_data_out_data_pop;
                    mem_data_in_push = tb_HTRANS[1] && tb_HREADY;
                    mem_data_in_data_push = {tb_HADDR[12:0], tb_HWRITE, tb_HSIZE, tb_HTRANS[1], tb_HWDATA};
                    seq_read_w = (tb_HTRANS[1] && !tb_HWRITE) ? 1'b1 : ~tb_HREADY;

                    mem_data_in_pop = ~mem_data_in_empty;
                    wait_read_w = mem_data_in_pop || ~MEM_data_HREADY;
                    MEM_data_valid = mem_data_in_pop;
                    MEM_data_HADDR = mem_data_in_data_pop[1041:1029];
                    MEM_data_HWRITE = mem_data_in_data_pop[1028];
                    MEM_data_HSIZE = mem_data_in_data_pop[1027:1025];
                    MEM_data_HTRANS = {mem_data_in_data_pop[1024], 1'b0};
                    MEM_data_HWDATA = mem_data_in_data_pop[1023:0];
                    mem_data_out_push = wait_read_r && MEM_data_HREADY && mem_data_in_empty;
                    mem_data_out_data_push = MEM_data_HRDATA;
                end
            end
            
            if (~mem_data_in_empty && write_start_r) begin
                mem_data_in_pop = MEM_data_HREADY;
                MEM_data_valid = mem_data_in_pop;
                MEM_data_HADDR = mem_data_in_data_pop[1041:1029];
                MEM_data_HWRITE = mem_data_in_data_pop[1028];
                MEM_data_HSIZE = mem_data_in_data_pop[1027:1025];
                MEM_data_HTRANS = {mem_data_in_data_pop[1024], 1'b0};
                MEM_data_HWDATA = mem_data_in_data_pop[1023:0];
            end
        end
    end

    DW_fifo_s2_sf #(
        .width(1042),
        .depth(4),
        .rst_mode(1)
    ) u_fifo_mem_data_in (
        .clk_push(i_clk),
        .clk_pop(i_clk_core),
        .rst_n(i_rst_n),
        .push_req_n(~mem_data_in_push),
        .pop_req_n(~mem_data_in_pop),
        .push_full(mem_data_in_full),
        .pop_empty(mem_data_in_empty),
        .data_in(mem_data_in_data_push),
        .data_out(mem_data_in_data_pop)
    );

    DW_fifo_s2_sf #(
        .width(2),
        .depth(4),
        .rst_mode(1)
    ) u_fifo_mem_cfg_in (
        .clk_push(i_clk),
        .clk_pop(i_clk_core),
        .rst_n(i_rst_n),
        .push_req_n(~mem_cfg_in_push),
        .pop_req_n(~mem_cfg_in_pop),
        .pop_empty(mem_cfg_in_empty),     
        .data_in(mem_cfg_in_data_push),
        .data_out(mem_cfg_in_data_pop)
    );

    DW_fifo_s2_sf #(
        .width(1024),
        .depth(4),
        .rst_mode(1)
    ) u_fifo_mem_data_out (
        .clk_push(i_clk_core),
        .clk_pop(i_clk),
        .rst_n(i_rst_n_core),
        .push_req_n(~mem_data_out_push),
        .pop_req_n(~mem_data_out_pop),
        .pop_empty(mem_data_out_empty),
        .data_in(mem_data_out_data_push),
        .data_out(mem_data_out_data_pop)
    );

    DW_fifo_s2_sf #(
        .width(16),
        .depth(4),
        .rst_mode(1)
    ) u_fifo_mem_cfg_out (
        .clk_push(i_clk_core),
        .clk_pop(i_clk),
        .rst_n(i_rst_n_core),
        .push_req_n(~mem_cfg_out_push),
        .pop_req_n(~mem_cfg_out_pop),
        .pop_empty(mem_cfg_out_empty),
        .data_in(mem_cfg_out_data_push),
        .data_out(mem_cfg_out_data_pop)
    );


    error_response u_error_response (
        .i_clk      (i_clk),
        .i_rst_n    (i_rst_n),
        .i_en       (error_en),
        .o_HREADY   (error_HREADY),
        .o_HRESP    (error_HRESP)
    );

    always @(posedge i_clk) begin
        if (!i_rst_n) begin
            state_r <= NORMAL;
            pre_start_r <= 0;
            wait_r <= 0;
            seq_write_r <= 0;
            write_start_r <= 0;
            core_start_r <= 0;
            seq_read_r <= 0;

            SIMD_data_EN_r1 <= 0;
            GEMM_data_EN_r1 <= 0;
            SIMD_data_EN_r2 <= 0;
            GEMM_data_EN_r2 <= 0;

            SIMD_irq_r1 <= 0;
            GEMM_irq_r1 <= 0;
            MEM_irq_r1 <= 0;
            SIMD_irq_r2 <= 0;
            GEMM_irq_r2 <= 0;
            MEM_irq_r2 <= 0;
        end
        else  begin
            state_r <= state_w;
            pre_start_r <= pre_start_w;
            wait_r <= wait_w;
            seq_write_r <= seq_write_w;
            write_start_r <= write_start_w;
            core_start_r <= core_start_w;
            seq_read_r <= seq_read_w;

            SIMD_data_EN_r1 <= SIMD_data_EN;
            GEMM_data_EN_r1 <= GEMM_data_EN;
            SIMD_data_EN_r2 <= SIMD_data_EN_r1;
            GEMM_data_EN_r2 <= GEMM_data_EN_r1;

            SIMD_irq_r1 <= SIMD_irq;
            GEMM_irq_r1 <= GEMM_irq;
            MEM_irq_r1 <= MEM_irq;
            SIMD_irq_r2 <= SIMD_irq_r1;
            GEMM_irq_r2 <= GEMM_irq_r1;
            MEM_irq_r2 <= MEM_irq_r1;
        end
    end

    always @(posedge i_clk_core) begin
        if (!i_rst_n_core) begin
            SIMD_start_r1 <= 0;
            GEMM_start_r1 <= 0;
            MEM_start_r1 <= 0;
            SIMD_start_r2 <= 0;
            GEMM_start_r2 <= 0;
            MEM_start_r2 <= 0;
            wait_read_r <= 0;
        end
        else begin
            SIMD_start_r1 <= SIMD_start_w;
            GEMM_start_r1 <= GEMM_start_w;
            MEM_start_r1 <= MEM_start_w;
            SIMD_start_r2 <= SIMD_start_r1;
            GEMM_start_r2 <= GEMM_start_r1;
            MEM_start_r2 <= MEM_start_r1;
            wait_read_r <= wait_read_w;
        end
    end
        
endmodule

module error_response (
    input   logic   i_clk,
    input   logic   i_rst_n,
    input   logic   i_en,
    output  logic   o_HREADY,
    output  logic   o_HRESP
);

    localparam IDLE = 1'b0;
    localparam RESP = 1'b1;

    logic       state_r, state_w;
    logic       hready_r, hready_w;

    assign o_HREADY = hready_r;
    assign o_HRESP  = (state_r == RESP);

    always @(*) begin
        case(state_r)
            IDLE: state_w = i_en ? RESP : IDLE;
            RESP: state_w = hready_r ? IDLE : RESP;
        endcase
        hready_w = i_en ? 1'b0 : 1'b1;
    end

    always @(posedge i_clk) begin
        if (!i_rst_n) begin
            state_r <= IDLE;
            hready_r <= 1'b1;
        end
        else begin
            state_r <= state_w;
            hready_r <= hready_w;
        end
    end

endmodule
