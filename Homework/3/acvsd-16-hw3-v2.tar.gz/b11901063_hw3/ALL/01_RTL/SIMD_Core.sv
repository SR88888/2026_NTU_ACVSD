module SIMD_Core #(
    parameter   DATA_WIDTH = 16
) (
    input   logic   i_clk,
    input   logic   i_rst_n,
    input   logic   test_mode,
    input   logic   start,
    output  logic   irq,
    // Interconnect
    output  logic            SIMD_data_EN,
    output  logic   [  13:0] SIMD_data_HADDR,
    output  logic            SIMD_data_HWRITE,
    output  logic   [   2:0] SIMD_data_HSIZE,
    output  logic   [   2:0] SIMD_data_HBURST,
    output  logic   [   1:0] SIMD_data_HTRANS,
    output  logic   [ 255:0] SIMD_data_HWDATA,
    input   logic            SIMD_data_HREADY,
    input   logic            SIMD_data_HRESP,
    input   logic   [ 255:0] SIMD_data_HRDATA,
    output  logic            PSW_NSLEEPIN,
    output  logic            ISO_EN,
    input   logic            PSW_ACK
);

    localparam IDLE     = 3'd0;
    localparam READ_I   = 3'd1;
    localparam READ_A   = 3'd2;
    localparam READ_B   = 3'd3;
    localparam WAIT     = 3'd4;
    localparam WRITE    = 3'd5;
    localparam FINISH   = 3'd6;

    logic [  2:0]   state_r, state_w;
    logic           busy_r, busy_w;
    logic [  5:0]   cnt_r, cnt_w;
    logic           pmu_en;
    logic [  1:0]   pmu_valid_sel;
    logic [255:0]   pmu_out_data;
    logic           pmu_out_valid;

    assign PSW_NSLEEPIN = test_mode ? 1'b1 : (busy_r ? 1'b1 : 1'b0);
    assign ISO_EN = test_mode ? 1'b0 : (busy_r ? 1'b0 : 1'b1);
    
    assign SIMD_data_EN = busy_r;
    assign SIMD_data_HSIZE = 3'b101; // 32 bytes
    assign SIMD_data_HBURST = 3'b000; // SINGLE

    assign irq = (state_r == FINISH) && busy_r;

    SIMD_pmu u_SIMD_pmu (
        .i_clk              (i_clk),
        .i_rst_n            (i_rst_n),
        .i_en               (pmu_en),
        .test_mode          (test_mode),
        .in_data            (SIMD_data_HRDATA),
        .valid_sel          (pmu_valid_sel),
        .out_data           (pmu_out_data),
        .out_valid          (pmu_out_valid)
    );

    always @(*) begin
        state_w = state_r;
        case(state_r)
            IDLE:   state_w = start ? READ_I : IDLE;
            READ_I: state_w = SIMD_data_HREADY ? READ_A : READ_I;
            READ_A: state_w = SIMD_data_HREADY ? READ_B : READ_A;
            READ_B: state_w = SIMD_data_HREADY ? WAIT : READ_B;
            WAIT:   state_w = SIMD_data_HREADY ? WRITE : WAIT;
            WRITE:  state_w = pmu_out_valid ? (&cnt_r ? FINISH : READ_I) : WRITE;
            FINISH: state_w = FINISH;
        endcase
    end

    always @(*) begin
        busy_w = (state_r == FINISH) ? 1'b0 : (busy_r || start);
        cnt_w = (state_r == WRITE && pmu_out_valid) ? cnt_r + 1'b1 : cnt_r;
    end

    always @(*) begin
        SIMD_data_HADDR  = 14'd0;
        SIMD_data_HWRITE = 1'b0;
        SIMD_data_HTRANS = 2'b00;
        pmu_valid_sel    = 2'b00;
        case(state_r)
            READ_I: begin
                SIMD_data_HADDR  = {3'd0, cnt_r, 5'd0};
                SIMD_data_HWRITE = 1'b0;
                SIMD_data_HTRANS = 2'b10; // NONSEQ
            end
            READ_A: begin
                SIMD_data_HADDR  = {3'd1, cnt_r, 5'd0};
                SIMD_data_HWRITE = 1'b0;
                SIMD_data_HTRANS = 2'b10; // NONSEQ
                pmu_valid_sel    = SIMD_data_HREADY ? 2'b01 : 2'b00;
            end
            READ_B: begin
                SIMD_data_HADDR  = {3'd2, cnt_r, 5'd0};
                SIMD_data_HWRITE = 1'b0;
                SIMD_data_HTRANS = 2'b10; // NONSEQ
                pmu_valid_sel    = SIMD_data_HREADY ? 2'b10 : 2'b00;
            end
            WAIT: begin
                SIMD_data_HTRANS = 2'b00; // IDLE
                pmu_valid_sel    = SIMD_data_HREADY ? 2'b11 : 2'b00;
            end
            WRITE: begin
                SIMD_data_HADDR  = {3'd1, cnt_r, 5'd0};
                SIMD_data_HWRITE = 1'b1;
                SIMD_data_HTRANS = pmu_out_valid ? 2'b10 : 2'b00;
            end
        endcase
    end

    always @(posedge i_clk) begin
        if (!i_rst_n) begin
            state_r <= IDLE;
            busy_r <= 1'b0;
            cnt_r <= 6'd0;
            SIMD_data_HWDATA <= 256'd0;
            pmu_en <= 1'b0;
        end
        else begin
            state_r <= state_w;
            busy_r <= busy_w;
            cnt_r <= cnt_w;
            SIMD_data_HWDATA <= pmu_out_data;
            pmu_en <= busy_r;
        end
    end

endmodule


module SIMD_pmu (
    input   logic   i_clk,
    input   logic   i_rst_n,
    input   logic   i_en,
    input   logic   test_mode,
    
    input   logic   [ 255:0] in_data,
    input   logic   [   1:0] valid_sel,
    output  logic   [ 255:0] out_data,
    output  logic            out_valid
);
    // when test_mode is 1, PSW should be always closed and ISO should be always disabled
    
    localparam IDLE = 2'd0;
    localparam WAIT = 2'd1;
    localparam PROC = 2'd2;

    logic   [ 1:0]  state_r, state_w;
    logic   [ 9:0]  instruction_r[0:15], instruction_w[0:15];
    logic   [15:0]  reg_file_r[0:15][0:3], reg_file_w[0:15][0:3];
    logic   [ 1:0]  r1, r2, rd;

    logic   [15:0]  fp_add_sub_result[0:15];
    logic           fp_add_sub_en;
    logic   [15:0]  fp_mult_result[0:15];
    logic           fp_mult_en;
    logic   [15:0]  fp_div_result[0:15];
    logic           fp_div_en;
    logic           fp_cmp_result[0:15];
    logic           fp_cmp_en;
    integer         i, j;

    assign fp_add_sub_en = (instruction_r[0][9:7] == 3'b101);
    assign fp_mult_en = (instruction_r[0][9:6] == 4'b1100);
    assign fp_div_en = (instruction_r[0][9:6] == 4'b1101);
    assign fp_cmp_en = (instruction_r[0][9:6] == 4'b1110);
    assign out_valid = (&instruction_r[0][9:6]) && (state_r == PROC);
    assign out_data = {reg_file_r[15][rd], reg_file_r[14][rd], reg_file_r[13][rd], reg_file_r[12][rd],
                       reg_file_r[11][rd], reg_file_r[10][rd], reg_file_r[ 9][rd], reg_file_r[ 8][rd],
                       reg_file_r[ 7][rd], reg_file_r[ 6][rd], reg_file_r[ 5][rd], reg_file_r[ 4][rd],
                       reg_file_r[ 3][rd], reg_file_r[ 2][rd], reg_file_r[ 1][rd], reg_file_r[ 0][rd]};

    always @(*) begin
        state_w = IDLE;
        case(state_r)
            IDLE: state_w = i_en ? WAIT : IDLE;
            WAIT: state_w = &valid_sel ? PROC : WAIT;
            PROC: state_w = &instruction_r[0][9:6] ? WAIT : PROC;
        endcase
    end

    always @(*) begin
        for (i = 0; i < 16; i = i + 1) begin
            instruction_w[i] = instruction_r[i];
        end
        if (state_r == WAIT) begin
            if (valid_sel == 2'b01) begin
                for (i = 0; i < 16; i = i + 1)  begin
                    instruction_w[i] = in_data[16*i+6 +: 10];
                end
            end
        end
        else begin
            for (i = 0; i < 15; i = i + 1) begin
                instruction_w[i] = instruction_r[i+1];
            end
            instruction_w[15] = 16'd0;
        end
    end

    always @(*) begin
        rd = instruction_r[0][5:4];
        r1 = instruction_r[0][3:2];
        r2 = instruction_r[0][1:0];
    end

    always @(*) begin
        for (i = 0; i < 16; i = i + 1) begin
            for (j = 0; j < 4; j = j + 1) begin
                reg_file_w[i][j] = reg_file_r[i][j];
            end
        end
        if (state_r == WAIT) begin
            if (&valid_sel) begin
                for (i = 0; i < 16; i = i + 1)  begin
                    reg_file_w[i][1] = in_data[16*i +: 16];
                end
            end
            else if (valid_sel[1]) begin
                for (i = 0; i < 16; i = i + 1)  begin
                    reg_file_w[i][0] = in_data[16*i +: 16];
                    reg_file_w[i][2] = 16'd0;
                    reg_file_w[i][3] = 16'd0;
                end
            end
        end
        else begin
            for (i = 0; i < 16; i = i + 1) begin
                case(instruction_r[0][9:6])
                    4'd0:   reg_file_w[i][rd] = $signed(reg_file_r[i][r1]) + $signed(reg_file_r[i][r2]);
                    4'd1:   reg_file_w[i][rd] = $signed(reg_file_r[i][r1]) - $signed(reg_file_r[i][r2]);
                    4'd2:   reg_file_w[i][rd] = $signed(reg_file_r[i][r1]) * $signed(reg_file_r[i][r2]);
                    4'd3:   reg_file_w[i][rd] = ($signed(reg_file_r[i][r1]) < $signed(reg_file_r[i][r2])) ? {8{2'b01}} : {8{2'b10}};
                    4'd4:   reg_file_w[i][rd] = reg_file_r[i][r1] << reg_file_r[i][r2][3:0];
                    4'd5:   reg_file_w[i][rd] = $signed(reg_file_r[i][r1]) >>> reg_file_r[i][r2][3:0];
                    4'd6:   reg_file_w[i][rd] = ~reg_file_r[i][r1];
                    4'd7:   reg_file_w[i][rd] = reg_file_r[i][r1] | reg_file_r[i][r2];
                    4'd8:   reg_file_w[i][rd] = reg_file_r[i][r1] & reg_file_r[i][r2];
                    4'd9:   reg_file_w[i][rd] = reg_file_r[i][r1] ^ reg_file_r[i][r2];
                    4'd10:  reg_file_w[i][rd] = fp_add_sub_result[i];
                    4'd11:  reg_file_w[i][rd] = fp_add_sub_result[i];
                    4'd12:  reg_file_w[i][rd] = fp_mult_result[i];
                    4'd13:  reg_file_w[i][rd] = fp_div_result[i];
                    4'd14:  reg_file_w[i][rd] = fp_cmp_result[i] ? {8{2'b01}} : {8{2'b10}};
                endcase
            end
        end
    end

    genvar gen_dw;
    generate
        for (gen_dw = 0; gen_dw < 16; gen_dw = gen_dw + 1) begin
            DW_fp_addsub_DG #(.sig_width(10), .exp_width(5), .ieee_compliance(1)
            ) u_fp_add_sub (
                .a      (reg_file_r[gen_dw][r1]),
                .b      (reg_file_r[gen_dw][r2]),
                .op     (instruction_r[0][6]),
                .z      (fp_add_sub_result[gen_dw]),
                .status (),
                .rnd    (3'b000),
                .DG_ctrl(fp_add_sub_en)
            );
            DW_fp_mult_DG #(.sig_width(10), .exp_width(5), .ieee_compliance(1)
            ) u_fp_mult (
                .a      (reg_file_r[gen_dw][r1]),
                .b      (reg_file_r[gen_dw][r2]),
                .rnd    (3'b000),
                .z      (fp_mult_result[gen_dw]),
                .status (),
                .DG_ctrl(fp_mult_en)
            );
            DW_fp_div_DG #(.sig_width(10), .exp_width(5), .ieee_compliance(1)
            ) u_fp_div (
                .a      (reg_file_r[gen_dw][r1]),
                .b      (reg_file_r[gen_dw][r2]),
                .rnd    (3'b000),
                .z      (fp_div_result[gen_dw]),
                .status (),
                .DG_ctrl(fp_div_en)
            );
            DW_fp_cmp_DG #(.sig_width(10), .exp_width(5), .ieee_compliance(1)
            ) u_fp_cmp (
                .a      (reg_file_r[gen_dw][r1]),
                .b      (reg_file_r[gen_dw][r2]),
                .altb   (fp_cmp_result[gen_dw]),
                .agtb   (),
                .aeqb   (),
                .unordered (),
                .z0     (),
                .z1     (),
                .status0(),
                .status1(),
                .zctr   (1'b0),
                .DG_ctrl(fp_cmp_en)
            );
        end
    endgenerate

    always @(posedge i_clk) begin
        if (!i_rst_n || !i_en) begin
            state_r <= IDLE;
            for (i = 0; i < 16; i = i + 1) begin
                instruction_r[i] <= 16'd0;
                for (j = 0; j < 4; j = j + 1) begin
                    reg_file_r[i][j] <= 16'd0;
                end
            end
        end 
        else begin
            state_r <= state_w;
            for (i = 0; i < 16; i = i + 1) begin
                instruction_r[i] <= instruction_w[i];
                for (j = 0; j < 4; j = j + 1) begin
                    reg_file_r[i][j] <= reg_file_w[i][j];
                end
            end
        end
    end
    
endmodule
