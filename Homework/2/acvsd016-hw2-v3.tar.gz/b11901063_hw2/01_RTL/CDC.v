`timescale 1ns/1ps
module CDC (
    // Clock and synchronous high reset
    input                   clk_A,
    input                   clk_B,
    input                   rst,

    input                   start_A,
    output                  start_B,
    input                   finish_B,
    output                  finish_A
);

reg start_d1, start_d2;
reg finish_A_d1, finish_A_d2, finish_A_r;

assign start_B = start_d2;
assign finish_A = finish_A_r;

always @(posedge clk_A or posedge rst) begin
    if (rst) begin
        finish_A_d1 <= 0;
        finish_A_d2 <= 0;
	finish_A_r <= 0;
    end 
    else begin
        finish_A_d1 <= finish_B;
        finish_A_d2 <= finish_A_d1;
	finish_A_r <= finish_A_d2 ? ~finish_A_r : finish_A_r;
    end
end

always @(posedge clk_B or posedge rst) begin
    if (rst) begin
        start_d1 <= 0;
        start_d2 <= 0;
    end 
    else begin
        start_d1 <= start_A;
        start_d2 <= start_d1;
    end
end

endmodule
