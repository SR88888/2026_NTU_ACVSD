`timescale 1ns/1ps
module LBP # (
    parameter DATA_WIDTH = 8,              // AXI4 data width
    parameter ADDR_WIDTH = 15,             // AXI4 address width
    parameter STRB_WIDTH = (DATA_WIDTH/8)  // AXI4 strobe width
)
(
    // Clock and synchronous high reset
    input                   clk_A,
    input                   clk_B,
    input                   rst,

    input                   start,
    output                  finish,

    // Data AXI4 master interface
    output [ADDR_WIDTH-1:0] data_awaddr,
    output [           7:0] data_awlen,
    output [           2:0] data_awsize,
    output [           1:0] data_awburst,
    output                  data_awvalid,
    input                   data_awready,
    output [DATA_WIDTH-1:0] data_wdata,
    output [STRB_WIDTH-1:0] data_wstrb,
    output                  data_wlast,
    output                  data_wvalid,
    input                   data_wready,
    // input  [           1:0] data_bresp,
    // input                   data_bvalid,
    // output                  data_bready,
    output [ADDR_WIDTH-1:0] data_araddr,
    output [           7:0] data_arlen,
    output [           2:0] data_arsize,
    output [           1:0] data_arburst,
    output                  data_arvalid,
    input                   data_arready,
    input  [DATA_WIDTH-1:0] data_rdata,
    input  [           1:0] data_rresp,
    input                   data_rlast,
    input                   data_rvalid,
    output                  data_rready
);

wire       start_B;
wire [7:0] i_data[0:8];
wire       i_valid;
wire [7:0] o_data;
wire       o_valid;
wire       finish_B;

AXI_r u_axi_r (
    .clk_B(clk_B),
    .rst(rst),
    .start(start_B),
    .araddr(data_araddr),
    .arlen(data_arlen),
    .arsize(data_arsize),
    .arburst(data_arburst),
    .arvalid(data_arvalid),
    .arready(data_arready),
    .rdata(data_rdata),
    .rresp(data_rresp),
    .rlast(data_rlast),
    .rvalid(data_rvalid),
    .rready(data_rready),
    .data(i_data),
    .data_valid(i_valid)
);

CORE u_core (
    .clk_B(clk_B),
    .rst(rst),
    .i_data(i_data),
    .i_valid(i_valid),
    .o_data(o_data),
    .o_valid(o_valid)
);

AXI_w u_axi_w (
    .clk_B(clk_B),
    .rst(rst),
    .data(o_data),
    .data_valid(o_valid),
    .finish(finish_B),
    .awaddr(data_awaddr),
    .awlen(data_awlen),
    .awsize(data_awsize),
    .awburst(data_awburst),
    .awvalid(data_awvalid),
    .awready(data_awready),
    .wdata(data_wdata),
    .wstrb(data_wstrb),
    .wlast(data_wlast),
    .wvalid(data_wvalid),
    .wready(data_wready)
);

CDC u_cdc (
    .clk_A(clk_A),
    .clk_B(clk_B),
    .rst(rst),
    .start_A(start),
    .start_B(start_B),
    .finish_B(finish_B),
    .finish_A(finish)
);

endmodule
