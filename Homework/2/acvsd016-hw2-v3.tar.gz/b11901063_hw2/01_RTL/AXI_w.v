`timescale 1ns/1ps
module AXI_w # (
    parameter DATA_WIDTH = 8,              // AXI4 data width
    parameter ADDR_WIDTH = 15,             // AXI4 address width
    parameter STRB_WIDTH = (DATA_WIDTH/8)  // AXI4 strobe width
)
(
    input                   clk_B,
    input                   rst,
    input  [DATA_WIDTH-1:0] data,
    input                   data_valid,
    output                  finish,
    // Data AXI4 master interface
    output [ADDR_WIDTH-1:0] awaddr,
    output [           7:0] awlen,
    output [           2:0] awsize,
    output [           1:0] awburst,
    output                  awvalid,
    input                   awready,
    output [DATA_WIDTH-1:0] wdata,
    output [STRB_WIDTH-1:0] wstrb,
    output                  wlast,
    output                  wvalid,
    input                   wready
);

localparam IDLE = 2'd0;
localparam AW   = 2'd1;
localparam WR   = 2'd2;
localparam FIN  = 2'd3;

reg  [1:0]  state_r, state_w;
reg  [6:0]  cnt_r, cnt_w;

assign awaddr = {1'b1, cnt_r, 7'b0};
assign awlen = 8'd127;
assign awsize = 3'd0;
assign awburst = 2'd1;
assign awvalid = (state_r == AW);
assign wdata = data;
assign wstrb = {STRB_WIDTH{1'b1}};
assign wlast = (&cnt_r == 7'd127) && data_valid;
assign wvalid = (state_r == WR) && data_valid;
assign finish = (state_r == FIN);

always @(*) begin
    case(state_r) // synopsys parallel_case
        IDLE:   state_w = AW;
        AW:     state_w = (awready && awvalid) ? WR : AW;
        WR:     state_w = wready ? WR : (&cnt_r) ? FIN : AW;
        FIN:    state_w = FIN;
    endcase
end

always @(*) begin
    cnt_w = (state_r == WR && state_w == AW) ? cnt_r + 1'b1 : cnt_r;
end

always @(posedge clk_B or posedge rst) begin
    if (rst) begin
        state_r <= IDLE;
        cnt_r <= 0;
    end
    else begin
        state_r <= state_w;
        cnt_r <= cnt_w;
    end
end


endmodule
