`timescale 1ns/1ps
module AXI_r # (
    parameter DATA_WIDTH = 8,              // AXI4 data width
    parameter ADDR_WIDTH = 15              // AXI4 address width
)(
    input                       clk_B,
    input                       rst,
    input                       start,
    // Data AXI4 master interface
    output reg [ADDR_WIDTH-1:0] araddr,
    output     [           7:0] arlen,
    output     [           2:0] arsize,
    output     [           1:0] arburst,
    output                      arvalid,
    input                       arready,
    input      [DATA_WIDTH-1:0] rdata,
    input      [           1:0] rresp,
    input                       rlast,
    input                       rvalid,
    output                      rready,

    output     [DATA_WIDTH-1:0] data[0:8],
    output                      data_valid
);

localparam IDLE     = 3'd0;
localparam AR_R1    = 3'd1;
localparam R_R1     = 3'd2;
localparam AR_R2    = 3'd3;
localparam R_R2     = 3'd4;
localparam AR_R3    = 3'd5;
localparam R_R3     = 3'd6;

reg  [2:0]              state_r, state_w;
reg  [DATA_WIDTH-1:0]   data_r[0:2][0:2], data_w[0:2][0:2];

reg  [ADDR_WIDTH-2:0]   cnt_r, cnt_w;
reg                     pixel_fin_r, pixel_fin_w;
wire                    top, left, right, bottom;
wire [6:0]              y_m1, y_p1, x_p1;

assign top = ~|cnt_r[13:7];
assign left = ~|cnt_r[6:0];
assign right = &cnt_r[6:0];
assign bottom = &cnt_r[13:7];
assign y_m1 = cnt_r[13:7] - 1'b1;
assign y_p1 = cnt_r[13:7] + 1'b1;
assign x_p1 = cnt_r[6:0] + 1'b1;

assign arlen = left ? 8'd1 : 8'd0;
assign arsize = 3'd0;
assign arburst = 2'd1;
assign arvalid = (state_r == AR_R1) || (state_r == AR_R2) || (state_r == AR_R3);
assign rready = (state_r == R_R1) || (state_r == R_R2) || (state_r == R_R3);

assign data[0] = data_r[0][0];
assign data[1] = data_r[0][1];
assign data[2] = data_r[0][2];
assign data[3] = data_r[1][0];
assign data[4] = data_r[1][1];
assign data[5] = data_r[1][2];
assign data[6] = data_r[2][0];
assign data[7] = data_r[2][1];
assign data[8] = data_r[2][2];
assign data_valid = pixel_fin_r;

always @(*) begin
    case(state_r) // synopsys parallel_case full_case
        IDLE:   state_w = start ? AR_R2 : IDLE;
        AR_R1:  state_w = (arready && arvalid) ? R_R1 : AR_R1;
        R_R1:   state_w = (rvalid && rlast) ? AR_R2 : R_R1;
        AR_R2:  state_w = (arready && arvalid) ? R_R2 : AR_R2;
        R_R2:   state_w = (rvalid && rlast) ? (bottom ? AR_R1 : AR_R3) : R_R2;
        AR_R3:  state_w = (arready && arvalid) ? R_R3 : AR_R3;
        R_R3:   state_w = (rvalid && rlast) ? ((top && !right) ? AR_R2 : AR_R1) : R_R3;
    endcase
end

always @(*) begin
    pixel_fin_w = rvalid && rlast && (bottom ? (state_r == R_R2) : (state_r == R_R3));
    cnt_w = (pixel_fin_w) ? cnt_r + 1'b1 : cnt_r;
end

always @(*) begin
    case(state_r) // synopsys parallel_case full_case
        AR_R1: araddr = left ? {1'b0, y_m1, cnt_r[6:0]} : {1'b0, y_m1, x_p1};
        AR_R2: araddr = left ? {1'b0, cnt_r} : {1'b0, cnt_r[13:7], x_p1};
        AR_R3: araddr = left ? {1'b0, y_p1, cnt_r[6:0]} : {1'b0, y_p1, x_p1};
    endcase
end

always @(*) begin
    data_w[0][0] = data_r[0][0];
    data_w[0][1] = data_r[0][1];
    data_w[0][2] = data_r[0][2];
    data_w[1][0] = data_r[1][0];
    data_w[1][1] = data_r[1][1];
    data_w[1][2] = data_r[1][2];
    data_w[2][0] = data_r[2][0];
    data_w[2][1] = data_r[2][1];
    data_w[2][2] = data_r[2][2];
    if (rvalid) begin
        case(state_r) // synopsys parallel_case full_case
            R_R1: begin 
                data_w[0][0] = data_r[0][1];
                data_w[0][1] = data_r[0][2];
                data_w[0][2] = right ? 8'd0 : rdata;
            end
            R_R2: begin
                data_w[1][0] = data_r[1][1];
                data_w[1][1] = data_r[1][2];
                data_w[1][2] = right ? 8'd0 : rdata;
            end
            R_R3: begin
                data_w[2][0] = data_r[2][1];
                data_w[2][1] = data_r[2][2];
                data_w[2][2] = right ? 8'd0 : rdata;
            end
        endcase
    end
    if (bottom) begin
        data_w[2][0] = 8'd0;
        data_w[2][1] = 8'd0;
        data_w[2][2] = 8'd0;
    end
end

always @(posedge clk_B or posedge rst) begin
    if (rst) begin
        state_r <= IDLE;
        pixel_fin_r <= 0;
        cnt_r <= 0;
        data_r[0][0] <= 0;
        data_r[0][1] <= 0;
        data_r[0][2] <= 0;
        data_r[1][0] <= 0;
        data_r[1][1] <= 0;
        data_r[1][2] <= 0;
        data_r[2][0] <= 0;
        data_r[2][1] <= 0;
        data_r[2][2] <= 0;
    end
    else begin
        state_r <= state_w;
        pixel_fin_r <= pixel_fin_w;
        cnt_r <= cnt_w;
        data_r[0][0] <= data_w[0][0];
        data_r[0][1] <= data_w[0][1];
        data_r[0][2] <= data_w[0][2];
        data_r[1][0] <= data_w[1][0];
        data_r[1][1] <= data_w[1][1];
        data_r[1][2] <= data_w[1][2];
        data_r[2][0] <= data_w[2][0];
        data_r[2][1] <= data_w[2][1];
        data_r[2][2] <= data_w[2][2];
    end
end


endmodule
