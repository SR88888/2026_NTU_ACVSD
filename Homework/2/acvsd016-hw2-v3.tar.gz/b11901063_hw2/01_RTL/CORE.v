`timescale 1ns/1ps
module CORE (
    input           clk_B,
    input           rst,

    input  [7:0]    i_data[0:8],
    input           i_valid,

    output [7:0]    o_data,
    output          o_valid
);

reg [7:0] compare_result;
reg [7:0] rotate[0:3];
reg [7:0] compare_tree[0:1];
reg [7:0] o_data_r, o_data_w;
reg       o_valid_r;
assign o_data = o_data_r;
assign o_valid = o_valid_r;

always @(*) begin
    compare_result[0] = (i_data[4] <= i_data[0]);
    compare_result[1] = (i_data[4] <= i_data[1]);
    compare_result[2] = (i_data[4] <= i_data[2]);
    compare_result[3] = (i_data[4] <= i_data[5]);
    compare_result[4] = (i_data[4] <= i_data[8]);
    compare_result[5] = (i_data[4] <= i_data[7]);
    compare_result[6] = (i_data[4] <= i_data[6]);
    compare_result[7] = (i_data[4] <= i_data[3]);
end

always @(*) begin
    rotate[0] = compare_result;
    rotate[1] = {compare_result[1:0], compare_result[7:2]};
    rotate[2] = {compare_result[3:0], compare_result[7:4]};
    rotate[3] = {compare_result[5:0], compare_result[7:6]};
    compare_tree[0] = (rotate[0] <= rotate[1]) ? rotate[0] : rotate[1];
    compare_tree[1] = (rotate[2] <= rotate[3]) ? rotate[2] : rotate[3];
end

always @(*) begin
   o_data_w = (compare_tree[0] <= compare_tree[1]) ? compare_tree[0] : compare_tree[1]; 
end

always @(posedge clk_B or posedge rst) begin
    if (rst) begin
        o_data_r <= 0;
        o_valid_r <= 0;
    end
    else begin
        o_data_r <= o_data_w;
        o_valid_r <= i_valid;
    end
end


endmodule
