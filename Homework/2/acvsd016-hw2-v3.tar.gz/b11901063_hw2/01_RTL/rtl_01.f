// Add your RTL files
./LBP.v
./CORE.v
./AXI_r.v
./AXI_w.v
./CDC.v

// tb
../00_TESTBED/axi/arbiter.v
../00_TESTBED/axi/axi_interconnect.v
../00_TESTBED/axi/priority_encoder.v
../00_TESTBED/axi/axi_ram.v
../00_TESTBED/testfixture.v
