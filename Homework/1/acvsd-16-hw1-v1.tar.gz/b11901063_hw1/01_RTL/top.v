`timescale 1ns / 1ps

module top(
    input i_clk,
    input i_rst_n,
    input i_valid,
    input [7:0] i_data_0,
    input [7:0] i_data_1, 
    input [7:0] i_data_2, 
    input [7:0] i_data_3,
    output o_valid,
    output [7:0] o_data,
    output NSLEEPIN
);
// ----------------------------------------------------
//               Parameters
// ----------------------------------------------------
localparam IDLE     = 3'd0;
localparam INPUT    = 3'd1;
localparam DELAY    = 3'd2;
localparam OUT_BM   = 3'd3;
localparam OUT_VAL  = 3'd4;
localparam FINISH   = 3'd5;
// ----------------------------------------------------
//               Signal Declarations
// ----------------------------------------------------
reg  [2:0]  state_r, state_w;
wire [7:0]  data[0:3];
wire [39:0] data_in_val[0:3];
wire [3:0]  val_fin;
wire [2:0]  cnt_val[0:3];
wire [63:0] data_in_bm[0:3];
wire        bm_fin;
wire [5:0]  cnt_bm;

reg  [8:0]  addr_val_r[0:3], addr_val_w[0:3];
reg  [1:0]  cen_val_r[0:3], cen_val_w[0:3];
reg  [1:0]  wen_val_r[0:3], wen_val_w[0:3];
wire [44:0] data_out_val[0:3][0:1];
reg  [1:0]  dslp_val_r[0:3], dslp_val_w[0:3];

reg  [2:0]  cnt_val_last_r[0:3], cnt_val_last_w[0:3];
reg  [8:0]  addr_val_last_r[0:3], addr_val_last_w[0:3];
reg  [3:0]  sram_val_last_r, sram_val_last_w;
reg  [3:0]  no_out_val_r, no_out_val_w;

reg  [2:0]  cnt_byte_r, cnt_byte_w;
reg         cnt_sram_r, cnt_sram_w;
reg         out_val_fin_r, out_val_fin_w;
reg  [1:0]  cnt_out_r, cnt_out_w;

reg  [6:0]  addr_bm_r, addr_bm_w;
reg  [3:0]  cen_bm_r, cen_bm_w;
reg         wen_bm_r, wen_bm_w;
wire [63:0] data_out_bm[0:3];
reg  [3:0]  dslp_bm_r, dslp_bm_w;

reg         o_valid_r, o_valid_w;
reg  [63:0] o_data_buff_r, o_data_buff_w;
reg  [7:0]  o_data_r, o_data_w;

integer     i;
// ----------------------------------------------------
//            Combinational Assignments
// ----------------------------------------------------
assign data[0] = i_data_0;
assign data[1] = i_data_1;
assign data[2] = i_data_2;
assign data[3] = i_data_3;
assign o_valid = o_valid_r;
assign o_data = o_data_r;
assign NSLEEPIN = (state_r == IDLE) || (state_r == INPUT) || (state_r == DELAY);
// ----------------------------------------------------
//                Module Instantiation
// ----------------------------------------------------
core u_core (
    .i_clk(i_clk), .i_rst_n(i_rst_n), .i_valid(i_valid), .i_data(data), 
    .o_data_in_val(data_in_val), .o_val_fin(val_fin), .o_cnt_val(cnt_val),
    .o_data_in_bm(data_in_bm), .o_bm_fin(bm_fin), .o_cnt_bm(cnt_bm)
);

genvar ch_i;
generate
    for (ch_i = 0; ch_i < 4; ch_i = ch_i + 1) begin : gen_channels
        TS1N16ADFPCLLLVTA512X45M4SWSHOD u_sram_val_0 (
            .A(addr_val_r[ch_i]), .CEB(cen_val_r[ch_i][0]), 
            .CLK(i_clk), .WEB(wen_val_r[ch_i][0]), 
            .D({5'b0, data_in_val[ch_i]}), .Q(data_out_val[ch_i][0]),
            .BWEB({45{1'b0}}), .RTSEL(2'b01), .WTSEL(2'b01), .SLP(1'b0), 
            .DSLP(dslp_val_r[ch_i][0]), .SD(1'b0), .PUDELAY()
        );
        TS1N16ADFPCLLLVTA512X45M4SWSHOD u_sram_val_1 (
            .A(addr_val_r[ch_i]), .CEB(cen_val_r[ch_i][1]), 
            .CLK(i_clk), .WEB(wen_val_r[ch_i][1]), 
            .D({5'b0, data_in_val[ch_i]}), .Q(data_out_val[ch_i][1]),
            .BWEB({45{1'b0}}), .RTSEL(2'b01), .WTSEL(2'b01), .SLP(1'b0), 
            .DSLP(dslp_val_r[ch_i][1]), .SD(1'b0), .PUDELAY()
        );
        TS1N16ADFPCLLLVTA128X64M4SWSHOD u_sram_bm (
            .A(addr_bm_r), .CEB(cen_bm_r[ch_i]), .CLK(i_clk),
            .WEB(wen_bm_r), .D(data_in_bm[ch_i]), .Q(data_out_bm[ch_i]),
            .BWEB({64{1'b0}}), .RTSEL(2'b01), .WTSEL(2'b01), .SLP(1'b0), 
            .DSLP(dslp_bm_r[ch_i]), .SD(1'b0), .PUDELAY()
        );
    end
endgenerate
// ----------------------------------------------------
//                Combinational Logic
// ----------------------------------------------------
always @(*) begin
    state_w = state_r;
    case(state_r)
        IDLE:    state_w = i_valid ? INPUT : IDLE;
        INPUT:   state_w = i_valid ? INPUT : DELAY;
        DELAY:   state_w = (&val_fin) ? OUT_BM : DELAY;
        OUT_BM:  state_w = (&{addr_bm_r, cnt_byte_r}) ? 
                           (no_out_val_r[cnt_out_r] ? (&cnt_out_r ? FINISH : OUT_BM) : OUT_VAL) : OUT_BM;
        OUT_VAL: state_w = out_val_fin_w ? (&cnt_out_r ? FINISH : OUT_BM) : OUT_VAL; 
        FINISH:  state_w = FINISH;
    endcase
end

always @(*) begin
    cnt_byte_w = cnt_byte_r;
    cnt_sram_w = cnt_sram_r;
    out_val_fin_w = (cnt_sram_r == sram_val_last_r[cnt_out_r]) && 
                    (addr_val_r[cnt_out_r] == addr_val_last_r[cnt_out_r]) && 
                    (cnt_byte_r == cnt_val_last_r[cnt_out_r]);
    cnt_out_w = cnt_out_r;

    if (state_r == OUT_BM) begin
        cnt_byte_w = cnt_byte_r + 1'b1;
        cnt_sram_w = 1'b0;
        cnt_out_w = (~|{addr_bm_r, cnt_byte_r} && cen_bm_r[0]) ? cnt_out_r + 1'b1 : cnt_out_r;
    end
    else if (state_r == OUT_VAL) begin
        cnt_byte_w = (out_val_fin_w || cnt_byte_r[2]) ? 3'd0 : cnt_byte_r + 1'b1;
        cnt_sram_w = (&{addr_val_r[cnt_out_r], cnt_byte_r[2]}) ? cnt_sram_r + 1'b1 : cnt_sram_r;
    end
    else if (state_r == FINISH) cnt_out_w = cnt_out_r + 1'b1;
end

always @(*) begin
    for (i = 0; i < 4; i = i + 1) begin
        addr_val_w[i] = addr_val_r[i];
        cen_val_w[i] = cen_val_r[i];
        wen_val_w[i] = wen_val_r[i];
        dslp_val_w[i] = dslp_val_r[i];
        cnt_val_last_w[i] = cnt_val_last_r[i];
        addr_val_last_w[i] = addr_val_last_r[i];
        sram_val_last_w[i] = sram_val_last_r[i];
        no_out_val_w[i] = no_out_val_r[i];
    end

    if (state_r == INPUT) begin
        for (i = 0; i < 4; i = i + 1) begin
            if (val_fin[i]) begin
                addr_val_w[i] = i_valid ? addr_val_r[i] + 1'b1 : addr_val_r[i];
                if (&addr_val_r[i]) begin
                    cen_val_w[i][0] = 1'b1;
                    cen_val_w[i][1] = cen_val_r[i][0];
                    wen_val_w[i][0] = 1'b1;
                    wen_val_w[i][1] = wen_val_r[i][0];
                end
            end
            else if (~i_valid) begin
                addr_val_w[i] = cnt_val[i][2] ? addr_val_r[i] - 1'b1 : addr_val_r[i];
                no_out_val_w[i] = (&cnt_val[i]) && (~|addr_val_r[i]) && cen_val_r[i][1];
            end

            if (~i_valid) begin
                cnt_val_last_w[i] = cnt_val[i];
            end
        end
    end
    else if (state_r == DELAY) begin
        for (i = 0; i < 4; i = i + 1) begin
            if (val_fin[i]) begin
                addr_val_last_w[i] = addr_val_r[i];
                sram_val_last_w[i] = (&addr_val_r[i]) ? &cen_val_r[i] : cen_val_r[i][0];
                wen_val_w[i] = 2'b11;
            end
        end
    end
    else if (state_r == OUT_BM) begin
        for (i = 0; i < 4; i = i + 1) begin
            addr_val_w[i] = 9'd0;
            cen_val_w[i] = 2'b11;
        end
        cen_val_w[cnt_out_r][0] = ~&{addr_bm_r, cnt_byte_r};
    end
    else if (state_r == OUT_VAL) begin
        for (i = 0; i < 4; i = i + 1) begin
            addr_val_w[i] = cnt_byte_r[2] ? addr_val_r[i] + 1'b1 : addr_val_r[i];
            if (&{addr_val_r[cnt_out_r], cnt_byte_r[2]}) begin
                cen_val_w[cnt_out_r][0] = 1'b1;
                cen_val_w[cnt_out_r][1] = cen_val_r[cnt_out_r][0];
                dslp_val_w[cnt_out_r][0] = 1'b1;
                dslp_val_w[cnt_out_r][1] = dslp_val_r[cnt_out_r][0];
            end
        end
    end
end

always @(*) begin
    addr_bm_w = addr_bm_r;
    cen_bm_w = cen_bm_r;
    wen_bm_w = wen_bm_r;
    dslp_bm_w = dslp_bm_r;

    if (state_r == INPUT) begin
        addr_bm_w = (bm_fin) ? addr_bm_r + 1'b1 : addr_bm_r;
        cen_bm_w = {4{cnt_bm != 6'd62}};
        wen_bm_w = (bm_fin && &addr_bm_r);
    end
    else if (state_r == DELAY) begin
        cen_bm_w = 4'b1110;
    end
    else if (state_r == OUT_BM) begin
        addr_bm_w = (&cnt_byte_r) ? addr_bm_r + 1'b1 : addr_bm_r;
        if (&{addr_bm_r, cnt_byte_r} && no_out_val_r[cnt_out_r]) begin
            cen_bm_w = {~cnt_out_r, |cnt_out_r, 1'b1};
            dslp_bm_w[cnt_out_r] = 1'b1;
        end
    end
    else if (state_r == OUT_VAL) begin
        cen_bm_w = out_val_fin_w ? {~cnt_out_r, |cnt_out_r, 1'b1} : 4'b1111;
        dslp_bm_w[cnt_out_r] = 1'b1;
    end
end

always @(*) begin
    o_data_buff_w = {o_data_buff_r[55:0], 8'd0};
    o_valid_w = o_valid_r;
    o_data_w = o_data_buff_r[63:56];
    if (state_r == OUT_BM) begin
        o_valid_w = o_valid_r || cnt_byte_r[1];
        if (cnt_byte_r == 3'd1) begin
            o_data_buff_w = data_out_bm[cnt_out_r];
        end
        else if ((cnt_byte_r == 3'd0) && out_val_fin_r && (~|cnt_val_last_r[cnt_out_r])) begin
            o_data_buff_w = {data_out_val[cnt_out_r][cnt_sram_r][39:0], 24'b0};
        end
    end
    else if (state_r == OUT_VAL) begin
        o_valid_w = 1'b1;
        if (cnt_byte_r == 3'd1) begin
            o_data_buff_w = {data_out_val[cnt_out_r][cnt_sram_r][39:0], 24'b0};
        end
    end
    else if (state_r == FINISH) begin
        o_valid_w = cnt_out_r[0];
    end
end

always @(posedge i_clk or negedge i_rst_n) begin
    if (!i_rst_n) begin
        state_r <= IDLE;
        for (i = 0; i < 4; i = i + 1) begin
            addr_val_r[i] <= 9'd0;
            cen_val_r[i] <= 2'b10;
            wen_val_r[i] <= 2'b10;
            dslp_val_r[i] <= 2'b00;
            cnt_val_last_r[i] <= 3'd0;
            addr_val_last_r[i] <= 9'd0;
            sram_val_last_r[i] <= 1'b0;
            no_out_val_r[i] <= 1'b0;
        end
        cnt_byte_r <= 3'd0;
        cnt_sram_r <= 1'b0;
        out_val_fin_r <= 1'b0;
        cnt_out_r <= 2'd0;
        addr_bm_r <= 7'd0;
        cen_bm_r <= 4'b0000;
        wen_bm_r <= 1'b0;
        dslp_bm_r <= 4'b0000;
        o_valid_r <= 1'b0;
        o_data_buff_r <= 64'b0;
        o_data_r <= 8'b0;
    end
    else begin
        state_r <= state_w;
        for (i = 0; i < 4; i = i + 1) begin
            addr_val_r[i] <= addr_val_w[i];
            cen_val_r[i] <= cen_val_w[i];
            wen_val_r[i] <= wen_val_w[i];
            dslp_val_r[i] <= dslp_val_w[i];
            cnt_val_last_r[i] <= cnt_val_last_w[i];
            addr_val_last_r[i] <= addr_val_last_w[i];
            sram_val_last_r[i] <= sram_val_last_w[i];
            no_out_val_r[i] <= no_out_val_w[i];
        end
        cnt_byte_r <= cnt_byte_w;
        cnt_sram_r <= cnt_sram_w;
        out_val_fin_r <= out_val_fin_w;
        cnt_out_r <= cnt_out_w;
        addr_bm_r <= addr_bm_w;
        cen_bm_r <= cen_bm_w;
        wen_bm_r <= wen_bm_w;
        dslp_bm_r <= dslp_bm_w;
        o_valid_r <= o_valid_w;
        o_data_buff_r <= o_data_buff_w;
        o_data_r <= o_data_w;
    end
end
    
endmodule

module core(
    input           i_clk,
    input           i_rst_n,
    input           i_valid,
    input  [7:0]    i_data[0:3],

    output [39:0]   o_data_in_val[0:3],
    output [3:0]    o_val_fin,
    output [2:0]    o_cnt_val[0:3],

    output [63:0]   o_data_in_bm[0:3],
    output          o_bm_fin,
    output [5:0]    o_cnt_bm
);

reg  [3:0]  save;
reg  [3:0]  start_r, start_w;
reg  [39:0] data_in_val_r[0:3], data_in_val_w[0:3];
reg  [2:0]  cnt_val_r[0:3], cnt_val_w[0:3];
reg  [3:0]  val_fin_r, val_fin_w;
reg  [63:0] data_in_bm_r[0:3], data_in_bm_w[0:3];
reg  [5:0]  cnt_bm_r, cnt_bm_w;
integer     i;

assign o_data_in_val[0] = data_in_val_r[0];
assign o_data_in_val[1] = data_in_val_r[1];
assign o_data_in_val[2] = data_in_val_r[2];
assign o_data_in_val[3] = data_in_val_r[3];
assign o_val_fin = val_fin_r;
assign o_cnt_val[0] = cnt_val_r[0];
assign o_cnt_val[1] = cnt_val_r[1];
assign o_cnt_val[2] = cnt_val_r[2];
assign o_cnt_val[3] = cnt_val_r[3];
assign o_data_in_bm[0] = data_in_bm_r[0];
assign o_data_in_bm[1] = data_in_bm_r[1];
assign o_data_in_bm[2] = data_in_bm_r[2];
assign o_data_in_bm[3] = data_in_bm_r[3];
assign o_bm_fin = (&cnt_bm_r);
assign o_cnt_bm = cnt_bm_r;

always @(*) begin 

    save[0] = (i_data[0] > 8'd10);
    save[1] = (i_data[1] > 8'd10);
    save[2] = (i_data[2] > 8'd10);
    save[3] = (i_data[3] > 8'd10);
    for (i = 0; i < 4; i = i + 1) begin
        start_w[i] = start_r[i] || save[i];
        data_in_val_w[i] = data_in_val_r[i];
        cnt_val_w[i] = cnt_val_r[i];
        val_fin_w[i] = val_fin_r[i];
        data_in_bm_w[i] = data_in_bm_r[i];
    end
    cnt_bm_w = cnt_bm_r;

    if (i_valid) begin
        for (i = 0; i < 4; i = i + 1) begin
            data_in_val_w[i] = save[i] ? {data_in_val_r[i][31:0], i_data[i]} : data_in_val_r[i];
            cnt_val_w[i] = save[i] ? (cnt_val_r[i][2] ? 3'd0 : cnt_val_r[i] + 1'b1) : cnt_val_r[i];
            val_fin_w[i] = save[i] && (cnt_val_r[i] == 3'd3);
            data_in_bm_w[i] = {data_in_bm_r[i][62:0], save[i]};
        end
        cnt_bm_w = cnt_bm_r + 1'b1;
    end
    else begin
        for (i = 0; i < 4; i = i + 1) begin
            data_in_val_w[i] = (~cnt_val_r[i][2]) ? {data_in_val_r[i][31:0], 8'd0} : data_in_val_r[i];
            cnt_val_w[i] = (~cnt_val_r[i][2]) ? cnt_val_r[i] + 1'b1 : cnt_val_r[i];
            val_fin_w[i] = val_fin_r[i] || (cnt_val_r[i] >= 3'd3);
        end
    end
end

always @(posedge i_clk or negedge i_rst_n) begin
    if (!i_rst_n) begin
        for (i = 0; i < 4; i = i + 1) begin
            start_r[i] <= 1'b0;
            data_in_val_r[i] <= 40'd0;
            cnt_val_r[i] <= 3'd7;
            val_fin_r[i] <= 1'b0;
            data_in_bm_r[i] <= 64'd0;
        end
        cnt_bm_r <= 6'd63;
    end
    else begin
        for (i = 0; i < 4; i = i + 1) begin
            start_r[i] <= start_w[i];
            data_in_val_r[i] <= data_in_val_w[i];
            cnt_val_r[i] <= cnt_val_w[i];
            val_fin_r[i] <= val_fin_w[i];
            data_in_bm_r[i] <= data_in_bm_w[i];
        end
        cnt_bm_r <= cnt_bm_w;
    end
end

endmodule

/*
always @(*) begin
    for (i = 0; i < 4; i = i + 1) begin
        cnt_val_w[i] = cnt_val_r[i];
        addr_val_w[i] = addr_val_r[i];
        data_in_val_w[i] = data_in_val_r[i];
        for (j = 0; j < 5; j = j + 1) begin
            cen_val_w[i][j] = cen_val_r[i][j];
            wen_val_w[i][j] = wen_val_r[i][j];
        end
        cnt_val_last_w[i] = cnt_val_last_r[i];
        addr_val_last_w[i] = addr_val_last_r[i];
        sram_val_last_w[i] = sram_val_last_r[i];
    end
    sram_val_cnt_w = sram_val_cnt_r;
    cnt_out_w = cnt_out_r;
    out_val_fin_w = out_val_fin_r;
    if (i_valid || state_r == INPUT) begin
        for (i = 0; i < 4; i = i + 1) begin
            if (save[i]) begin
                data_in_val_w[i] = {data_in_val_r[i][55:0], i_data[i]};
                cnt_val_w[i] = cnt_val_r[i] + 1'b1;
                addr_val_w[i] = (&cnt_val_r[i] && val_start_r[i]) ? addr_val_r[i] + 1'b1 : addr_val_r[i];
                cen_val_w[i][0] = (&addr_val_r[i] && &cnt_val_r[i]) ? 1'b1 : cen_val_r[i][0];
                wen_val_w[i][0] = (&addr_val_r[i] && &cnt_val_r[i]) ? 1'b1 : wen_val_r[i][0];
                for (j = 1; j < 5; j = j + 1) begin
                    cen_val_w[i][j] = (&addr_val_r[i] && &cnt_val_r[i]) ? cen_val_r[i][j-1] : cen_val_r[i][j];
                    wen_val_w[i][j] = (&addr_val_r[i] && &cnt_val_r[i]) ? wen_val_r[i][j-1] : wen_val_r[i][j];
                end
            end
        end
    end
    else if (state_r == OUT_BM) begin
        out_val_fin_w = 1'b0;
        cnt_val_w[0] = 3'd0;
        cnt_out_w = out_val_fin_r_delay ? cnt_out_r + 1'b1 : cnt_out_r;
        sram_val_cnt_w = 1'b0;
        for (i = 0; i < 4; i = i + 1) begin
            cen_val_w[i] = 5'b00000;
            addr_val_w[i] = 7'd0;
            wen_val_w[i] = 5'b11111;
        end
        if (~|cnt_out_r && ~|addr_bm_r && ~out_val_fin_r_delay) begin
            for (i = 0; i < 4; i = i + 1) begin
                cnt_val_w[i] = (~&cnt_val_r[i]) ? cnt_val_r[i] + 1'b1 : cnt_val_r[i];
                addr_val_w[i] = addr_val_r[i];
                data_in_val_w[i] = (~&cnt_val_r[i]) ? {data_in_val_r[i][55:0], 8'd0} : data_in_val_r[i];
                wen_val_w[i] = wen_val_r[i];
                cnt_val_last_w[i] = (~|cnt_bm_r[5:3]) ? cnt_val_r[i] : cnt_val_last_r[i];
                addr_val_last_w[i] = (~|cnt_bm_r[5:3]) ? addr_val_r[i] : addr_val_last_r[i];
                sram_val_last_w[i] = ~wen_val_r[i][4] ? 3'd4 : ~wen_val_r[i][3] ? 3'd3 : 
                                     ~wen_val_r[i][2] ? 3'd2 : ~wen_val_r[i][1] ? 3'd1 : 3'd0;
            end
        end
    end
    else if (state_r == OUT_VAL) begin
        sram_val_cnt_w = (&addr_val_r[cnt_out_r] && &cnt_val_w[0]) ? sram_val_cnt_r + 1'b1 : sram_val_cnt_r;
        cnt_val_w[0] = cnt_val_r[0] + 1'b1;
        for (i = 0; i < 4; i = i + 1) begin
            addr_val_w[i] = (&cnt_val_r[0]) ? addr_val_r[i] + 1'b1 : addr_val_r[i];
            cen_val_w[i] = 5'b00000;
            wen_val_w[i] = 5'b11111;
        end
        case(cnt_out_r)
            2'b00: out_val_fin_w = (sram_val_cnt_w == sram_val_last_r[0]) && 
                                   (addr_val_w[0] == addr_val_last_r[0]) && 
                                   (cnt_val_w[0] == cnt_val_last_r[0]);
            2'b01: out_val_fin_w = (sram_val_cnt_w == sram_val_last_r[1]) && 
                                   (addr_val_w[1] == addr_val_last_r[1]) && 
                                   (cnt_val_w[0] == cnt_val_last_r[1]);
            2'b10: out_val_fin_w = (sram_val_cnt_w == sram_val_last_r[2]) && 
                                   (addr_val_w[2] == addr_val_last_r[2]) && 
                                   (cnt_val_w[0] == cnt_val_last_r[2]);
            2'b11: out_val_fin_w = (sram_val_cnt_w == sram_val_last_r[3]) && 
                                   (addr_val_w[3] == addr_val_last_r[3]) && 
                                   (cnt_val_w[0] == cnt_val_last_r[3]);
        endcase
    end
end

always @(*) begin
    cnt_bm_w = cnt_bm_r;
    addr_bm_w = addr_bm_r;
    for (i = 0; i < 4; i = i + 1) begin
        data_in_bm_w[i] = data_in_bm_r[i];
        cen_bm_w[i] = cen_bm_r[i];
        wen_bm_w[i] = wen_bm_r[i];
    end
    if (i_valid || state_r == INPUT) begin
        cnt_bm_w = (state_r == INPUT) ? cnt_bm_r + 1'b1 : cnt_bm_r;
        addr_bm_w = (&cnt_bm_r) ? addr_bm_r + 1'b1 : addr_bm_r;
        for (i = 0; i < 4; i = i + 1) begin
            data_in_bm_w[i] = {data_in_bm_r[i][62:0], save[i]};
            cen_bm_w[i] = 1'b0;
            wen_bm_w[i] = ~i_valid;
        end
    end
    else if (state_r == OUT_BM)begin
        cnt_bm_w = cnt_bm_r + 4'd8;
        addr_bm_w = (&cnt_bm_r[5:3]) ? addr_bm_r + 1'b1 : addr_bm_r;
        cen_bm_w = 4'b0000;
        wen_bm_w = 4'b1111;
    end
end

always @(*) begin
    o_data_buff_w = {o_data_buff_r[55:0], 8'd0};
    o_valid_w = |o_data_buff_r;;
    o_data_w = o_data_buff_r[63:56];
    if (state_r == OUT_BM || state_r == OUT_VAL) begin
        o_valid_w = o_valid_r || cnt_bm_r[4];
        if (cnt_val_r[0] == 3'd1)       o_data_buff_w = i_data_out_val[cnt_out_r][sram_val_cnt_r];
        else if (cnt_bm_r[5:3] == 3'd1) o_data_buff_w = i_data_out_bm[cnt_out_r];
    end
end
// ----------------------------------------------------
//                Sequential Logic
// ----------------------------------------------------
always @(posedge i_clk or negedge i_rst_n) begin
    if (!i_rst_n) begin
        state_r <= IDLE;
        for (i = 0; i < 4; i = i + 1) begin
            val_start_r[i] <= 1'b0;
            cnt_val_r[i] <= 3'd7;
            addr_val_r[i] <= 0;
            data_in_val_r[i] <= 0;
            cen_val_r[i][0] <= 1'b0;
            wen_val_r[i][0] <= 1'b0;
            for (j = 1; j < 5; j = j + 1) begin
                cen_val_r[i][j] <= 1'b1;
                wen_val_r[i][j] <= 1'b1;
            end
            cnt_val_last_r[i] <= 0;
            addr_val_last_r[i] <= 0;
            sram_val_last_r[i] <= 0;
        end
        sram_val_cnt_r <= 0;
        out_val_fin_r <= 1'b0;
        out_val_fin_r_delay <= 1'b0;
        cnt_out_r <= 0;

        cnt_bm_r <= 0;
        addr_bm_r <= 0;
        for (i = 0; i < 4; i = i + 1) begin
            data_in_bm_r[i] <= 0;
            cen_bm_r[i] <= 1'b0;
            wen_bm_r[i] <= 1'b0;
        end

        o_data_buff_r <= 64'b0;
        o_valid_r <= 1'b0;
        o_data_r <= 8'b0;
    end 
    else begin
        state_r <= state_w;
        for (i = 0; i < 4; i = i + 1) begin
            val_start_r[i] <= val_start_w[i];
            cnt_val_r[i] <= cnt_val_w[i];
            addr_val_r[i] <= addr_val_w[i];
            data_in_val_r[i] <= data_in_val_w[i];
            for (j = 0; j < 5; j = j + 1) begin
                cen_val_r[i][j] <= cen_val_w[i][j];
                wen_val_r[i][j] <= wen_val_w[i][j];
            end
            cnt_val_last_r[i] <= cnt_val_last_w[i];
            addr_val_last_r[i] <= addr_val_last_w[i];
            sram_val_last_r[i] <= sram_val_last_w[i];
        end
        sram_val_cnt_r <= sram_val_cnt_w;
        out_val_fin_r <= out_val_fin_w;
        out_val_fin_r_delay <= out_val_fin_r;
        cnt_out_r <= cnt_out_w;

        cnt_bm_r <= cnt_bm_w;
        addr_bm_r <= addr_bm_w;
        for (i = 0; i < 4; i = i + 1) begin
            data_in_bm_r[i] <= data_in_bm_w[i];
            cen_bm_r[i] <= cen_bm_w[i];
            wen_bm_r[i] <= wen_bm_w[i];
        end

        o_data_buff_r <= o_data_buff_w;
        o_valid_r <= o_valid_w;
        o_data_r <= o_data_w;
    end
end
*/