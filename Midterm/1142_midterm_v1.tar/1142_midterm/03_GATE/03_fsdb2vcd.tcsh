#!/bin/tcsh
fsdb2saif vit_pe_P0_gate.fsdb -o vit_pe_P0_gate.vcd
fsdb2saif vit_pe_P1_gate.fsdb -o vit_pe_P1_gate.vcd
fsdb2saif vit_pe_P2_gate.fsdb -o vit_pe_P2_gate.vcd
fsdb2saif vit_pe_P3_gate.fsdb -o vit_pe_P3_gate.vcd

