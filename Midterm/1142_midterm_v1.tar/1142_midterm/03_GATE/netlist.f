// -------------------------------------------------------------
// Testbench & Simulation Environment
// -------------------------------------------------------------

../00_TESTBED/vit_pe_tb.v
../00_TESTBED/axi_ram/axi_ram.v

// -------------------------------------------------------------
// Design Netlist
// -------------------------------------------------------------

../02_SYN/Netlist/vit_pe_syn.v

// SRAM?
// /share1/tech/ADFP/Executable_Package/Collaterals/IP/sram/N16ADFP_SRAM/VERILOG/N16ADFP_SRAM_100a.v

// -------------------------------------------------------------
// Technology 
// -------------------------------------------------------------
-v /share1/tech/ADFP/Executable_Package/Collaterals/IP/stdcell/N16ADFP_StdCell/VERILOG/N16ADFP_StdCell.v


