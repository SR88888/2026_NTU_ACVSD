#!/bin/tcsh
vcs -full64 -R -f netlist.f +v2k -sverilog -v2005 +define+SDF+PAT_NUM=0 +maxdelays -negdelay +neg_tchk | tee gate_sim.log
#vcs -full64 -R -f netlist.f +v2k -sverilog -v2005 +define+FSDB+SDF+PAT_NUM=0 -debug_access+all +maxdelays -negdelay +neg_tchk | tee gate_sim.log


