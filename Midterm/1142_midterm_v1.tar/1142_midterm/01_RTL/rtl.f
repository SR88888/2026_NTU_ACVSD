// -------------------------------------------------------------
// Testbench & Simulation Environment
// -------------------------------------------------------------

../00_TESTBED/vit_pe_tb.v
../00_TESTBED/axi_ram/axi_ram.v

// -------------------------------------------------------------
// RTL Design Files
// -------------------------------------------------------------

../01_RTL/vit_pe.v
// Feel free to use SystemVerilog
// ../01_RTL/vit_pe.sv

// SRAM?
// /share1/tech/ADFP/Executable_Package/Collaterals/IP/sram/N16ADFP_SRAM/VERILOG/N16ADFP_SRAM_100a.v

// Other design files... 

// -------------------------------------------------------------
// Compilation Options & Search Paths
// -------------------------------------------------------------

// Verilog Library Extensions
+libext+.v+.sv+.vlib

// Module Search Path
-y /usr/cad/synopsys/synthesis/cur/dw/sim_ver
+incdir+/usr/cad/synopsys/synthesis/cur/dw/sim_ver/+

