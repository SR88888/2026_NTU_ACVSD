#!/bin/tcsh
vcs -full64 -R -f rtl.f -sverilog -v2005 +v2k +define+FSDB+PAT_NUM=0 +notimingcheck -debug_access+all | tee rtl_sim.log
# vcs -full64 -R -f rtl.f -sverilog -v2005 +v2k +define+PAT_NUM=0 +notimingcheck | tee rtl_sim.log
