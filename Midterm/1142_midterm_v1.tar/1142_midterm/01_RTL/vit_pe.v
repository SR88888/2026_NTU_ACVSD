module vit_pe #(
    parameter 	DATA_WIDTH 	= 8,
    parameter 	ADDR_WIDTH 	= 15,
    parameter 	STRB_WIDTH 	= (DATA_WIDTH/8)
)(
	// ------------------------------------------------------------
	// System Clock & Reset
	// ------------------------------------------------------------
	
    input 						clk_vit_pe,
    input 						clk_tb,  
    input 						clk_ram, 
    input 						rst_n,

	// ------------------------------------------------------------
    // Control Signals
	// ------------------------------------------------------------
	
    output 						finish,

	// ------------------------------------------------------------
    // AXI4 Interface
	// ------------------------------------------------------------
	
    // 1. Write Address Channel (AW)
    output 	[ADDR_WIDTH-1: 0] 	awaddr,
    output 	[ 7: 0] 			awlen,
    output 	[ 2: 0]			 	awsize,
    output 	[ 1: 0] 			awburst,
    output 						awvalid,
    input 						awready,

    // 2. Write Data Channel (W)
    output 	[DATA_WIDTH-1: 0] 	wdata,
    output 	[STRB_WIDTH-1: 0] 	wstrb,
    output 						wlast,
    output  					wvalid,
    input 						wready,

    // 3. Write Response Channel (B)
    input 	[ 1: 0] 			bresp,
    input 						bvalid,
    output 						bready,

    // 4. Read Address Channel (AR)
    output 	[ADDR_WIDTH-1: 0] 	araddr,
    output  [ 7: 0] 			arlen,
    output 	[ 2: 0] 			arsize,
    output 	[ 1: 0] 			arburst,
    output 						arvalid,
    input 						arready,

    // 5. Read Data Channel (R)
    input 	[DATA_WIDTH-1: 0] 	rdata,
    input 	[ 1: 0] 			rresp,
    input 						rlast,
    input 						rvalid,
    output 						rready
);

    // ===============================================================
    // TODO: Your Design Starts Here
    // ===============================================================
	







endmodule
