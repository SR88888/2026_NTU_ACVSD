module AXI_w # (
    parameter DATA_WIDTH = 8,              // AXI4 data width
    parameter ADDR_WIDTH = 15,             // AXI4 address width
    parameter STRB_WIDTH = (DATA_WIDTH/8)  // AXI4 strobe width
)
(
    input                   clk,
    input                   clk_ram,
    input                   rst_n,
    input  [ADDR_WIDTH-1:0] in_addr,
    input                   in_addr_valid,
    input  [DATA_WIDTH-1:0] in_data,
    input                   in_data_valid,
    // Data AXI4 master interface
    output [ADDR_WIDTH-1:0] awaddr,
    output [           7:0] awlen,
    output [           2:0] awsize,
    output [           1:0] awburst,
    output                  awvalid,
    input                   awready,
    output [DATA_WIDTH-1:0] wdata,
    output [STRB_WIDTH-1:0] wstrb,
    output                  wlast,
    output                  wvalid,
    input                   wready,
    output                  bready
);

localparam IDLE = 2'd0;
localparam AW   = 2'd1;
localparam WAIT = 2'd2;
localparam WR   = 2'd3;

reg  [1:0]  state_r, state_w;
wire        fifo_empty;
wire        fifo_push, fifo_pop;
wire [14:0] fifo_in_data, fifo_out_data;

assign awlen = 8'd0;
assign awsize = 3'd0;
assign awburst = 2'd0;
assign awvalid = (state_r == AW);
assign awaddr = fifo_out_data;
assign wvalid = (state_r == WR);
assign wstrb = {STRB_WIDTH{1'b1}};
assign wlast = (state_r == WR);
assign wdata = fifo_out_data[7:0];
assign bready = 1'b1;

assign fifo_push = in_addr_valid || in_data_valid;
assign fifo_pop = (~fifo_empty && ((state_r == AW && awready) || (state_r == WR && wready)));
assign fifo_in_data = (in_data_valid) ? in_data : in_addr;

always @(*) begin
    case(state_r)
        IDLE:   state_w = fifo_empty ? IDLE : AW;
        AW:     state_w = (awready && awvalid) ? WAIT : AW;
        WAIT:   state_w = fifo_empty ? WAIT : WR;
        WR:     state_w = (wready && wvalid) ? IDLE : WR;
    endcase
end

//synopsys sync_set_reset "rst_n"
always @(posedge clk_ram) begin
    if (!rst_n) state_r <= IDLE;
    else        state_r <= state_w;
end

DW_fifo_s2_sf #(
    .width(ADDR_WIDTH),
    .depth(5),
    .rst_mode(1)
) write_fifo_inst (
    .clk_push(clk),
    .clk_pop(clk_ram),
    .rst_n(rst_n),
    .push_req_n(~fifo_push),
    .pop_req_n(~fifo_pop),
    .pop_empty(fifo_empty),
    .data_in(fifo_in_data),
    .data_out(fifo_out_data)
);

endmodule
