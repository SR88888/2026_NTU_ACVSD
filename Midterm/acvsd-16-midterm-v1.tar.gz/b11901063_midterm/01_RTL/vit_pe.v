module vit_pe #(
    parameter 	DATA_WIDTH 	= 8,
    parameter 	ADDR_WIDTH 	= 15,
    parameter 	STRB_WIDTH 	= (DATA_WIDTH/8)
)(
	// ------------------------------------------------------------
	// System Clock & Reset
	// ------------------------------------------------------------
	
    input 						clk_vit_pe,
    input 						clk_tb,  
    input 						clk_ram, 
    input 						rst_n,

	// ------------------------------------------------------------
    // Control Signals
	// ------------------------------------------------------------
	
    output 						finish,

	// ------------------------------------------------------------
    // AXI4 Interface
	// ------------------------------------------------------------
	
    // 1. Write Address Channel (AW)
    output 	[ADDR_WIDTH-1: 0] 	awaddr,
    output 	[ 7: 0] 			awlen,
    output 	[ 2: 0]			 	awsize,
    output 	[ 1: 0] 			awburst,
    output 						awvalid,
    input 						awready,

    // 2. Write Data Channel (W)
    output 	[DATA_WIDTH-1: 0] 	wdata,
    output 	[STRB_WIDTH-1: 0] 	wstrb,
    output 						wlast,
    output  					wvalid,
    input 						wready,

    // 3. Write Response Channel (B)
    input 	[ 1: 0] 			bresp,
    input 						bvalid,
    output 						bready,

    // 4. Read Address Channel (AR)
    output 	[ADDR_WIDTH-1: 0] 	araddr,
    output  [ 7: 0] 			arlen,
    output 	[ 2: 0] 			arsize,
    output 	[ 1: 0] 			arburst,
    output 						arvalid,
    input 						arready,

    // 5. Read Data Channel (R)
    input 	[DATA_WIDTH-1: 0] 	rdata,
    input 	[ 1: 0] 			rresp,
    input 						rlast,
    input 						rvalid,
    output 						rready
);

    // ===============================================================
    // TODO: Your Design Starts Here
    // ===============================================================

wire        fifo_read_push;
wire        fifo_read_full;
wire        fifo_read_empty, fifo_read_request;
wire [7:0]  fifo_read_data;

wire        fifo_addr_valid, fifo_data_valid;
wire [14:0] fifo_write_addr;
wire [7:0]  fifo_write_data;
wire        finish_w;
reg         finish_r1, finish_r2;

assign fifo_read_push = rready && rvalid;
assign finish = finish_r2;


AXI_r #(
    .DATA_WIDTH(DATA_WIDTH),
    .ADDR_WIDTH(ADDR_WIDTH)
) axi_r_inst (
    .clk(clk_vit_pe),
    .clk_ram(clk_ram),
    .rst_n(rst_n),
    .fifo_read_full(fifo_read_full),
    .araddr(araddr),
    .arlen(arlen),
    .arsize(arsize),
    .arburst(arburst),
    .arvalid(arvalid),
    .arready(arready),
    .rlast(rlast),
    .rvalid(rvalid),
    .rready(rready)
);

DW_fifo_s2_sf #(
    .width(DATA_WIDTH),
    .depth(4),
    .rst_mode(1)
) read_data_fifo_inst (
    .clk_push(clk_ram),
    .clk_pop(clk_vit_pe),
    .rst_n(rst_n),
    .push_req_n(~fifo_read_push),
    .push_full(fifo_read_full),
    .pop_req_n(~fifo_read_request),
    .pop_empty(fifo_read_empty),
    .data_in(rdata),
    .data_out(fifo_read_data)
);

CORE core_inst (
    .clk(clk_vit_pe),
    .rst_n(rst_n),
    .in_data(fifo_read_data),
    .fifo_empty(fifo_read_empty),
    .fifo_request(fifo_read_request),
    .out_addr(fifo_write_addr),
    .out_addr_valid(fifo_addr_valid),
    .out_data(fifo_write_data),
    .out_data_valid(fifo_data_valid),
    .finish(finish_w)
);

// synopsys sync_set_reset "rst_n"
always @(posedge clk_tb) begin
    if (!rst_n) begin
        finish_r1 <= 0;
        finish_r2 <= 0;
    end
    else begin
        finish_r1 <= finish_w;
        finish_r2 <= finish_r1;
    end
end

AXI_w #(
    .DATA_WIDTH(DATA_WIDTH),
    .ADDR_WIDTH(ADDR_WIDTH),
    .STRB_WIDTH(STRB_WIDTH)
) axi_w_inst (
    .clk(clk_vit_pe),
    .clk_ram(clk_ram),
    .rst_n(rst_n),
    .in_addr(fifo_write_addr),
    .in_addr_valid(fifo_addr_valid),
    .in_data(fifo_write_data),
    .in_data_valid(fifo_data_valid),
    .awaddr(awaddr),
    .awlen(awlen),
    .awsize(awsize),
    .awburst(awburst),
    .awvalid(awvalid),
    .awready(awready),
    .wdata(wdata),
    .wstrb(wstrb),
    .wlast(wlast),
    .wvalid(wvalid),
    .wready(wready),
    .bready(bready)
);

endmodule
