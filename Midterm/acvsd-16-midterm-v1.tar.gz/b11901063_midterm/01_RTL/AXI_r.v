module AXI_r # (
    parameter DATA_WIDTH = 8,              // AXI4 data width
    parameter ADDR_WIDTH = 15              // AXI4 address width
)(
    input                       clk,
    input                       clk_ram,
    input                       rst_n,
    input                       fifo_read_full,
    // Data AXI4 master interface
    output     [ADDR_WIDTH-1:0] araddr,
    output     [           7:0] arlen,
    output     [           2:0] arsize,
    output     [           1:0] arburst,
    output                      arvalid,
    input                       arready,
    input                       rlast,
    input                       rvalid,
    output                      rready
);

localparam IDLE     = 4'd0;
localparam AR_S     = 4'd1;
localparam AR_W     = 4'd2;
localparam AR_P1    = 4'd3;
localparam AR_P2    = 4'd4;
localparam AR_P3    = 4'd5;
localparam AR_POS   = 4'd6;
localparam AR_CLS   = 4'd7;
localparam FIN      = 4'd8;

localparam RAM_IDLE = 1'b0;
localparam RAM_ADDR = 1'b1;

reg  [3:0]          state_r, state_w;
reg                 ram_state_r, ram_state_w;
reg  [1:0]          cnt_pat_row_r, cnt_pat_row_w;
reg  [5:0]          cnt_row_r, cnt_row_w;
reg  [5:0]          cnt_col_r, cnt_col_w;
wire [6:0]          tmp;
reg  [ADDR_WIDTH:0] fifo_in_data;
wire                fifo_push, fifo_full, fifo_pop, fifo_empty;
wire [ADDR_WIDTH:0] fifo_out_data;

assign tmp = cnt_row_r + 2'd2;
assign fifo_push = ~fifo_full && |state_r[2:0];
assign fifo_pop = ~fifo_empty && (ram_state_r == RAM_ADDR && arready);
assign arburst = 2'd1;
assign arsize = 3'd0;
assign arlen[7:2] = 6'd0;
assign arlen[1:0] = {2{fifo_out_data[ADDR_WIDTH]}};
assign araddr = fifo_out_data[ADDR_WIDTH-1:0];
assign arvalid = (ram_state_r == RAM_ADDR);
assign rready = ~fifo_read_full;

always @(*) begin
    state_w = state_r;
    case(state_r)
        IDLE:   state_w = AR_S;
        AR_S:   state_w = fifo_full ? AR_S : AR_W;
        AR_W:   state_w = fifo_full ? AR_W : (&{cnt_row_r[5], cnt_row_r[3:0]} ? AR_P1 : AR_W);
        AR_P1:  state_w = fifo_full ? AR_P1 : &cnt_pat_row_r ? AR_P2 : AR_P1;
        AR_P2:  state_w = fifo_full ? AR_P2 : &cnt_pat_row_r ? AR_P3 : AR_P2;
        AR_P3:  state_w = fifo_full ? AR_P3 : &cnt_pat_row_r ? AR_POS : AR_P3;
        AR_POS: state_w = fifo_full ? AR_POS : &cnt_row_r ? (&cnt_col_r ? AR_CLS : AR_S) : AR_P1;
        AR_CLS: state_w = fifo_full ? AR_CLS : &{cnt_col_r, cnt_row_r[0]} ? FIN : AR_CLS;
        FIN:    state_w = FIN;
    endcase
end

always @(*) begin
    cnt_pat_row_w = cnt_pat_row_r;
    cnt_row_w = cnt_row_r;
    cnt_col_w = cnt_col_r;
    case(state_r)
        AR_W:    cnt_row_w = fifo_full ? cnt_row_r : (&{cnt_row_r[5], cnt_row_r[3:0]} ? 6'd0 : cnt_row_r + 1'b1);
        AR_P1:   cnt_pat_row_w = fifo_full ? cnt_pat_row_r : cnt_pat_row_r + 1'b1;
        AR_P2:   cnt_pat_row_w = fifo_full ? cnt_pat_row_r : cnt_pat_row_r + 1'b1;
        AR_P3:   cnt_pat_row_w = fifo_full ? cnt_pat_row_r : cnt_pat_row_r + 1'b1;
        AR_POS: begin
            cnt_row_w = fifo_full ? cnt_row_r : cnt_row_r + 1'b1;
            cnt_col_w = (fifo_full || ~&cnt_row_r) ? cnt_col_r : cnt_col_r + 1'b1;
        end
        AR_CLS: begin
            cnt_row_w[0] = fifo_full ? cnt_row_r[0] : ~cnt_row_r[0];
            cnt_col_w = (fifo_full || ~cnt_row_r[0]) ? cnt_col_r : cnt_col_r + 1'b1;
        end
    endcase
end

always @(*) begin
    fifo_in_data = 0;
    case(state_r)
        AR_S:   fifo_in_data = {1'b1, 3'd1, 4'd12, cnt_col_r, 2'd0};
        AR_W:   fifo_in_data = {1'b0, 3'd1, cnt_row_r, cnt_col_r};
        AR_P1:  fifo_in_data = {1'b1, 3'd0, 2'd0, cnt_row_r[5:3], cnt_pat_row_r, cnt_row_r[2:0], 2'd0};
        AR_P2:  fifo_in_data = {1'b1, 3'd0, 2'd1, cnt_row_r[5:3], cnt_pat_row_r, cnt_row_r[2:0], 2'd0};
        AR_P3:  fifo_in_data = {1'b1, 3'd0, 2'd2, cnt_row_r[5:3], cnt_pat_row_r, cnt_row_r[2:0], 2'd0};
        AR_POS: fifo_in_data = {1'b0, 2'd1, tmp, cnt_col_r};
        AR_CLS: fifo_in_data = {1'b0, 3'd2, cnt_row_r, cnt_col_r};
    endcase
end

//synopsys sync_set_reset "rst_n"
always @(posedge clk) begin
    if (!rst_n) begin
        state_r <= IDLE;
        cnt_pat_row_r <= 0;
        cnt_row_r <= 0;
        cnt_col_r <= 0;
    end
    else begin
        state_r <= state_w;
        cnt_pat_row_r <= cnt_pat_row_w;
        cnt_row_r <= cnt_row_w;
        cnt_col_r <= cnt_col_w;
    end
end

always @(*) begin
    case(ram_state_r)
        RAM_IDLE: ram_state_w = fifo_empty ? RAM_IDLE : RAM_ADDR;
        RAM_ADDR: ram_state_w = (arready && arvalid) ? RAM_IDLE : RAM_ADDR;
    endcase
end

//synopsys sync_set_reset "rst_n"
always @(posedge clk_ram) begin
    if (!rst_n) ram_state_r <= RAM_IDLE;
    else        ram_state_r <= ram_state_w;
end

DW_fifo_s2_sf #(
    .width(ADDR_WIDTH+1),
    .depth(4),
    .rst_mode(1)
) read_addr_fifo_inst (
    .clk_push(clk),
    .clk_pop(clk_ram),
    .rst_n(rst_n),
    .push_req_n(~fifo_push),
    .push_full(fifo_full),
    .pop_req_n(~fifo_pop),
    .pop_empty(fifo_empty),
    .data_in(fifo_in_data),
    .data_out(fifo_out_data)
);

endmodule
