module CORE(
    input 		    clk,
    input 		    rst_n,
    input 	[7:0]   in_data,
    input 			fifo_empty,
    output          fifo_request,
    output  [14:0]  out_addr,
    output          out_addr_valid,
    output  [7:0]   out_data,
    output          out_data_valid,
    output          finish
);

localparam IDLE     = 3'd0;
localparam SCALE    = 3'd1;
localparam WAIT_W   = 3'd2;
localparam MAC      = 3'd3;
localparam MULT     = 3'd4;
localparam ADD_POS  = 3'd5;
localparam CLS1     = 3'd6;
localparam CLS2     = 3'd7;

reg  [2:0]  state_r, state_w;
reg  [5:0]  cnt_mac_r, cnt_mac_w;
reg  [5:0]  cnt_row_r, cnt_row_w;
reg  [5:0]  cnt_col_r, cnt_col_w;
reg  [31:0] scale_r, scale_w;
reg  [7:0]  weight_r[0:47], weight_w[0:47];
reg  [15:0] mul_res;
reg  [21:0] mac_res_r, mac_res_w;
wire [54:0] mul_scale_res;
reg  [21:0] add_pos_res;
reg  [12:0] out_addr_r, out_addr_w;
reg         out_valid_r, out_valid_w;
reg         finish_r, finish_w;
integer     i;

assign fifo_request = (state_r == SCALE || state_r == WAIT_W || state_r == MAC || state_r == ADD_POS || state_r == CLS1 || state_r == CLS2) && !fifo_empty;
assign out_addr = (state_r == ADD_POS) ? {2'd2, {1'b0, cnt_row_r} + 1'b1, cnt_col_r} : {2'd2, 7'd0, cnt_col_r};
assign out_addr_valid = (state_r == ADD_POS || state_r == CLS2) && fifo_request;
assign out_data = mac_res_r[7:0];
assign out_data_valid = out_valid_r;
assign finish = finish_r;

always @(*) begin
    state_w = state_r;
    case(state_r)
        IDLE:       state_w = fifo_empty ? IDLE : SCALE;
        SCALE:      state_w = (fifo_request && &cnt_mac_r[1:0]) ? WAIT_W : SCALE;
        WAIT_W:     state_w = (fifo_request && &{cnt_mac_r[5], cnt_mac_r[3:0]}) ? MAC : WAIT_W;
        MAC:        state_w = (fifo_request && &{cnt_mac_r[5], cnt_mac_r[3:0]}) ? MULT : MAC;
        MULT:       state_w = cnt_mac_r[0] ? ADD_POS : MULT;
        ADD_POS:    state_w = fifo_request ? (&cnt_row_r ? &cnt_col_r ? CLS1 : SCALE : MAC) : ADD_POS;
        CLS1:       state_w = fifo_request ? CLS2 : CLS1;
        CLS2:       state_w = fifo_request ? (&cnt_col_r ? IDLE : CLS1) : CLS2;
    endcase
end

always @(*) begin
    cnt_mac_w = cnt_mac_r;
    cnt_row_w = cnt_row_r;
    cnt_col_w = cnt_col_r;
    case(state_r)
        SCALE:  cnt_mac_w = fifo_request ? (&cnt_mac_r[1:0] ? 6'd0 : cnt_mac_r + 1'b1) : cnt_mac_r;
        WAIT_W: cnt_mac_w = fifo_request ? (&{cnt_mac_r[5], cnt_mac_r[3:0]} ? 6'd0 : cnt_mac_r + 1'b1) : cnt_mac_r;
        MAC:    cnt_mac_w = fifo_request ? (&{cnt_mac_r[5], cnt_mac_r[3:0]} ? 6'd0 : cnt_mac_r + 1'b1) : cnt_mac_r;
        MULT:   cnt_mac_w[0] = ~cnt_mac_r[0];
        ADD_POS: begin
            cnt_row_w = fifo_request ? cnt_row_r + 1'b1 : cnt_row_r;
            cnt_col_w = (fifo_request && &cnt_row_r) ? cnt_col_r + 1'b1 : cnt_col_r;
        end
        CLS2:   cnt_col_w = fifo_request ? cnt_col_r + 1'b1 : cnt_col_r;
    endcase
end

DW02_mult_2_stage #(.A_width(22), .B_width(33)) 
    u_mult (.A(mac_res_r), .B({1'b0, scale_r}), .TC(1'b1), .CLK(clk), .PRODUCT(mul_scale_res));

always @(*) begin
    scale_w = scale_r;
    for (i = 0; i < 48; i = i + 1) begin
        weight_w[i] = weight_r[i];
    end
    mul_res = $signed(weight_r[0]) * $signed({1'b0, in_data});
    mac_res_w = 0;
    add_pos_res = $signed(mac_res_r[21:0]) + $signed(in_data);
    out_valid_w = 0;
    out_addr_w = {7'd1, cnt_col_r};
    finish_w = finish_r;
    case(state_r)
        SCALE: scale_w = fifo_request ? {scale_r[23:0], in_data} : scale_r;
        WAIT_W: begin
            for (i = 0; i < 47; i = i + 1) begin
                weight_w[i] = fifo_request ? weight_r[i+1] : weight_r[i];
            end
            weight_w[47] = fifo_request ? in_data : weight_r[47];
        end
        MAC: begin
            for (i = 0; i < 47; i = i + 1) begin
                weight_w[i] = fifo_request ? weight_r[i+1] : weight_r[i];
            end
            weight_w[47] = fifo_request ? weight_r[0] : weight_r[47];
            mac_res_w = fifo_request ? ((~|cnt_mac_r) ? $signed(mul_res) : $signed(mac_res_r) + $signed(mul_res)) : $signed(mac_res_r);
        end
        MULT: begin
            mac_res_w = cnt_mac_r[0] ? (mul_scale_res[31] ? ($signed(mul_scale_res[53:32]) + 1) : $signed(mul_scale_res[53:32])) : mac_res_r;
        end
        ADD_POS, CLS2: begin
            mac_res_w = fifo_request ? (add_pos_res[21] && ~&add_pos_res[20:7]) ? 8'h80 : 
                                       (~add_pos_res[21] && |add_pos_res[20:7]) ? 8'h7F : add_pos_res[7:0] : $signed(mac_res_r);
            out_addr_w = (state_r == ADD_POS) ? {cnt_row_r + 1'b1, cnt_col_r} : {7'd0, cnt_col_r};
            out_valid_w = fifo_request;
        end
        CLS1: begin
            mac_res_w = fifo_request ? {{14{in_data[7]}}, in_data} : mac_res_r;
            finish_w = fifo_request && &cnt_col_r;
        end
    endcase
end

//synopsys sync_set_reset "rst_n"
always @(posedge clk) begin
    if (!rst_n) begin
        state_r <= IDLE;
        cnt_mac_r <= 0;
        cnt_row_r <= 0;
        cnt_col_r <= 0;
        scale_r <= 0;
        for (i = 0; i < 48; i = i + 1) begin
            weight_r[i] <= 0;
        end
        mac_res_r <= 0;
        out_addr_r <= 0;
        out_valid_r <= 0;
        finish_r <= 0;
    end 
    else begin
        state_r <= state_w;
        cnt_mac_r <= cnt_mac_w;
        cnt_row_r <= cnt_row_w;
        cnt_col_r <= cnt_col_w;
        scale_r <= scale_w;
        for (i = 0; i < 48; i = i + 1) begin
            weight_r[i] <= weight_w[i];
        end
        mac_res_r <= mac_res_w;
        out_addr_r <= out_addr_w;
        out_valid_r <= out_valid_w;
        finish_r <= finish_w;
    end
end

endmodule
