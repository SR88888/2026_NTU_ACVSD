
set sdc_version 1.2
#set_units -time ns -resistance kOhm -capacitance pF -voltage V -current uA
current_design CHIP
create_clock [get_ports {CLK}] -name CLK1 -period 100 -waveform {0 50} 
create_clock  -name vclk -period 100 -waveform {0 50} 
set_case_analysis 1 [get_ports {TEST_MODE}]
set_case_analysis 1 [get_ports {SCAN_EN}]
set_clock_uncertainty  -setup 0.5  [get_clocks {CLK1}]
set_clock_uncertainty  -hold 0.02  [get_clocks {CLK1}]
#set_clock_latency 0.3 [get_clocks {CLK1}]

set_input_delay     -max 3 -clock vclk [remove_from_collection [all_inputs] [get_ports CLK]]
set_input_delay     -min 0 -clock vclk [remove_from_collection [all_inputs] [get_ports CLK]]
set_output_delay    3 -clock vclk [all_outputs]

set_input_transition 0.1 [all_inputs]
set_drive 0.1 [all_inputs]
set_load -pin_load 20 [all_outputs]
set_max_fanout 8 [all_inputs]


#set_ideal_network [get_ports {CLK}]
