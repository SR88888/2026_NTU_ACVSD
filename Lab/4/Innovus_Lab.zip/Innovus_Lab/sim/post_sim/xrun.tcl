ida_probe -log
#probe -create CHIP -vcd -depth 2 all
ida_probe -wave -wave_probe_args="[scope -tops] -all -depth all"
run 500ns
#dumptcf -scope test.CHIP -output CHIP.tcf  -inctoggle -overwrite
dumpsaif -scope test.CHIP -output CHIP.saif -overwrite
run 3700ns
#dumptcf -end
dumpsaif -end
run 
exit
