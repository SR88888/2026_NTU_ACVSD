CHIP_sim.v
../../output/CHIP_pr.v
-v /share1/tech/ADFP/Executable_Package/Collaterals/IP/stdcell/N16ADFP_StdCell/VERILOG/N16ADFP_StdCell.v
-v /share1/tech/ADFP/Executable_Package/Collaterals/IP/stdio/N16ADFP_StdIO/VERILOG/N16ADFP_StdIO.v
-v /share1/tech/ADFP/Lab_adfp/library/memory/rf_2p_hse.v

