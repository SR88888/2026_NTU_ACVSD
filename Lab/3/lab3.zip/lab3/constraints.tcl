set DESIGN "ALU"
set CLOCK "clk"
set CLOCK_PERIOD 5.0

create_clock $CLOCK -period $CLOCK_PERIOD
set_ideal_network [get_ports $CLOCK]
set_dont_touch_network [get_ports $CLOCK]

set_clock_uncertainty 0.1 $CLOCK
set_input_delay  [ expr $CLOCK_PERIOD*0.5 ] -clock $CLOCK [remove_from_collection [all_inputs] $CLOCK]
set_output_delay [ expr $CLOCK_PERIOD*0.5 ] -clock $CLOCK [all_outputs]
set_drive 1 [all_inputs]
set_load  0.05 [all_outputs]

set_operating_conditions -max_library N16ADFP_StdCellss0p72vm40c_ccs -max ss0p72vm40c
set_boundary_optimization $DESIGN false
check_design

uniquify
set_fix_multiple_port_nets -all -buffer_constants [get_designs *]
set_fix_hold [get_clocks clk]
