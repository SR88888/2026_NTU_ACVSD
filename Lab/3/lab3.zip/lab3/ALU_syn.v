/////////////////////////////////////////////////////////////
// Created by: Synopsys DC Expert(TM) in wire load mode
// Version   : U-2022.12
// Date      : Mon Jul 22 08:26:50 2024
/////////////////////////////////////////////////////////////


module ALU_DW01_sub_0 ( A, B, CI, DIFF, CO );
  input [7:0] A;
  input [7:0] B;
  output [7:0] DIFF;
  input CI;
  output CO;
  wire   n1, n2, n3, n4, n5, n6, n7, n8, n9;
  wire   [7:2] carry;

  FA1D1BWP16P90LVT U2_6 ( .A(A[6]), .B(n3), .CI(carry[6]), .CO(carry[7]), .S(
        DIFF[6]) );
  FA1D1BWP16P90LVT U2_5 ( .A(A[5]), .B(n4), .CI(carry[5]), .CO(carry[6]), .S(
        DIFF[5]) );
  FA1D1BWP16P90LVT U2_4 ( .A(A[4]), .B(n5), .CI(carry[4]), .CO(carry[5]), .S(
        DIFF[4]) );
  FA1D1BWP16P90LVT U2_3 ( .A(A[3]), .B(n6), .CI(carry[3]), .CO(carry[4]), .S(
        DIFF[3]) );
  FA1D1BWP16P90LVT U2_2 ( .A(A[2]), .B(n7), .CI(carry[2]), .CO(carry[3]), .S(
        DIFF[2]) );
  FA1D1BWP16P90LVT U2_1 ( .A(A[1]), .B(n8), .CI(n1), .CO(carry[2]), .S(DIFF[1]) );
  XOR3D2BWP16P90LVT U2_7 ( .A1(A[7]), .A2(n2), .A3(carry[7]), .Z(DIFF[7]) );
  CKND1BWP16P90LVT U1 ( .I(B[1]), .ZN(n8) );
  CKND1BWP16P90LVT U2 ( .I(B[6]), .ZN(n3) );
  CKND1BWP16P90LVT U3 ( .I(B[5]), .ZN(n4) );
  CKND1BWP16P90LVT U4 ( .I(B[4]), .ZN(n5) );
  CKND1BWP16P90LVT U5 ( .I(B[3]), .ZN(n6) );
  CKND1BWP16P90LVT U6 ( .I(B[2]), .ZN(n7) );
  OR2D1BWP16P90LVT U7 ( .A1(A[0]), .A2(n9), .Z(n1) );
  CKND1BWP16P90LVT U8 ( .I(B[0]), .ZN(n9) );
  CKND1BWP16P90LVT U9 ( .I(B[7]), .ZN(n2) );
  XNR2D1BWP16P90LVT U10 ( .A1(n9), .A2(A[0]), .ZN(DIFF[0]) );
endmodule


module ALU_DW01_add_0 ( A, B, CI, SUM, CO );
  input [7:0] A;
  input [7:0] B;
  output [7:0] SUM;
  input CI;
  output CO;
  wire   n1;
  wire   [7:2] carry;

  FA1D1BWP16P90LVT U1_6 ( .A(A[6]), .B(B[6]), .CI(carry[6]), .CO(carry[7]), 
        .S(SUM[6]) );
  FA1D1BWP16P90LVT U1_5 ( .A(A[5]), .B(B[5]), .CI(carry[5]), .CO(carry[6]), 
        .S(SUM[5]) );
  FA1D1BWP16P90LVT U1_4 ( .A(A[4]), .B(B[4]), .CI(carry[4]), .CO(carry[5]), 
        .S(SUM[4]) );
  FA1D1BWP16P90LVT U1_3 ( .A(A[3]), .B(B[3]), .CI(carry[3]), .CO(carry[4]), 
        .S(SUM[3]) );
  FA1D1BWP16P90LVT U1_2 ( .A(A[2]), .B(B[2]), .CI(carry[2]), .CO(carry[3]), 
        .S(SUM[2]) );
  FA1D1BWP16P90LVT U1_1 ( .A(A[1]), .B(B[1]), .CI(n1), .CO(carry[2]), .S(
        SUM[1]) );
  XOR3D2BWP16P90LVT U1_7 ( .A1(A[7]), .A2(B[7]), .A3(carry[7]), .Z(SUM[7]) );
  AN2D1BWP16P90LVT U1 ( .A1(B[0]), .A2(A[0]), .Z(n1) );
  XOR2D1BWP16P90LVT U2 ( .A1(B[0]), .A2(A[0]), .Z(SUM[0]) );
endmodule


module ALU ( alu_out, instruction, inputA, inputB, clk, reset );
  output [7:0] alu_out;
  input [3:0] instruction;
  input [7:0] inputA;
  input [7:0] inputB;
  input clk, reset;
  wire   N39, N40, N41, N42, N43, N44, N45, N46, N47, N48, N49, N50, N51, N52,
         N53, N54, n18, n19, n20, n21, n22, n23, n24, n25, n26, n27, n28, n29,
         n30, n31, n32, n33, n34, n35, n36, n37, n38, n39, n40, n41, n42, n43,
         n44, n45, n46, n47, n48, n49, n50, n51, n52, n53, n54, n55, n56, n57,
         n58, n59, n60, n61, n62, n63, n64, n65, n66, n67, n68, n69, n70, n71,
         n72, n73, n74, n75, n76, n77, n78, n79, n80, n81, n82, n83, n84, n85,
         n86, n87, n88, n89, n90, n91, n92, n93, n94, n95, n96, n97, n98, n99,
         n100, n101, n102, n103, n104, n105, n106, n107, n108, n109, n110,
         n111, n112, n113, n114, n115, n116, n117, n118, n119;
  wire   [7:0] reg_A;
  wire   [7:0] reg_B;
  wire   [3:0] reg_ins;
  wire   [7:0] X;

  DFCNQD2BWP16P90LVT reg_B_reg_7_ ( .D(inputB[7]), .CP(clk), .CDN(n106), .Q(
        reg_B[7]) );
  DFCNQD2BWP16P90LVT reg_B_reg_6_ ( .D(inputB[6]), .CP(clk), .CDN(n106), .Q(
        reg_B[6]) );
  DFCNQD2BWP16P90LVT reg_B_reg_5_ ( .D(inputB[5]), .CP(clk), .CDN(n105), .Q(
        reg_B[5]) );
  DFCNQD2BWP16P90LVT reg_B_reg_4_ ( .D(inputB[4]), .CP(clk), .CDN(n105), .Q(
        reg_B[4]) );
  DFCNQD2BWP16P90LVT reg_B_reg_3_ ( .D(inputB[3]), .CP(clk), .CDN(n105), .Q(
        reg_B[3]) );
  DFCNQD2BWP16P90LVT reg_B_reg_2_ ( .D(inputB[2]), .CP(clk), .CDN(n105), .Q(
        reg_B[2]) );
  DFCNQD2BWP16P90LVT reg_B_reg_1_ ( .D(inputB[1]), .CP(clk), .CDN(n105), .Q(
        reg_B[1]) );
  DFCNQD2BWP16P90LVT reg_B_reg_0_ ( .D(inputB[0]), .CP(clk), .CDN(n105), .Q(
        reg_B[0]) );
  DFCNQD2BWP16P90LVT reg_ins_reg_3_ ( .D(instruction[3]), .CP(clk), .CDN(n105), 
        .Q(reg_ins[3]) );
  DFCNQD2BWP16P90LVT reg_ins_reg_2_ ( .D(instruction[2]), .CP(clk), .CDN(n105), 
        .Q(reg_ins[2]) );
  DFCNQD2BWP16P90LVT reg_ins_reg_1_ ( .D(instruction[1]), .CP(clk), .CDN(n105), 
        .Q(reg_ins[1]) );
  DFCNQD2BWP16P90LVT reg_ins_reg_0_ ( .D(instruction[0]), .CP(clk), .CDN(n105), 
        .Q(reg_ins[0]) );
  DFCNQD2BWP16P90LVT reg_A_reg_7_ ( .D(inputA[7]), .CP(clk), .CDN(n105), .Q(
        reg_A[7]) );
  DFCNQD2BWP16P90LVT reg_A_reg_6_ ( .D(inputA[6]), .CP(clk), .CDN(n105), .Q(
        reg_A[6]) );
  DFCNQD2BWP16P90LVT reg_A_reg_5_ ( .D(inputA[5]), .CP(clk), .CDN(n105), .Q(
        reg_A[5]) );
  DFCNQD2BWP16P90LVT reg_A_reg_4_ ( .D(inputA[4]), .CP(clk), .CDN(n104), .Q(
        reg_A[4]) );
  DFCNQD2BWP16P90LVT reg_A_reg_3_ ( .D(inputA[3]), .CP(clk), .CDN(n104), .Q(
        reg_A[3]) );
  DFCNQD2BWP16P90LVT reg_A_reg_2_ ( .D(inputA[2]), .CP(clk), .CDN(n104), .Q(
        reg_A[2]) );
  DFCNQD2BWP16P90LVT reg_A_reg_1_ ( .D(inputA[1]), .CP(clk), .CDN(n104), .Q(
        reg_A[1]) );
  DFCNQD2BWP16P90LVT reg_A_reg_0_ ( .D(inputA[0]), .CP(clk), .CDN(n104), .Q(
        reg_A[0]) );
  DFCNQD2BWP16P90LVT alu_out_reg_1_ ( .D(n97), .CP(clk), .CDN(n104), .Q(
        alu_out[1]) );
  DFCNQD2BWP16P90LVT alu_out_reg_2_ ( .D(n91), .CP(clk), .CDN(n104), .Q(
        alu_out[2]) );
  DFCNQD2BWP16P90LVT alu_out_reg_3_ ( .D(n85), .CP(clk), .CDN(n104), .Q(
        alu_out[3]) );
  DFCNQD2BWP16P90LVT alu_out_reg_4_ ( .D(n79), .CP(clk), .CDN(n104), .Q(
        alu_out[4]) );
  DFCNQD2BWP16P90LVT alu_out_reg_5_ ( .D(n73), .CP(clk), .CDN(n104), .Q(
        alu_out[5]) );
  DFCNQD2BWP16P90LVT alu_out_reg_6_ ( .D(n67), .CP(clk), .CDN(n104), .Q(
        alu_out[6]) );
  DFCNQD2BWP16P90LVT alu_out_reg_7_ ( .D(n61), .CP(clk), .CDN(n104), .Q(
        alu_out[7]) );
  DFCNQD2BWP16P90LVT alu_out_reg_0_ ( .D(n58), .CP(clk), .CDN(n104), .Q(
        alu_out[0]) );
  ALU_DW01_sub_0 sub_43 ( .A(reg_A), .B(reg_B), .CI(n57), .DIFF({N54, N53, N52, 
        N51, N50, N49, N48, N47}) );
  ALU_DW01_add_0 add_42 ( .A(reg_A), .B(reg_B), .CI(n57), .SUM({N46, N45, N44, 
        N43, N42, N41, N40, N39}) );
  TIELBWP20P90LVT U65 ( .ZN(n57) );
  DEL025D1BWP20P90 U66 ( .I(X[0]), .Z(n60) );
  CKBD1BWP16P90LVT U67 ( .I(n59), .Z(n58) );
  CKBD1BWP16P90LVT U68 ( .I(n60), .Z(n59) );
  CKBD1BWP16P90LVT U69 ( .I(n62), .Z(n61) );
  CKBD1BWP16P90LVT U70 ( .I(n63), .Z(n62) );
  CKBD1BWP16P90LVT U71 ( .I(n64), .Z(n63) );
  CKBD1BWP16P90LVT U72 ( .I(n65), .Z(n64) );
  CKBD1BWP16P90LVT U73 ( .I(n66), .Z(n65) );
  CKBD1BWP16P90LVT U74 ( .I(X[7]), .Z(n66) );
  CKBD1BWP16P90LVT U75 ( .I(n68), .Z(n67) );
  CKBD1BWP16P90LVT U76 ( .I(n69), .Z(n68) );
  CKBD1BWP16P90LVT U77 ( .I(n70), .Z(n69) );
  CKBD1BWP16P90LVT U78 ( .I(n71), .Z(n70) );
  CKBD1BWP16P90LVT U79 ( .I(n72), .Z(n71) );
  CKBD1BWP16P90LVT U80 ( .I(X[6]), .Z(n72) );
  CKBD1BWP16P90LVT U81 ( .I(n74), .Z(n73) );
  CKBD1BWP16P90LVT U82 ( .I(n75), .Z(n74) );
  CKBD1BWP16P90LVT U83 ( .I(n76), .Z(n75) );
  CKBD1BWP16P90LVT U84 ( .I(n77), .Z(n76) );
  CKBD1BWP16P90LVT U85 ( .I(n78), .Z(n77) );
  CKBD1BWP16P90LVT U86 ( .I(X[5]), .Z(n78) );
  CKBD1BWP16P90LVT U87 ( .I(n80), .Z(n79) );
  CKBD1BWP16P90LVT U88 ( .I(n81), .Z(n80) );
  CKBD1BWP16P90LVT U89 ( .I(n82), .Z(n81) );
  CKBD1BWP16P90LVT U90 ( .I(n83), .Z(n82) );
  CKBD1BWP16P90LVT U91 ( .I(n84), .Z(n83) );
  CKBD1BWP16P90LVT U92 ( .I(X[4]), .Z(n84) );
  CKBD1BWP16P90LVT U93 ( .I(n86), .Z(n85) );
  CKBD1BWP16P90LVT U94 ( .I(n87), .Z(n86) );
  CKBD1BWP16P90LVT U95 ( .I(n88), .Z(n87) );
  CKBD1BWP16P90LVT U96 ( .I(n89), .Z(n88) );
  CKBD1BWP16P90LVT U97 ( .I(n90), .Z(n89) );
  CKBD1BWP16P90LVT U98 ( .I(X[3]), .Z(n90) );
  CKBD1BWP16P90LVT U99 ( .I(n92), .Z(n91) );
  CKBD1BWP16P90LVT U100 ( .I(n93), .Z(n92) );
  CKBD1BWP16P90LVT U101 ( .I(n94), .Z(n93) );
  CKBD1BWP16P90LVT U102 ( .I(n95), .Z(n94) );
  CKBD1BWP16P90LVT U103 ( .I(n96), .Z(n95) );
  CKBD1BWP16P90LVT U104 ( .I(X[2]), .Z(n96) );
  CKBD1BWP16P90LVT U105 ( .I(n98), .Z(n97) );
  CKBD1BWP16P90LVT U106 ( .I(n99), .Z(n98) );
  CKBD1BWP16P90LVT U107 ( .I(n100), .Z(n99) );
  CKBD1BWP16P90LVT U108 ( .I(n101), .Z(n100) );
  CKBD1BWP16P90LVT U109 ( .I(n102), .Z(n101) );
  CKBD1BWP16P90LVT U110 ( .I(X[1]), .Z(n102) );
  CKND1BWP16P90LVT U111 ( .I(n22), .ZN(n115) );
  AOAI211D1BWP16P90LVT U112 ( .A1(n18), .A2(n19), .B(n103), .C(n20), .ZN(X[7])
         );
  AOI32D1BWP16P90LVT U113 ( .A1(n115), .A2(n107), .A3(reg_A[7]), .B1(reg_B[7]), 
        .B2(n21), .ZN(n20) );
  AOI32D1BWP16P90LVT U114 ( .A1(reg_B[7]), .A2(reg_A[7]), .A3(n24), .B1(n25), 
        .B2(n107), .ZN(n19) );
  AOI22D1BWP16P90LVT U115 ( .A1(N54), .A2(n26), .B1(N46), .B2(n27), .ZN(n18)
         );
  AOAI211D1BWP16P90LVT U116 ( .A1(n28), .A2(n29), .B(n103), .C(n30), .ZN(X[6])
         );
  AOI32D1BWP16P90LVT U117 ( .A1(n115), .A2(n117), .A3(reg_B[6]), .B1(reg_A[6]), 
        .B2(n31), .ZN(n30) );
  AOI32D1BWP16P90LVT U118 ( .A1(reg_A[6]), .A2(n24), .A3(reg_B[6]), .B1(n25), 
        .B2(n108), .ZN(n29) );
  AOI22D1BWP16P90LVT U119 ( .A1(N53), .A2(n26), .B1(N45), .B2(n27), .ZN(n28)
         );
  AOAI211D1BWP16P90LVT U120 ( .A1(n32), .A2(n33), .B(n103), .C(n34), .ZN(X[5])
         );
  AOI32D1BWP16P90LVT U121 ( .A1(n115), .A2(n109), .A3(reg_A[5]), .B1(reg_B[5]), 
        .B2(n35), .ZN(n34) );
  AOI32D1BWP16P90LVT U122 ( .A1(reg_A[5]), .A2(n24), .A3(reg_B[5]), .B1(n25), 
        .B2(n109), .ZN(n33) );
  AOI22D1BWP16P90LVT U123 ( .A1(N52), .A2(n26), .B1(N44), .B2(n27), .ZN(n32)
         );
  AOAI211D1BWP16P90LVT U124 ( .A1(n36), .A2(n37), .B(n103), .C(n38), .ZN(X[4])
         );
  AOI32D1BWP16P90LVT U125 ( .A1(n115), .A2(n110), .A3(reg_A[4]), .B1(reg_B[4]), 
        .B2(n39), .ZN(n38) );
  AOI32D1BWP16P90LVT U126 ( .A1(reg_A[4]), .A2(n24), .A3(reg_B[4]), .B1(n25), 
        .B2(n110), .ZN(n37) );
  AOI22D1BWP16P90LVT U127 ( .A1(N51), .A2(n26), .B1(N43), .B2(n27), .ZN(n36)
         );
  AOAI211D1BWP16P90LVT U128 ( .A1(n40), .A2(n41), .B(n103), .C(n42), .ZN(X[3])
         );
  AOI32D1BWP16P90LVT U129 ( .A1(n115), .A2(n118), .A3(reg_B[3]), .B1(reg_A[3]), 
        .B2(n43), .ZN(n42) );
  AOI32D1BWP16P90LVT U130 ( .A1(reg_A[3]), .A2(n24), .A3(reg_B[3]), .B1(n25), 
        .B2(n111), .ZN(n41) );
  AOI22D1BWP16P90LVT U131 ( .A1(N50), .A2(n26), .B1(N42), .B2(n27), .ZN(n40)
         );
  AOAI211D1BWP16P90LVT U132 ( .A1(n44), .A2(n45), .B(n103), .C(n46), .ZN(X[2])
         );
  AOI32D1BWP16P90LVT U133 ( .A1(n115), .A2(n112), .A3(reg_A[2]), .B1(reg_B[2]), 
        .B2(n47), .ZN(n46) );
  AOI32D1BWP16P90LVT U134 ( .A1(reg_A[2]), .A2(n24), .A3(reg_B[2]), .B1(n25), 
        .B2(n112), .ZN(n45) );
  AOI22D1BWP16P90LVT U135 ( .A1(N49), .A2(n26), .B1(N41), .B2(n27), .ZN(n44)
         );
  INR3D1BWP16P90LVT U136 ( .A1(reg_ins[1]), .B1(n116), .B2(reg_ins[2]), .ZN(
        n24) );
  AOAI211D1BWP16P90LVT U137 ( .A1(n52), .A2(n53), .B(n103), .C(n54), .ZN(X[0])
         );
  AOI22D1BWP16P90LVT U138 ( .A1(N47), .A2(n26), .B1(N39), .B2(n27), .ZN(n52)
         );
  AOI32D1BWP16P90LVT U139 ( .A1(n115), .A2(n114), .A3(reg_A[0]), .B1(reg_B[0]), 
        .B2(n55), .ZN(n54) );
  AOI32D1BWP16P90LVT U140 ( .A1(reg_A[0]), .A2(n24), .A3(reg_B[0]), .B1(n25), 
        .B2(n114), .ZN(n53) );
  AOAI211D1BWP16P90LVT U141 ( .A1(n48), .A2(n49), .B(n103), .C(n50), .ZN(X[1])
         );
  AOI32D1BWP16P90LVT U142 ( .A1(n115), .A2(n119), .A3(reg_B[1]), .B1(reg_A[1]), 
        .B2(n51), .ZN(n50) );
  AOI22D1BWP16P90LVT U143 ( .A1(N48), .A2(n26), .B1(N40), .B2(n27), .ZN(n48)
         );
  AOI32D1BWP16P90LVT U144 ( .A1(reg_A[1]), .A2(n24), .A3(reg_B[1]), .B1(n25), 
        .B2(n113), .ZN(n49) );
  INR3D1BWP16P90LVT U145 ( .A1(reg_ins[1]), .B1(reg_ins[0]), .B2(reg_ins[2]), 
        .ZN(n25) );
  IND3D1BWP16P90LVT U146 ( .A1(n103), .B1(n56), .B2(reg_ins[2]), .ZN(n23) );
  OAI21D1BWP16P90LVT U147 ( .A1(reg_A[0]), .A2(n22), .B(n23), .ZN(n55) );
  OAI21D1BWP16P90LVT U148 ( .A1(reg_A[7]), .A2(n22), .B(n23), .ZN(n21) );
  OAI21D1BWP16P90LVT U149 ( .A1(reg_B[6]), .A2(n22), .B(n23), .ZN(n31) );
  OAI21D1BWP16P90LVT U150 ( .A1(reg_A[5]), .A2(n22), .B(n23), .ZN(n35) );
  OAI21D1BWP16P90LVT U151 ( .A1(reg_A[4]), .A2(n22), .B(n23), .ZN(n39) );
  OAI21D1BWP16P90LVT U152 ( .A1(reg_B[3]), .A2(n22), .B(n23), .ZN(n43) );
  OAI21D1BWP16P90LVT U153 ( .A1(reg_A[2]), .A2(n22), .B(n23), .ZN(n47) );
  OAI21D1BWP16P90LVT U154 ( .A1(reg_B[1]), .A2(n22), .B(n23), .ZN(n51) );
  BUFFD1BWP16P90LVT U155 ( .I(reg_ins[3]), .Z(n103) );
  CKND1BWP16P90LVT U156 ( .I(reg_ins[0]), .ZN(n116) );
  NR2D1BWP16P90LVT U157 ( .A1(reg_ins[2]), .A2(n103), .ZN(n22) );
  NR2D1BWP16P90LVT U158 ( .A1(reg_ins[1]), .A2(reg_ins[0]), .ZN(n56) );
  NR3D1BWP16P90LVT U159 ( .A1(reg_ins[1]), .A2(reg_ins[2]), .A3(n116), .ZN(n26) );
  INR2D1BWP16P90LVT U160 ( .A1(n56), .B1(reg_ins[2]), .ZN(n27) );
  CKND1BWP16P90LVT U161 ( .I(reg_B[0]), .ZN(n114) );
  CKND1BWP16P90LVT U162 ( .I(reg_B[5]), .ZN(n109) );
  CKND1BWP16P90LVT U163 ( .I(reg_B[4]), .ZN(n110) );
  CKND1BWP16P90LVT U164 ( .I(reg_B[2]), .ZN(n112) );
  CKND1BWP16P90LVT U165 ( .I(reg_B[7]), .ZN(n107) );
  CKND1BWP16P90LVT U166 ( .I(reg_B[6]), .ZN(n108) );
  CKND1BWP16P90LVT U167 ( .I(reg_B[3]), .ZN(n111) );
  CKND1BWP16P90LVT U168 ( .I(reg_B[1]), .ZN(n113) );
  CKND1BWP16P90LVT U169 ( .I(reg_A[6]), .ZN(n117) );
  CKND1BWP16P90LVT U170 ( .I(reg_A[3]), .ZN(n118) );
  CKND1BWP16P90LVT U171 ( .I(reg_A[1]), .ZN(n119) );
  BUFFD1BWP16P90LVT U172 ( .I(reset), .Z(n104) );
  BUFFD1BWP16P90LVT U173 ( .I(reset), .Z(n105) );
  BUFFD1BWP16P90LVT U174 ( .I(reset), .Z(n106) );
endmodule

