#STEP1 Read Input Files
read_verilog ALU_syn.v
current_design ALU
link
check_design
source constraints.tcl
report_constraint -all_violators

report_area > ALU_syn.area_rpt
report_timing > ALU_syn.timing_rpt
report_power > ALU_syn.power_rpt


#STEP2  Select scan style
set test_default_scan_style multiplexed_flip_flop

#STEP3 Set ATE configuration and create test protocol (unit: ns)
set test_default_delay 0
set test_default_bidir_delay 0
set test_default_strobe 40
set test_default_period 100

create_test_protocol -infer_asynch -infer_clock

#(Optional)
#set_dft_signal -view existing_dft -type ScanClock -port clk -timing [list 45 55]
#set_dft_signal -view existing_dft -type reset -port reset -active_state 0
#create_test_protocol

#STEP4 Pre-scan Check
report_constraint -all_violators
dft_drc

#STEP5 Scan specification
set_scan_configuration -chain_count 1

#STEP6 Scan preview
preview_dft

#STEP7 Scan chain synthesis
insert_dft

#STEP8 Post-scan check
report_constraint -all_violators
dft_drc

#STEP9 Reports
report_scan_path -view existing -chain all > ALU_syn_dft.scan_path
report_scan_path -view existing -cell all > ALU_syn_dft.scan_cell
report_area > ALU_syn_dft.area_rpt
report_timing > ALU_syn_dft.timing_rpt
report_power > ALU_syn_dft.power_rpt

#STEP10 Write out files
write_scan_def -output ALU_syn_dft.scandef
write_test_protocol -output ALU_syn_dft.spf
write -hierarchy -format verilog -output ALU_syn_dft.v
write -hierarchy -format ddc -output ALU_syn_dft.ddc
write_sdf -version 2.1 ALU_syn_dft.sdf














