#STEP1 Read Input Files
read_netlist ALU_syn_dft.v
read_netlist /share1/tech/ADFP/Executable_Package/Collaterals/IP/stdcell/N16ADFP_StdCell/VERILOG/N16ADFP_StdCell.v
#STEP2 Build Model
run_build_model ALU
report_violations -all

#STEP3 Run DRC
run_drc ALU_syn_dft.spf

#STEP4 Set fault list
set_faults -model stuck
add_faults -all

#STEP5 Run ATPG
set_atpg -abort_limit 100 -merge high
run_atpg -auto_compression

#STEP6 Review Results
report_summaries

set_faults -report collapsed
report_summaries

set_faults -fault_coverage
report_summaries

#STEP7 Save Patterns
report_patterns -all

write_patterns ALU_syn_ATPG.wgl -format WGL
write_patterns ALU_syn_ATPG.stil -format STIL -vcs -serial